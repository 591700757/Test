//
//  AppDelegate.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import Alamofire
import KeychainAccess
import ObjectMapper
import SVProgressHUD
//import Reachability
//this is use as the 新日鉄 branch



@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {
    
    
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {

        if(FileManager.default.fileExists(atPath: kVoicedoDataBase) == false){
            PVDDatabaseAccess.sharedInstance.trycreateVoiceDoDB()
        }
        SVProgressHUD.setFont(UIFont.systemFont(ofSize: 20))

        if(NSClassFromString("XCTest") != nil){
            print("UNIT TESTでアプリを走らせない")
            voiceDoDataInit()
            let storyboard = UIStoryboard(name: "UnitTestsStoryboard", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "PVDUTController") as! PVDUTController
            self.window?.rootViewController = vc
            self.window?.makeKeyAndVisible()
            return true
        }else{
            print("UNIT TESTじゃないので正常に走らせる")
        }
        
        let uxxx068 = String(format: NSLocalizedString("UXXX-068", comment: "engine init failed"))
        let uxxx035 = String(format: NSLocalizedString("UXXX-035", comment: "file replaced"))
        let uxxx036 = String(format: NSLocalizedString("UXXX-036", comment: "file removed"))
        let uxxx069 = String(format: NSLocalizedString("UXXX-069", comment: "camera title"))
        let uxxx070 = String(format: NSLocalizedString("UXXX-070", comment: "camera message"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let enginePath   = PVDSwiftUtils.getEngineSettingFilePath()
        let engineBKPath = PVDSwiftUtils.getEngineSettingBKFilePath()

        //sr.iniの誤った編集で初期化失敗を復帰(sr.iniを復帰若しくは削除)
        let flagKeyValue:String? =  UserDefaults.standard.object(forKey: kInitFlagKey) as? String
        if((flagKeyValue == "initing")&&(enginePath != nil)&&(engineBKPath != nil)){
            if(FileManager.default.fileExists(atPath: enginePath!) == true){
                try! FileManager.default.removeItem(atPath: enginePath!)
            }
            if(FileManager.default.fileExists(atPath: engineBKPath!) == true){
                try! FileManager.default.copyItem(atPath: engineBKPath!, toPath: enginePath!)
                SVProgressHUD.showInfo(withStatus: uxxx035)
            }else{
                SVProgressHUD.showInfo(withStatus: uxxx036)
            }
        }
        
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 30
        alamofireManager = Alamofire.SessionManager(configuration: configuration)
        
        
//音声合成初期化
        //VoiceDo parameter初期化
        let lagFreeField = UITextField()
        self.window?.addSubview(lagFreeField)
        lagFreeField.becomeFirstResponder()
        lagFreeField.resignFirstResponder()
        lagFreeField.removeFromSuperview()
        
        print("buildversion:" + UIApplication.versionBuild() + "\n")
        voiceDoDataInit()
        PVDSwiftUtils.checkCommandListBind()
        print(gcontrolBinds)
        
        //音声エンジン初期化
        gInspectInitResult =  (PSRManager.shareInstance() as AnyObject).voicedoInit(PVDSwiftUtils.getShareContainerDomainPath(),
            iniUrl:  PVDSwiftUtils.getEngineSettingFilePath())
        if(gInspectInitResult != 0){
            DispatchQueue.main.async(execute: { () -> Void in
                PSRManager.sendLogTextAsync([kLogViewKey:uxxx068])
            })
        }
        if AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeVideo) ==  AVAuthorizationStatus.authorized
        {
            // Already Authorized
        }
        else
        {
            AVCaptureDevice.requestAccess(forMediaType: AVMediaTypeVideo, completionHandler: { (granted :Bool) -> Void in
                if granted == true
                {
                    // User granted
                    NSLog("カメラ使用可能です")
                }
                else
                {
                    
                    let alert = UIAlertController(title: uxxx069, message: uxxx070, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                        
                    }))
                    alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                        DispatchQueue.main.async(execute: {
                            if let url = URL(string:UIApplicationOpenSettingsURLString) {
                                UIApplication.shared.openURL(url)
                            }
                        })
                    }))
                    
                    
                    DispatchQueue.main.async(execute: {
                        self.window?.rootViewController?.present(alert, animated: true, completion: nil)
                    })
                }
            })
        }
        
//        if(NSFileManager.defaultManager().fileExistsAtPath(kbackupFolder) == true){
//            try! NSFileManager.defaultManager().copyItemAtPath(kbackupFolder, toPath: ktmpbackupFolder)
//        }

        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        NSLog("applicationWillResignActive")
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        UIApplication.shared.isIdleTimerDisabled = false
        

    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
        UIApplication.shared.isIdleTimerDisabled = true
//        SpeechTalkManager.sharedInstance.setSiriVoice(gsettingModel.siriLangurage!)
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        NSLog("applicationDidBecomeActive")
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.

        PVDSwiftUtils.saveSettingFile()
        (PSRManager.shareInstance() as AnyObject).voicedoClose()
        (PSRManager.shareInstance() as AnyObject).finalizeAudioQueue()
    }
    
    


    //後から追加されたパラメーターを追加設定する
    func updateSetting(){
        if(gsettingModel.globalFontSize == nil){
            gsettingModel.globalFontSize = 24
        }
        if(gsettingModel.workSharingFlag == nil){
            gsettingModel.workSharingFlag = false
        }
        if(gsettingModel.workSharingGoOn == nil){
            gsettingModel.workSharingGoOn = false
        }
        if(gsettingModel.workSharingArray != nil){
            gsettingModel.workSharingArray = (gsettingModel.workSharingArray! as NSArray).mutableCopy() as? NSMutableArray
        }
 
        if(gsettingModel.inputScrolToTopFlag == nil){
            gsettingModel.inputScrolToTopFlag = true
        }
        if((gsettingModel.audioFourceToUseBuildInSpeakerFlag == nil)||(gsettingModel.audioFourceToUseBuildInSpeakerFlag == false)){
            UserDefaults.standard.set("false", forKey: kForceToUseBuildInSpeeakKey)
            gsettingModel.audioFourceToUseBuildInSpeakerFlag = false
        }else{
            UserDefaults.standard.set("true", forKey: kForceToUseBuildInSpeeakKey)
         
        }
        if(gsettingModel.siriLangurage == nil){
            gsettingModel.siriLangurage = SiriLangKey.kJapanese.rawValue
        }
        if(gsettingModel.systemSettingLocked == nil){
            gsettingModel.systemSettingLocked = false;
        }
        if(gsettingModel.logLevel == nil){
            gsettingModel.logLevel = "0"
        }
        if(gsettingModel.workSharingBackUpMax == nil){
            gsettingModel.workSharingBackUpMax = 5
        }
        if(gsettingModel.engineLogEnable == nil){
            gsettingModel.engineLogEnable = false
        }
        if(gsettingModel.globalDescriptionFontSize == nil){
            gsettingModel.globalDescriptionFontSize = 16
        }
        if(gsettingModel.chosedEnv == nil){
            gsettingModel.chosedEnv = "silent.json"
        }
        if(gsettingModel.envDetail == nil){
            gsettingModel.envDetail = "初期値"
        }
        if(gsettingModel.autoUpload == nil){
            gsettingModel.autoUpload = false
        }
        if(gsettingModel.unfinishedListOrder == nil){
            gsettingModel.unfinishedListOrder = false
        }
    }
    
    
    //MARK: Voice initialize
    func voiceDoDataInit(){
        //Exception handler
        NSSetUncaughtExceptionHandler { (exception) -> Void in
            let arr = exception.callStackSymbols
            let reason = exception.reason
            let name = exception.name
            
            PVDSwiftUtils.backupCrashReport(name.rawValue, reason: reason!, callStackSymbols: arr.description)
        }
       
        let settingfileUrl = PVDSwiftUtils.getGroupSettingFileURL()
        var settingDic :[String:Any]? = nil
        
        if(settingfileUrl?.path != nil){
            settingDic = PVDSwiftUtils.getDictionarybyFullPathS((settingfileUrl?.path)!)
        }
        
        
        
        if(settingDic != nil){
            gsettingModel = Mapper<PVDSettingModel>().map(JSON: settingDic!)!
            
            //音声合成オン
            UserDefaults.standard.set(gsettingModel.inspectionOnSpeech, forKey: kInspectWithSpeechKey)
            UserDefaults.standard.set(gsettingModel.voiceDoChannel, forKey: kNrInUseKey)
            
            //default 1ch
            if(gsettingModel.voiceDoChannel == "1ch"){
                (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.oneChannelType)
            }else{
                (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.twoChannelType)
            }
            

            gSiriSpeechRate = Float(gsettingModel.siriSpeechRate!)

            UserDefaults.standard.set("false", forKey: kGlobalPausekey)
            UserDefaults.standard.synchronize()
            
        }else{
            
            if((UIDevice.current.systemVersion as NSString).floatValue >= 9){
                settingDic = [
                    "inspectionOnSpeech" : "true",
                    "noiseReduceLevel" : "1.0",
                    "choosedSpeaker" : "男性",
                    "choosedSpeakerfilePath" : kDefaultMalePath,
                    "siriSpeechRate" : "0.55",
                    "voiceDoChannel" : "1ch",
                    "cameraOff":"true",
                    "ipAddress":"",
                    "serverPath":"handsfree",
                    "port":"80",
                    "userid":"",
                    "lastupdate":"----/--/-- --:--:--",
                    "deviceid":"",
                    "globalFont":"24",
                    "workSharingBackUpMax":"5",
                    "workPlanId":"000001",
                    "autoUpload":false
                ]
            }else{
                settingDic = [
                    "inspectionOnSpeech" : "true",
                    "noiseReduceLevel" : "1.0",
                    "choosedSpeaker" : "男性",
                    "choosedSpeakerfilePath" : kDefaultMalePath,
                    "siriSpeechRate" : "0.25",
                    "voiceDoChannel" : "1ch",
                    "cameraOff":"true",
                    "ipAddress":"",
                    "serverPath":"handsfree",
                    "port":"80",
                    "userid":"",
                    "lastupdate":"----/--/-- --:--:--",
                    "deviceid":"",
                    "globalFont":"24",
                    "workSharingBackUpMax":"5",
                    "workPlanId":"000001",
                    "autoUpload":false
                ]
            }
            
            gsettingModel = Mapper<PVDSettingModel>().map(JSON: settingDic!)!
            gresultTimeStampFormat = DateFormatter()
            gworkshareTimeStampFormat = DateFormatter()
            //date formater
            gresultTimeStampFormat.dateFormat = "yyyy/MM/dd HH:mm:ss"
            gworkshareTimeStampFormat.dateFormat = "yyyyMMddHHmmss"
            PVDSwiftUtils.saveSettingFile()
            NSLog("critical:設定をが見つかりません、初期化をします")
            //音声合成オン
            UserDefaults.standard.set("false", forKey: kInspectWithSpeechKey)
            UserDefaults.standard.set("1ch", forKey: kNrInUseKey)
            
            //default 1ch
            (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.oneChannelType)
            UserDefaults.standard.set("1.0", forKey: kNrLevelKey)
            //一時停止フラグ
            UserDefaults.standard.set("false", forKey: kGlobalPausekey)
            
            
            
            UserDefaults.standard.synchronize()
        }
//        gchoosedSpeakerfilePath =  (NSHomeDirectory() as NSString).stringByAppendingPathComponent(gsettingModel.choosedSpeakerfilePath!)
//        gchooseSpeaker = gsettingModel.choosedSpeaker

        //ノイズレベル設定
        var noiseLevel:Float! = 0.0
        if(UserDefaults.standard.object(forKey: kNrLevelKey) != nil){
            noiseLevel = ((UserDefaults.standard.object(forKey: kNrLevelKey) as AnyObject).floatValue)!
        }else{
            UserDefaults.standard.set("1.0", forKey: kNrLevelKey)
            noiseLevel = ((UserDefaults.standard.object(forKey: kNrLevelKey) as AnyObject).floatValue)!
        }

        //Audio Dump再生の時不要語でリトライしないフラグ
        UserDefaults.standard.set("off", forKey: kAudioDumpModeKey)
        
        //後から追加されたconfig項目の初期化
        updateSetting()
        //エンジンのフラグを設定
        PSRManager.setNoiseLevel(noiseLevel)
        PSRManager.setEngineLogAndRaw(gsettingModel.engineLogEnable!)
        

        
        //global  work plan id
        let keychain = Keychain(service: kKeyChainKey)

        if(FileManager.default.fileExists(atPath: kStatusLogFolderPath) == false){
            try! FileManager.default.createDirectory(atPath: kStatusLogFolderPath, withIntermediateDirectories: true, attributes: nil)
        }
        gsettingModel.statusLogFileName = "StatusLog" + PVDSwiftUtils.getworkshareTimeStamp(Date()) + ".txt"
        gsettingModel.accessLogFileName = "AccessLog" + PVDSwiftUtils.getworkshareTimeStamp(Date()) + ".txt"
        //dic for speachの読み込み
        if(gDicForSpeach != nil){
            gDicForSpeach.removeAllObjects()
            gDicForSpeach = nil
        }
        
        //補助辞書を読み込む
        gDicForSpeach = NSMutableArray()
        
        if let aStreamReader = StreamReader(path: kdicForSpeachPathKey) {
            defer {
                aStreamReader.close()
            }
            var tmpArray:[String]!
            while let line = aStreamReader.nextLine() {
                tmpArray = line.components(separatedBy: ":")
                if(tmpArray.count != 2){
                    continue
                }
                let tmpDicModel:PVDDicForSpeachModel = PVDDicForSpeachModel(tword: tmpArray[0] , tyomi: tmpArray[1] )
                gDicForSpeach.add(tmpDicModel)
            }
        }
        
        //音声Dummp初期化

        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            do{
                try FileManager.default.createDirectory(atPath: kbackupFolder, withIntermediateDirectories: true, attributes: nil)
            }catch let error as NSError{
                print(error)
            }
            
        }
        
        //初回起動データを読み飛ばす 4*440
        UserDefaults.standard.set(4.0, forKey: kMikeZeroInputCountKey)
        UserDefaults.standard.synchronize()
        
    }
    
    

}

