//
//  PSRCore.cpp
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#include "PSRCore.h"
#include "logPrint.h"
#include "PSRCppUtils.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <assert.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include <time.h>
#include "PSRLocalizedInfo.h"


static std::mutex g_Mutex;


static std::string g_psr_backup_rule;   //バックアップルール

static void SRStatus200(void);
static bool g_initializingFlag = true; //初期化のフラグ true:初期化中/初期化失敗 false:初期化成功

static volatile int g_start_rule_flag = 0;//0:rule stop 1:rule start 2:辞書 close




PSRCore &PSRCore::getInstance()
{
    static PSRCore *_instance = NULL;
    if (_instance == NULL) {
        _instance = new PSRCore();
        
        memset(_instance->current_rule, 0x0, sizeof(_instance->current_rule));
        _instance->status = SRStopped;
        _instance->log_level = 0;
        g_psr_backup_rule = std::string();
        g_psr_backup_rule.clear();
    
        
    }
    return (PSRCore &)(*_instance);
}


//debug log用
const std::string currentDateTime() {
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[128];
    tstruct = *localtime(&now);
    sprintf(buf, "%d:%d:%d",tstruct.tm_hour,tstruct.tm_min,tstruct.tm_sec);

    
    return buf;
}


// 認識エンジンからの認識開始時のコールバック
static void SRStartCB(
                      void
                      )
{
    char tmp_string[128];
    PSRCore instance = PSRCore::getInstance();
    if(instance.log_level > 0){
        sprintf(tmp_string,"SRStartCB");
        instance.call_log(tmp_string);
    }
    
    if(instance.mStartCall != NULL){
        instance.mStartCall();
    }
}

// 認識エンジンからの認識終了時のコールバック
static void SRStopCB(
                     void
                     )
{
    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    if(instance.log_level > 0){
        sprintf(tmp_string, "[SRStopCB] start");
        instance.call_log(tmp_string);
    }

    // ルール停止のコールバック
    if(instance.mStopNCall != NULL){
        instance.mStopNCall();
    }
    
    if (instance.psr_runing_busy() == 2) {
        g_psr_backup_rule.clear();
    }else{
        instance.psr_set_running_status(0);
    
    }
    if(g_psr_backup_rule.empty() == true){
        if(instance.log_level > 0){
            sprintf(tmp_string, "バックアップルールがない,[SRStopCB] end");
            instance.call_log(tmp_string);
        }
        return ;
    }else{
        if(instance.log_level > 0){
            sprintf(tmp_string, "バックアップルールがある:%s" , g_psr_backup_rule.c_str());
            instance.call_log(tmp_string);
        }
        if(instance.mStopCall != NULL){
            instance.mStopCall();
        }

    }
    if(instance.log_level > 0){
        sprintf(tmp_string,"[SRStopCB] end");
        instance.call_log(tmp_string);
    }
}

// 認識エンジンからのエラー返却時のコールバック
static void SRFailureCB(
                        int failure_ret
                        )
{
    char failureString[BC_STRING_MAX];
    sprintf(failureString, "SRFailureCB%d",failure_ret);
    PSRCore instance = PSRCore::getInstance();
    if (instance.log_level > 0) {
        instance.call_log(failureString);
    }
    
    
}


static void SRSuccessCB(
                        char *success_ret
                        )
{
    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    if(instance.log_level > 0){
        sprintf(tmp_string,"SRSuccessCB");
        instance.call_log(tmp_string);
    }

    instance.status = SRCBFailed;

    
}

// 認識エンジンからのステータス返却時のコールバック
// 認識成功時は結果取得も行う
static void SRStatusCB(
                       int status,
                       int param
                       )
{
    log_printf("SRStatusCB %d %d", status, param);
    g_initializingFlag = false;
    char tmp_string[128];
    // 認識成功時の処理
    static int last = 0;
    PSRCore instance = PSRCore::getInstance();
    switch(status){
        case 100:{
            if(instance.log_level > 0){
                sprintf(tmp_string,"音声の始端が確定しました");
                instance.call_log(tmp_string);
            }
            instance.call_log(PSRLocalizedInfo::getInstance().logMessages[1]);
            break;
        }
        case 200:{
            if(instance.log_level > 0){
                sprintf(tmp_string,"音声の終端が確定しました");
                instance.call_log(tmp_string);
            }
            instance.call_log(PSRLocalizedInfo::getInstance().logMessages[2]);
            SRStatus200();
            
            break;
        }
        case 300:{
            if(last != status){
                sprintf(tmp_string, "SRStatusCB status = %d, level = %d", status, param);
                
                if(instance.log_level > 0){
                    instance.call_log(tmp_string);
                }
                instance.call_log(PSRLocalizedInfo::getInstance().logMessages[3]);

            }
            break;
        }
        case 500:{
            instance.status = SRStartted;
            if(instance.log_level > 0){
                sprintf(tmp_string,"認識を開始します");
                instance.call_log(tmp_string);
            }
            instance.call_log(PSRLocalizedInfo::getInstance().logMessages[5]);
            break;
        }
        case 600:{
            instance.status = SRStopped;
            if(instance.log_level > 0){
                sprintf(tmp_string,"認識を中断しました");
                instance.call_log(tmp_string);
            }
            instance.call_log(PSRLocalizedInfo::getInstance().logMessages[6]);
            
            break;
        }
        //REJECT系
        case 128:
            if(instance.log_level > 0){
                sprintf(tmp_string,"VD_REJECT_SHORT");
                instance.call_log(tmp_string);
            }
            break;
        case 256:
            if(instance.log_level > 0){
                sprintf(tmp_string,"VD_REJECT_LONG");
                instance.call_log(tmp_string);
            }
            break;
        case 512:
            if(instance.log_level > 0){
                sprintf(tmp_string,"VD_REJECT_SMALL");
                instance.call_log(tmp_string);
            }
            break;
        case 1024:
            if(instance.log_level > 0){
                sprintf(tmp_string,"VD_REJECT_LOUD");
                instance.call_log(tmp_string);
            }
            break;
        default:
            char unhandle[1024];
            sprintf(unhandle, "%s%d",PSRLocalizedInfo::getInstance().logMessages[27],status);
            break;
    }
    last = status;
}

// 認識エンジンの例外時のコールバック
static void SRExceptionCB(
                          char *exception_ret
                          )
{
    log_printf("SRExceptionCB %s", exception_ret);
    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    sprintf(tmp_string, "SRExceptionCB:%s" ,  std::string(exception_ret).c_str());
    instance.call_log(tmp_string);
}





//
// 認識エンジンと録音用キューの初期化

int PSRCore::psr_init(
           char *doc_dir,
           char *ini_file_name
           )
{
    char tmp_string[128];
    PSRCore instance = PSRCore::getInstance();
    if(instance.log_level > 0){
        sprintf(tmp_string,"[PSRCore::psr_init start]");
        instance.call_log(tmp_string);
    }
    if((doc_dir == NULL)||(ini_file_name == NULL)){
        return  -1;
    }

    

 
    std::lock_guard<std::mutex> lock(g_Mutex);


    char g_Doc_Dir[PATH_MAX];
    if(doc_dir != NULL) strncpy(g_Doc_Dir,doc_dir, PATH_MAX - 1);


    
    // FIFOファイルの残骸を削除
    PSRCppUtils::getInstance().removePipe(g_Doc_Dir);
    
    log_printf("GetInstance");
    // 認識エンジンのインターフェース
    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    
    char tmp_ncs[PATH_MAX];

    
    snprintf(tmp_ncs, PATH_MAX, "%s/.ncs", g_Doc_Dir);
    
    /* config check */
    char alert_msg[LINE_MAX];
    int err_flg = 0;
    log_printf("bool:%d",PSRCppUtils::getInstance().exists_test2(ini_file_name));
    
    if (!PSRCppUtils::getInstance().get_file_existence(ini_file_name)) {
        snprintf(alert_msg, PATH_MAX, "Not find config. [ config is '%s' ]", ini_file_name);
        err_flg |= 1;
    }

    g_psr_backup_rule.clear();
    if (err_flg) {
        log_printf("%s",alert_msg);
        // 設定ファイルが存在ない場合は、処理続行不可能なので、終了する
        if(instance.log_level > 0){
            
            sprintf(tmp_string, "[PSRCore::psr_init end],psr_init abort return error:設定ファイルがない,backup rule:%s", g_psr_backup_rule.c_str());
            instance.call_log(tmp_string);
        }
        g_initializingFlag = true;
        return -err_flg;
    }

    log_printf("Initialize======================================================================================\n");
    int ret = g_pIf->Initialize(tmp_ncs, ini_file_name);
    if(ret != 0){
        sprintf(tmp_string,"認識エンジンの初期化に失敗しました");
        instance.call_log(tmp_string);
        log_printf("認識エンジンの初期化に失敗しました:%s",ini_file_name);
        err_flg |= 8;
        return -err_flg;
    }
    log_printf("start Set Callback");
    g_pIf->set_on_started_call(SRStartCB);
    g_pIf->set_on_stopped_call(SRStopCB);
    g_pIf->set_recognition_failure_call(SRFailureCB);
    g_pIf->set_recognition_success_call(SRSuccessCB);
    g_pIf->set_recognition_status_call(SRStatusCB);
    g_pIf->set_exception_call(SRExceptionCB);
    log_printf("end Set Callback");


    log_printf("SetMaxWaveDataSize==============================================================================\n");
    g_pIf->SetMaxWaveDataSize(44100 * 2);
//    if(g_pIf->SetMaxWaveDataSize(44100 * 2) == false){
//        instance.call_alarm(PSRLocalizedInfo::getInstance().logMessages[28]);
//        err_flg |= 16;
//        return -err_flg;
//    }
    log_printf("AudioStart======================================================================================\n");
    int audioStartRet = g_pIf->AudioStart();
    if(audioStartRet != 0){
        instance.call_alarm(PSRLocalizedInfo::getInstance().logMessages[29]);
        err_flg |= 32;
        printf("audio start failed code:%d\n",audioStartRet);
        return -err_flg;
    }
    if(instance.log_level > 0){
        sprintf(tmp_string, "[PSRCore::psr_init end],backup rule:%s" , g_psr_backup_rule.c_str());
        instance.call_log(tmp_string);
    }
    if(err_flg == 0){
         g_initializingFlag = false;//初期化成功
    }else{
         g_initializingFlag = true;//初期化失敗
    }
    
    return -err_flg;
}


/**
 *  認識結果取得
 *
 *  @return 認識結果
 */
static char *getInspectionResult(){

    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    if (instance.log_level > 0) {
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[7]);
    }
    //エンジンclose dead lock対応 start
    if(g_start_rule_flag == 2){
        sprintf(tmp_string,"クローズ中認識結果をスールー");
        instance.call_log(tmp_string);
        return NULL;
    }
    //エンジンclose dead lock対応 end

    std::lock_guard<std::mutex> lock(g_Mutex);
    
    char *result;
    int retcode;
    
    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();

    retcode = g_pIf->GetResultInfo();
    // 認識結果取得
    log_printf("ResultCode: %d", retcode);
    log_printf("認識結果解析に入りました");
    
    if(retcode != 0) {
        
        if(retcode == 4){
            log_printf("解析結果がreject");
            instance.call_log(PSRLocalizedInfo::getInstance().logMessages[25]);
        }else{
            log_printf("解析結果がNULLかrecodeが不正:%d",retcode);
            instance.call_log(PSRLocalizedInfo::getInstance().logMessages[9]);
        }

        return NULL;
    }
    int gRet = g_pIf->GetResult(RANK, &result);
    if(gRet == iOS::RECOGNIZER_RESULT_ERROR_NONE){
        log_printf("結果取得成功");
    }else if(gRet == iOS::RECOGNIZER_RESULT_ERROR_PSR_GRMOBJ_GETWORDHYOKI){
        log_printf("結果取得失敗:表記取得失敗");
    }else if(gRet == iOS::RECOGNIZER_RESULT_ERROR_PSR_GRMOBJ_GETRESULT){
        log_printf("結果取得失敗:PSR_GrmObj_GetResult失敗");
    }else if(gRet == iOS::RECOGNIZER_RESULT_ERROR_NOT_ENOUGH_MEMORY){
        log_printf("結果取得失敗:メモリ不足");
    }else if(gRet == iOS::RECOGNIZER_RESULT_ERROR_PSR_REJECTJUDGE){
        log_printf("結果取得失敗:拒否された");
    }
    
    if (instance.log_level > 0) {
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[10]);
    }

    return result;
}

// 認識エンジンからステータス200がかえってきたときの動作
// 認識結果を取得する
static void SRStatus200(void)
{
    PSRCore instance = PSRCore::getInstance();
    if (instance.log_level > 0) {
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[11]);
    }
    

    char *result = getInspectionResult();
    if(result == NULL){
        if (instance.log_level > 0) {
            char tmp_string[128];
            sprintf(tmp_string,"認識結果取得失敗");
            instance.call_log(tmp_string);
        }
        return ;
    }

    
    // 読みと不要語を排除して表示用の結果取得
    char result2[4096];
    
    
    //エンジンのリーク対応
    memcpy(result2, result, strlen(result)+1);
    if(result != NULL){
        free(result);
    }
    
    

    instance.finish_inspection(result2, true);
    log_printf("認識結果解析終了、解析成功");
    if (instance.log_level > 0) {
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[12]);
    }
    
}







//// 録音と認識の開始
int PSRCore::psr_start(char * rule)
{
    char tmp_string[128];
    int ret = -1;
    PSRCore instance = PSRCore::getInstance();
    std::string time = "";
    if (instance.log_level > 0) {
        time = currentDateTime();
        sprintf(tmp_string, "%s%s__%s" , PSRLocalizedInfo::getInstance().logMessages[16],rule,time.c_str());
        instance.call_log(tmp_string);
    }
    //エンジンclose dead lock対応 start
    if(g_start_rule_flag == 2){
        return ret;
    }
    //エンジンclose dead lock対応 end
    // 認識開始
    std::lock_guard<std::mutex> lock(g_Mutex);

    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    
    if(instance.status == SRStartted){
        if (instance.log_level > 0) {
            sprintf(tmp_string, "%s%s" , PSRLocalizedInfo::getInstance().logMessages[17],this->current_rule);
            instance.call_log(tmp_string);
        }
        assert("illegalStart");
        exit(EXIT_FAILURE);
        return ret;
    }
    sprintf(this->current_rule, "%s",rule);
    
    if(g_pIf->Start(rule) != 0){
        printf("start rule failed\n");
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[30]);
    }else{
        if (instance.log_level > 0) {
            sprintf(tmp_string,"start rule success");
            instance.call_log(tmp_string);
        }
        ret = 0;
    }
    instance.status = SRStartted;
    log_printf("PSR Start rule:%s==========================================================================================\n",rule);
    if (instance.log_level > 0) {
        time = currentDateTime();
        sprintf(tmp_string, "%s%s__%s" , PSRLocalizedInfo::getInstance().logMessages[18],rule,time.c_str());
        instance.call_log(tmp_string);
    }
    return ret;
    
}


int PSRCore::psr_open_dic(const char* dicFileName){
    char tmp_string[128];
        PSRCore instance = PSRCore::getInstance();
    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s(%d)__start" ,__FUNCTION__,__LINE__);
        instance.call_log(tmp_string);
    }
    std::lock_guard<std::mutex> lock(g_Mutex);
    if(dicFileName == NULL){
        if (instance.log_level > 0) {
            sprintf(tmp_string, "%s(%d)__error end -1" ,__FUNCTION__,__LINE__);
            instance.call_log(tmp_string);
        }
        return  -1;
    }
    if(PSRCppUtils::getInstance().exists_test2(dicFileName) == false){
        if (instance.log_level > 0) {
            sprintf(tmp_string, "%s(%d)__error end -2" ,__FUNCTION__,__LINE__);
            instance.call_log(tmp_string);
        }
        
        return -2;
    }

    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    instance.psr_set_running_status(0);
    int ret =  g_pIf->OpenDic(dicFileName);
    if(ret != 0){
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[26]);
    }
    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s(%d)__end" ,__FUNCTION__,__LINE__);
        instance.call_log(tmp_string);
    }
    return ret;
}





int PSRCore::psr_set_user(const char *usrName){
    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    if(usrName == NULL){
        return -1;
    }
    
    if(PSRCppUtils::getInstance().exists_test2(usrName) == false){
        return -2;
    }
    int ret = -1;
    ret = g_pIf->SetUser(usrName);
    if(ret >= 0){
        return 0;
    }else{
        return  ret;
    }
    
}

const char *PSRCore::psr_get_user(){
    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    return g_pIf->GetUser();
}



// 録音と認識の終了
int PSRCore::psr_stop()
{
    std::string time = currentDateTime();
    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s%s__%s" , PSRLocalizedInfo::getInstance().logMessages[19],this->current_rule,time.c_str());
        instance.call_log(tmp_string);
    }
    //エンジンclose dead lock対応 start
    if(g_start_rule_flag == 2){
        return -2;
    }
    //エンジンclose dead lock対応 end
    std::lock_guard<std::mutex> lock(g_Mutex);
    
    
    
    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    // 認識終了
    char *g_pRule = this->current_rule;
    

    if(mStopAudioCall){
        mStopAudioCall();
    }
    int ret = g_pIf->Stop(g_pRule);//通常のルール停止関数でルールでの停止

    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s%s__%s" , PSRLocalizedInfo::getInstance().logMessages[20],this->current_rule,time.c_str());
        instance.call_log(tmp_string);
    }
    return ret;
}


int PSRCore::psr_close_dic(){

    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    // 認識終了
    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s(%d)__start" ,__FUNCTION__,__LINE__);
        instance.call_log(tmp_string);
    }
    std::lock_guard<std::mutex> lock(g_Mutex);
    instance.psr_set_running_status(2);
    g_psr_backup_rule.clear();
    if(mStopAudioCall){
        mStopAudioCall();
    }
    g_pIf->Stop(this->current_rule);//辞書クローズ時ルール停止
    g_pIf->CloseDic();
    
    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s(%d)__end" ,__FUNCTION__,__LINE__);
        instance.call_log(tmp_string);
    }
    return  0;//PocketInterfaceでのCloseDicの戻り時実装したいfalseの場合も返す
}


// 録音用キューの破棄と認識エンジンの終了処理
void PSRCore::psr_close(void)
{
    std::lock_guard<std::mutex> lock(g_Mutex);
    // 録音中止
    PSRCore instance = PSRCore::getInstance();
    char tmp_string[128];
    if (instance.log_level > 0){
        sprintf(tmp_string,"[PSRCore::psr_close start]");
        instance.call_log(tmp_string);
        sprintf(tmp_string, "%s%s" , PSRLocalizedInfo::getInstance().logMessages[21],this->current_rule);
        instance.call_log(tmp_string);
    }
    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();

    log_printf("finalizeQueue===================================================================================\n");

    
    instance.psr_set_running_status(2);
    g_psr_backup_rule.clear();


    if(mStopAudioCall){
        mStopAudioCall();
    }
    g_pIf->Stop(this->current_rule);//エンジンクローズ時ルール停止

    log_printf("AudioStop=======================================================================================\n");
    g_pIf->AudioStop();
#ifdef USE_STARTPLAY
    log_printf("stopPlay========================================================================================\n");
    g_pIf->stopRec();
#endif
    log_printf("CloseDic========================================================================================\n");
    g_pIf->CloseDic();
    log_printf("Finalize========================================================================================\n");
    g_pIf->Finalize();
    if (instance.log_level > 0) {
        sprintf(tmp_string, "%s%s" , PSRLocalizedInfo::getInstance().logMessages[22],this->current_rule);
        instance.call_log(tmp_string);
        sprintf(tmp_string,"[psr_close] PSR Stop rule:%s,[PSRCore::psr_close end]" , this->current_rule);
        instance.call_log(tmp_string);
    }
}


void PSRCore::finish_inspection(char *result,bool successFlag){
    PSRCore instance = PSRCore::getInstance();
    
    if ((result == NULL)||(result[0] == '\0')||(std::string(result).length() == 0)) {
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[23]);

        
        instance.call_log(PSRLocalizedInfo::getInstance().logMessages[24]);
        return ;
    }

    if (!mResultCall) {
        log_printf("解析コールバックが設置されていません");
        return ;
    }
    mResultCall(result,successFlag);
}

//test methods
void PSRCore::set_stopAudioCB(void (*func)(void)){
    mStopAudioCall = func;
}

void PSRCore::set_stopCB(void (*func)(void)){
    mStopCall = func;
}

void PSRCore::set_stopNCB(void (*func)(void)){
    mStopNCall = func;
}

void PSRCore::set_result_call(void (*func)(char *,bool))
{
    mResultCall =  func;
}


void PSRCore::set_log_call(void (*func)(std::string)){
    mLogCall = func;
}

void PSRCore::set_alarm(void (*func)(std::string)){
    mAlarmCall = func;
}

void PSRCore::set_startCB(void (*func)()){
    mStartCall = func;
}

void PSRCore::call_log(char *logstr){
    if((logstr != NULL)&&(mLogCall != nullptr)){
        if(mLogCall != NULL){
            mLogCall(std::string(logstr));
        }
    }else{
        printf("logの内容がNullですかmLogCallが未設定\n");
    }
    
}



void PSRCore::call_alarm(char *alarmstr){
    if((mAlarmCall != nullptr)&&(alarmstr != NULL)){
        printf("alarmstr:%s\n",alarmstr);
        mAlarmCall(std::string(alarmstr));
    }else{
        printf("alarmの内容がNullですかmAlarmが未設定\n");
    }
}

void PSRCore::removePipe(char *p_doc_dir){
    char doc_Dir[PATH_MAX];
    if(p_doc_dir != NULL){
        strncpy(doc_Dir,p_doc_dir, PATH_MAX - 1);
    }
     PSRCppUtils::getInstance().removePipe(doc_Dir);
}



int PSRCore::psr_runing_busy(){
    PSRCore instance = PSRCore::getInstance();
    char logContent[128];
    sprintf(logContent, "[PSRCore::psr_runing_busy]:get psr_runing_busy(read):%d",g_start_rule_flag);
    if(instance.log_level  > 0){
        instance.call_log(logContent);
    }
    
    return g_start_rule_flag;
}

void PSRCore::psr_set_running_status(int flag){
    PSRCore instance = PSRCore::getInstance();
    char logContent[128];
    sprintf(logContent, "[PSRCore::psr_set_running_status]:running set to(write):%d",flag);
    if(instance.log_level > 0){
        instance.call_log(logContent);
    }
    g_start_rule_flag = flag;
    
}

bool PSRCore::psr_isinitializing(){
    
    return g_initializingFlag;
}

int PSRCore::set_log_level(int level){
    if(level <= 0){
        log_level = 0;
    }else{
        log_level = level;
    }
    return log_level;
}


int PSRCore::get_log_level(){
    return log_level;
}

void PSRCore::set_backup_rule(std::string back_uprule){
    PSRCore instance = PSRCore::getInstance();
    char logContent[128];
    sprintf(logContent, "[PSRCore::set_backup_rule]:back up rule is set(write):%s",back_uprule.c_str());
    if(instance.log_level  > 0){
        instance.call_log(logContent);
    }
    g_psr_backup_rule = back_uprule;
}


std::string PSRCore::get_backup_rule(){
    PSRCore instance = PSRCore::getInstance();
    char logContent[128];
    sprintf(logContent, "[PSRCore::get_backup_rule]:reading back up rule(read):%s",g_psr_backup_rule.c_str());
    printf("getting backup rule:%s",g_psr_backup_rule.c_str());
    if(instance.log_level  > 0){
        instance.call_log(logContent);
    }
    return g_psr_backup_rule;
}

void PSRCore::clear_backup_rule(){
    g_psr_backup_rule.clear();
    PSRCore instance = PSRCore::getInstance();
    char logContent[128];
    sprintf(logContent, "[PSRCore::clear_backup_rule]:clear back up rule(clear):%s",g_psr_backup_rule.c_str());
    if(instance.log_level  > 0){
        instance.call_log(logContent);
    }
}


//unit test
void PSRCore::unittest30(){
    char result2[4096] = "\x95s\x97v\x8c\352/\202ӂ\xa4;\x95s\x97v\x8c\352/\202ӂ\xa4;";
    PSRCore instance = PSRCore::getInstance();

    instance.finish_inspection(result2, true);

}

void PSRCore::unittest31(){
    char result2[4096] = "\x98R\x82\xa6\x82\xa2\x82\xa0\x82\350,\223\374\x97͒l,Item_00001/\x82낤\x82\xa6\x82\xa2\x82\xa0\x82\350\202傤;";
    PSRCore instance = PSRCore::getInstance();
    
    
    
    instance.finish_inspection(result2, true);
    
}

void PSRCore::utcalllogNull(){
    PSRCore instance = PSRCore::getInstance();
    instance.call_log(NULL);
}

void PSRCore::unittest_srStartCB(){
    SRStartCB();
}



void PSRCore::unittest_SRStopCB(){
    SRStopCB();
}


void PSRCore::unittest_SRFailureCB(int failCode){
    SRFailureCB(failCode);
}


void PSRCore::unittest_SRSuccessCB(){
    SRSuccessCB(0);
}

void PSRCore::unittest_SRStatus(int status,int param){
    SRStatusCB(status,param);
    
}

void PSRCore::unittest_SRExceptinCB(){
    char tmp_string[128];
    sprintf(tmp_string, "test");
    SRExceptionCB(tmp_string);
}



int  PSRCore::unittest_SRinit(char *doc_dir, char *ini_file_name){
   return psr_init(doc_dir, ini_file_name);
}


char *PSRCore::unittest_getInspectionResult(){
    return getInspectionResult();
}

int PSRCore::unittest_PSRStart(char *rule){
    PSRCore instance = PSRCore::getInstance();
    return instance.psr_start(rule);
}


void PSRCore::unittest_PSRStop(){
    psr_stop();
}

void PSRCore::unnittest_PSRClose(){
    psr_close();
}

int PSRCore::unnittest_SetLogLevel(int level){
    return set_log_level(level);
}

void PSRCore::unittest_Call_alarm_NULL(){
    call_alarm(NULL);
}


int PSRCore::unittest_psr_open_dic(char *path){
    return psr_open_dic(path);
}

int PSRCore::unittest_psr_set_user(char *path){
    return psr_set_user(path);
}

const char *PSRCore::unittest_psr_get_user(){
    return psr_get_user();
}


void PSRCore::UT_PSR_Callback(unsigned long wParam, unsigned long lParam, void *pParam){
//    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
    
}
