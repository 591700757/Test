//
//  PSRCore.h
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#ifndef __VoiceDo__PSRCore__
#define __VoiceDo__PSRCore__




#include <mutex>
#include "PocketSRInterface.h"
#include <stdio.h>
#include <deque>
#include <string>

#define RANK 2

enum SRStatus { SRStartted = 0, SRStopped = 1,SRCBFailed = 2 };
static const char * SRStatusStrings[] = { "SRStartted", "SRStopped", "SRCBFailed" };

class PSRCore
{
public:
    static PSRCore &getInstance();


    SRStatus status;
    volatile bool test_engine_flag;
    int log_level;
    char current_rule[NAME_MAX];                                //認識中のルール
    
    int psr_start(char * rule);                                //指定ルールの認識開始
    int psr_stop();                                 //指定ルールの認識終了
    void psr_force_stop(void);                                            //前回のルールを強制停止
    void psr_stop_engine_lock_test(void);
    int psr_init(char *doc_dir,

    char *ini_file_name);//認識エンジン初期化
    void psr_close(void);                                       //認識エンジン停止
    void set_result_call(void (*func)(char *,bool));            //認識結果解析終了コールバック設置
    void set_log_call(void (*func)(std::string));                    //logコールバック
    void finish_inspection(char *result,bool successFlag);       //認識結果解析終了コールバックに解析結果を返す
    bool psr_isinitializing();                                      //初期化完了したか
    void psr_set_running_status(int flag);                          //0:rule stop 1:rule start 2:engine close
    int psr_runing_busy();
    //test

    void call_log(char *);                          //log設定
    void psr_test(const char *doc_dir);
    void set_alarm(void (*func)(std::string));
    void call_alarm(char *);
    void set_startCB(void(*func)(void));
    void set_stopCB(void (*func)(void));
    void set_stopNCB(void (*func)(void));
    void set_stopAudioCB(void (*func)(void));
//    void set_stopInspection
    int set_log_level(int);
    int get_log_level();
    
    void (*mStartCall)(void);                                   //ルール開始のコールバック
    void (*mStopNCall)(void);                                   //ルール停止のコールバック
    void (*mStopCall)(void);                                    //ルール停止後バックアップルール再開を行うコールバック
    void (*mStopAudioCall)(void);                  //ルールとAudioを停止するコールバックs
    void (*mAlarmCall)(std::string);
    void set_backup_rule(std::string );                   //バックアップルール設定
    std::string get_backup_rule();                       //バックアップルール取得
    void clear_backup_rule();                       //バックアップルールをクリア
    void writeaobuffer();
    int psr_open_dic(const char* dicFileName);                            //辞書を開く
    int psr_close_dic();                                                  //辞書を閉じる
    int psr_set_user(const char *usrName);                                 //ユーザーの設定切り替え
    const char *psr_get_user();
    void removePipe(char *p_doc_dir);
 //Unit test methods
    void unittest30();
    void unittest31();
    void unittest_srStartCB();
    void unittest_SRStopCB();
    void utcalllogNull();
    void unittest_SRFailureCB(int failCode);
    void unittest_SRSuccessCB();
    void unittest_SRStatus(int status,int param);
    void unittest_SRExceptinCB();
    int  unittest_SRinit(char *doc_dir, char *ini_file_name);
    char *unittest_getInspectionResult();
    int  unittest_PSRStart(char *rule);
    void unittest_PSRStop();
    void unnittest_PSRClose();
    int unnittest_SetLogLevel(int level);
    void unittest_Call_alarm_NULL();
    int unittest_psr_open_dic(char *path);
    int unittest_psr_set_user(char *path);
    const char *unittest_psr_get_user();
    
//Unit test PocketInterface methods
    void UT_PSR_Callback(unsigned long wParam, unsigned long lParam, void *pParam);
    
private:

    void (*mResultCall)(char *,bool);                               //結果通知コールバック
    void (*mLogCall)(std::string);                                        //log通知コールバック


    
};


#endif /* defined(__VoiceDo__PSRCore__) */
