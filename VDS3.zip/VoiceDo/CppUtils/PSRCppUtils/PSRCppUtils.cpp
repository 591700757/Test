//
//  PSRCppUtils.cpp
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#include "PSRCppUtils.h"
#include "logPrint.h"
#include <string.h>
#include <dirent.h>
#include <unistd.h>



PSRCppUtils &PSRCppUtils::getInstance()
{
    static PSRCppUtils *_instance = NULL;
    if (_instance == NULL) {
        _instance = new PSRCppUtils();
    }
    return (PSRCppUtils &)(*_instance);
}



// 半角数値を全角(SJIS)に直す
int PSRCppUtils::convertNumber2(
                   char *in,
                   char *out
                   )
{
    int i;
    long len = strlen(in);
    
    for(i = 0; i < len; i++){
        if(!isnumber(in[i])) return -1;
    }
    
    for(i = 0; i < len; i++){
        *(out++) = 0x82;
        *(out++) = 0x1F + *(in++);
    }
    *out = '\0';
    
    return 0;
}

// ゴミファイルの削除
void PSRCppUtils::removePipe(
                char *p_doc_dir
                )
{
    DIR *dir;
    dirent *result;
    char name[PATH_MAX];
    
    if((dir = opendir(p_doc_dir)) == NULL){
        log_printf("opendir error: %s", p_doc_dir);
        return;
    }
    
    while((result = readdir(dir))!= NULL){
        if(strncmp(result->d_name, "pipe_", 5) == 0){
            strncpy(name, p_doc_dir, PATH_MAX - 1);
            strncat(name, "/", PATH_MAX - strlen(name) - 1);
            strncat(name, result->d_name, PATH_MAX - strlen(name) - 1);
            unlink(name);
        }
    }
    closedir(dir);
}


//inline bool exists_test3 (const std::string& name) {
//struct stat buffer;
//return (stat (name.c_str(), &buffer) == 0);
//}
//// 設定ファイルの読み込み
//int readIniFile(
//                char *iniFile,
//                char *dicName,
//                char *modelName,
//                char *labelName0,
//                char *labelName1,
//                char *labelName2,
//                char *labelName3,
//                char *nextName,
//                char *retryName,
//                char *cancelName,
//                char *labelRule0,
//                char *labelRule1,
//                char *labelRule2,
//                char *labelRule3,
//                char *nextRule
//                )
//{
//    int ret = 0;
//    FILE *fp;
//    if((fp = fopen(iniFile, "r")) == NULL){
//        printf("Ini file open error: %s", iniFile);
////        NSLog(@"Ini file open error: %s", iniFile);
//        return -1;
//    }
//    
//    // 設定ファイルの中身の順番
//    // ルールはSJIS, それ以外はUTF8で格納
//    char *result[14] = {
//        dicName,
//        labelRule0,
//        labelRule1,
//        labelRule2,
//        labelRule3,
//        nextRule,
//        modelName,
//        labelName0,
//        labelName1,
//        labelName2,
//        labelName3,
//        nextName,
//        retryName,
//        cancelName
//    };
//    for(int i = 0; i < 14; i++){
//        if(fgets(result[i], PATH_MAX, fp) == 0){
//            ret = -1;
//            break;
//        }
//        char *p = strchr(result[i], '\n');
//        if(p!= NULL) *p = '\0';
//    }
//    
//    if(ret != -1){
//        // UTF8に変換
//        result[0] = dicName;
//        result[1] = modelName;
//        result[2] = labelName0;
//        result[3] = labelName1;
//        result[4] = labelName2;
//        result[5] = labelName3;
//        result[6] = nextName;
//        result[7] = retryName;
//        result[8] = cancelName;
//        for(int i = 0; i < 9; i++){
//            NSString *string = [NSString stringWithCString:result[i] encoding:NSShiftJISStringEncoding];
//            strncpy(result[i], (char *)[string UTF8String], PATH_MAX - 1);
//        }
//    }
//    fclose(fp);
//    
//    return ret;
//}

bool PSRCppUtils::exists_test2 (const std::string& name) {
    return ( access( name.c_str(), F_OK ) != -1 );
}

bool PSRCppUtils::get_file_existence (const std::string& name) {
    struct stat buffer;
    return (stat (name.c_str(), &buffer) == 0);
}

