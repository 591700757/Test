//
//  PSRCppUtils.h
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#ifndef __VoiceDo__PSRCppUtils__
#define __VoiceDo__PSRCppUtils__

#include <stdio.h>
#include <sys/stat.h>
#include <iostream>

class PSRCppUtils
{
public:
    static PSRCppUtils &getInstance();
    void removePipe(char *);
    int convertNumber2(char *,char *);
    bool get_file_existence (const std::string& name);
    bool exists_test2(const std::string& name);
};

#endif /* defined(__VoiceDo__PSRCppUtils__) */
