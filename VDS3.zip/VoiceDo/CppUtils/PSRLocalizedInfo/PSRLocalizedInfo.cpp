//
//  PSRLocalizedInfo.cpp
//  VoiceDo
//
//  Created by ying.zhang on 2016/02/24.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

#include "PSRLocalizedInfo.h"


PSRLocalizedInfo &PSRLocalizedInfo::getInstance()
{
    static PSRLocalizedInfo *_instance = NULL;
    if (_instance == NULL) {
        _instance = new PSRLocalizedInfo();
        
        
    }
    return (PSRLocalizedInfo &)(*_instance);
}