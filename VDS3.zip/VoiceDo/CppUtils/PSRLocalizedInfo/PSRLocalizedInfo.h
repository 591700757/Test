//
//  PSRLocalizedInfo.hpp
//  VoiceDo
//
//  Created by ying.zhang on 2016/02/24.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

#ifndef PSRLocalizedInfo_hpp
#define PSRLocalizedInfo_hpp
#define LOGCOUNTS  31
#include <stdio.h>
#include <iostream>




class PSRLocalizedInfo
{
public:
    static PSRLocalizedInfo &getInstance();
    char logMessages[LOGCOUNTS][BC_STRING_MAX];

    
};
#endif /* PSRLocalizedInfo_hpp */
