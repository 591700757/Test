
#ifndef _POCKETSRINTEFACE_PRIV_H
#define _POCKETSRINTEFACE_PRIV_H

#ifdef ENABLE_JNILOG
#include <android/log.h>
#define LOG_TAG "PocketSRInterface.cpp"
#define  LOGV(...)  __android_log_print(ANDROID_LOG_VERBOSE,LOG_TAG,__VA_ARGS__)
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGW(...)  __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define  LOGF(...)  __android_log_print(ANDROID_LOG_FATAL,LOG_TAG,__VA_ARGS__)
#else
#ifdef _IOSLOG // sakakit
#include "logPrint.h"
#define  LOGV(...)  log_printf(__VA_ARGS__)
#define  LOGD(...)  log_printf(__VA_ARGS__)
#define  LOGI(...)  log_printf(__VA_ARGS__)
#define  LOGW(...)  log_printf(__VA_ARGS__)
#define  LOGE(...)  log_printf(__VA_ARGS__)
#define  LOGF(...)  log_printf(__VA_ARGS__)
#else
#define  LOGV(...)  do {} while (0)
#define  LOGD(...)  do {} while (0)
#define  LOGI(...)  do {} while (0)
#define  LOGW(...)  do {} while (0)
#define  LOGE(...)  do {} while (0)
#define  LOGF(...)  do {} while (0)
#endif
#endif

#ifndef _IOS
namespace android {
#else
namespace iOS { 
#endif
    
/* Command Result */
enum recognizer_error_code {
    RECOGNIZER_RESULT_ERROR_NONE = 0,
    RECOGNIZER_RESULT_ERROR_PSR_AUDIOSTART, /* PSR_AudioStart error return */
    RECOGNIZER_RESULT_ERROR_PSR_REC_ACTIVATERULE, /* PSR_Rec_ActivateRule error return */
    RECOGNIZER_RESULT_ERROR_PSR_GRMOBJ_GETRESULT, /* PSR_GrmObj_GetResult error return */
    RECOGNIZER_RESULT_ERROR_PSR_REJECTJUDGE, /* PSR_RejectJudge error return */
    RECOGNIZER_RESULT_ERROR_PSR_GRMRES_GETNBESTSENT, /* PSR_GrmRes_GetNBestSent error return */
    RECOGNIZER_RESULT_ERROR_NOT_ENOUGH_MEMORY, /* Memory Allocation Error */
    RECOGNIZER_RESULT_ERROR_PSR_REC_DEACTIVATERULE, /* PSR_Rec_DeactivateRule error return */
    RECOGNIZER_RESULT_ERROR_PSR_AUDIOSTOP, /* PSR_AudioStop error return */
    RECOGNIZER_RESULT_ERROR_PSR_GRMOBJ_GETWORDHYOKI, /* PSR_GrmObj_GetWordHyoki error return */
    RECOGNIZER_RESULT_ERROR_PSR_NOISE
};


class PocketSRInterface
{
public:

    static PocketSRInterface* GetInstance(void);
    static void SetInitialValue(void);
#ifndef _IOS // sakakit
    int32_t Initialize();
#else
    int32_t Initialize(const char *TMP_NCS, const char *INI_FILE);
#endif
    void Finalize(void);

    int32_t Start(const char* dicRuleName);
    int32_t Stop(const char *ruleName);

    bool SetMaxWaveDataSize(int32_t bufferSize);
    bool WaveDataSet(void* waveData, int32_t size);

    int32_t OpenDic(const char* dicFileName);
    void CloseDic();

    int32_t AudioStart(void);
    void AudioStop(void);

    int32_t SetUser(const char *userName);
    const char *GetUser(void);

    int32_t GetResultInfo();
    int32_t GetResult(int32_t rank, char **output_str);

    void notifyRecognizeFailed(int32_t error_code);
    void notifyRecognizeException(char *message);

    void releaseMemoryAndObject(void);

#ifndef _IOS // sakakit
    int32_t  TrainInitialize(const char* userfilename);
#else
    int32_t TrainInitialize(const char* userfilename, const char* INI_FILE, const char* TRAIN_WAV);
#endif
    void TrainUninitialize();
    int32_t  TrainStart();
    int32_t  TrainRestart();
    int32_t  TrainSkip();
    int32_t  TrainCancel();
    int32_t  TrainSave();
    int32_t  TrainGetWord(char** ppHyoki, char** ppYomi);
#ifndef _IOS // sakakit
    int32_t  TrainDo();
#else
    int32_t  TrainDo(const char *TRAIN_WAV);
#endif

    void set_on_started_call(void (*func)(void));
    void set_on_stopped_call(void (*func)(void));
    void set_recognition_failure_call(void (*func)(int32_t failure_ret));
    void set_recognition_success_call(void (*func)(char *success_ret));
    void set_recognition_status_call(void (*func)(int32_t status, int32_t param));
    void set_exception_call(void (*func)(char *exception_ret));

    void (*mOnStartedCall)(void);
    void (*mOnStoppedCall)(void);
    void (*mRecognitionFailureCall)(int32_t failure_ret);
    void (*mRecognitionSuccessCall)(char *success_ret);
    void (*mStatusCall)(int32_t status, int32_t param);
    void (*mExceptionCall)(char *exception_ret);

    // for DEBUG
    void startRec(const char *filename);
    void stopRec(void);
    void startPlay(const char *filename);
    void stopPlay(void);
  private:
    int32_t mDataRec;
    int32_t mDataPlay;
};

}; /* namespace android */

#endif /* _POCKETSRINTEFACE_PRIV_H */

