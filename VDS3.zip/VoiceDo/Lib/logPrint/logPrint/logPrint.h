#ifndef _LOGPRINT_H_
#define _LOGPRINT_H_

#ifdef __cplusplus
extern "C" {
#endif

int log_printf(const char * __restrict format, ...);
int log_saveinfile(const char * __restrict format, ...);
const char * engine_dump_path();
const char *analysis_log_path();
const char *inspection_score_log_path();
void write_utf8_log(char *);
void send_log_to_UI(char *sslog);
const char * engine_dump_path2();
#ifdef __cplusplus
}
#endif

#endif
