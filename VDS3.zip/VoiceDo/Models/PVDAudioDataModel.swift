//
//  PVDAudioDataModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/03/01.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDAudioDataInfoList:Mappable{
    var items:[PVDAudioDataModel]?
    
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        items            <- map["items"]
    }
}




class PVDAudioDataModel: Mappable {
    
    var name:String?
//    var path:String?
    var uploadedflag:Bool
    var userFilePath:String?
    var dictFilePath:String?
    var audioFileDuration:Int?
    var rule:String?
    var audioStarttime:Double?

    
    
    required init?(map: Map) {
        uploadedflag = false
    }
    
    
    func mapping(map: Map) {
        name                <- map["filename"]
        uploadedflag        <- map["flag"]
        userFilePath        <- map["userfilePath"]
        dictFilePath        <- map["dicfilePath"]
        audioFileDuration   <- map["duration"]
        rule                <- map["currentRule"]
        audioStarttime      <- map["audioStarttime"]
    }

}
