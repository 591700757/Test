//
//  PVDCameraCmdListModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/13.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDCameraCmdListModel: Mappable {
    var itemlist:[PVDCameraCmdModel]?
    // MARK: Initialization
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        itemlist            <- map["control"]
    }
}
