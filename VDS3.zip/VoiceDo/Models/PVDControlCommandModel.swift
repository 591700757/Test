//
//  PVDControlCommandModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/05/20.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDControlCommandModel: Mappable {
    
    // MARK: Properties
    var wprev:String?               //前に戻る
    var wrepeat:String?             //もう一度
    var wnext:String?               //次へ進む
    var wexit:String?               //中断
    var wchange:String?             //交代
    var wbackhome:String?           //ホームへ戻る
    var wagain:String?              //次の作業開始
    var wcontinue:String?           //未完了再開
//    var wrecog_start:String?      //認識再開
//    var wrecog_end:String?        //認識一時停止
    var wwait:String?               //入力
    var wload:String?               //
    var wfinish:String?             //入力完了
    var wmove:String?               //移動
    var wmoveToUnfinished:String?   //未入力移動
    var wmoveToRequired:String?      //必須移動
    

    
    // MARK: Initialization
    required init?(map: Map) {
        wprev               = ""
        wrepeat             = ""
        wnext               = ""
        wexit               = ""
        wchange             = ""
        wbackhome           = ""
        wagain              = ""
        wcontinue           = ""
//        wrecog_start    = ""
//        wrecog_end      = ""
        wload               = ""
        wmoveToUnfinished   = ""
        wmoveToRequired     = ""
        
    }
    
    
    func mapping(map: Map) {
        wprev               <- map["prev"]
        wrepeat             <- map["repeat"]
        wnext               <- map["next"]
        wexit               <- map["exit"]
        wchange             <- map["change"]
        wbackhome           <- map["backhome"]
        wagain              <- map["again"]
        wcontinue           <- map["continue"]
//        wrecog_start    <- map["recog_start"]
//        wrecog_end      <- map["recog_stop"]
        wload               <- map["reload"]
        wwait               <- map["wwait"]
        wfinish             <- map["finish"]
        wmove               <- map["move"]
        wmoveToUnfinished   <- map["wmoveToUnfinished"]
        wmoveToRequired     <- map["wmoveToRequired"]
    }
    
}
