//
//  PVDControlModle.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/18.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

//認識画面のコントロール
class PVDControlModel: NSObject {
    struct PVDControlOption : OptionSet {
        let rawValue: Int
        //default イレギュラーの出力
        static let unknownType     = PVDControlOption(rawValue: 0)
        
        //戻る、前へ
        static let goBackType      = PVDControlOption(rawValue: 1)
        
        //次へ、スキップ
        static let goFowardType    = PVDControlOption(rawValue: 1 << 2)
        
        //完了
        static let finishedType    = PVDControlOption(rawValue: 1 << 3)
        
        //中断
        static let stopType        = PVDControlOption(rawValue: 1 << 4)
        
        //カメラ
        static let cameraType      = PVDControlOption(rawValue: 1<<5)
        
        //音声メモ
        static let voicememoType   = PVDControlOption(rawValue: 1<<6)
        
        //もう一度
        static let repeatType      = PVDControlOption(rawValue: 1<<7)
    }
    var name:String
    var ctype:PVDControlOption
    
    init?(namev: AnyObject?,
        ctypeStringv: AnyObject?) {
            // Initialize stored properties.
            name = PVDSwiftUtils.getSafeStringFromAnyObject(namev)
            let ctypeString = PVDSwiftUtils.getSafeStringFromAnyObject(ctypeStringv)
            switch ctypeString{
                case "100":
                    ctype = .goBackType
                    break
                case "101":
                    ctype = .goFowardType
                    break
                case "102":
                    ctype = .finishedType
                    break
                case "103":
                    ctype = .voicememoType
                    break
                case "104":
                    ctype = .cameraType
                    break
                case "105":
                    ctype = .stopType
                    break
                case "106":
                    ctype = .repeatType
                default:
                    ctype = .unknownType
                    print("未処理のコントロールタイプがファイルから読み込んだ")
                    break
                
            }
            
    }
}
