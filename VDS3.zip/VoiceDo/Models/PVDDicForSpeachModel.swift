//
//  PVDDicForSpeachModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/11/16.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import Foundation

class PVDDicForSpeachModel: NSObject {
    
    var word:String!
    var yomi:String!
    
    override init() {
        word = ""
        yomi = ""
    }
    
    init(tword:String,tyomi:String) {
        super.init()
        self.word = tword
        self.yomi = tyomi
    }

}
