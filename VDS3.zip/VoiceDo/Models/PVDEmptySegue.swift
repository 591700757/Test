//
//  PVDEmptySegue.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/17.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDEmptySegue: UIStoryboardSegue {

    override func perform(){
    
    }
 
}
