//
//  PVDEnvironmentModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/06/07.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDEnvironmentListModel: Mappable {
    // MARK: Properties
    var items:[PVDEnvironmentModel]?
    
    
    // MARK: Initialization
    required init?(map: Map) {
    }
    
    
    func mapping(map: Map) {
        items           <- map["environment"]
        
    }
}

class PVDEnvironmentModel: Mappable {
    // MARK: Properties
    var env_title:String?          
    var file_name:String?
    
    // MARK: Initialization
    required init?(map: Map) {
    }
    
    
    func mapping(map: Map) {
        env_title           <- map["env_title"]
        file_name           <- map["file_name"]
        
    }
}
