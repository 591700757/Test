//
//  PVDProcessModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/24.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDProcessItemModel: Mappable {
    var itemid:String?
    var itemname:String?
    var voiced_name:String?
    var itemType:String?
    var itemoption:[PVDProcessItemOptionModel]?
    var unit:String?
    var min_val:String?
    var max_val:String?
    var supplementary_guide:String?
    var condition:[PVDProcessConditionModel]?//複数の条件を保存できるようにしているが、げんじて見てるのは最初の条件
    var standarad_operation_time: String?
    var optional_flag:String?//true:非必須    false、ID、nil:必須
    var name_for_voice_recognition:String?
    var image:String?
    var ext:String?

    var photoArray:NSArray?
    var albumName:String?
    var clickFlag:Bool! = false
    var heightOfDiscriptionImage:CGFloat?

    var descriptionImgPath:String?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map){
        itemid                          <- map["id"]
        itemname                        <- map["name"]
        voiced_name                     <- map["voiced_name"]
        itemType                        <- map["type"]
        itemoption                      <- map["option"]
        unit                            <- map["unit"]
        min_val                         <- map["min_val"]
        max_val                         <- map["max_val"]
        supplementary_guide             <- map["supplementary_guide"]
        condition                       <- map["condition"]
        standarad_operation_time        <- map["standarad_operation_time"]
        optional_flag                   <- map["optional_flag"]
        name_for_voice_recognition      <- map["name_for_voice_recognition"]
        image                           <- map["image"]
        ext                             <- map["ext"]
    }
}

class PVDProcessConditionModel:Mappable{
    var itemid:String?                      //条件分岐対象のid
    var expression:String?                  //条件式
    
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        itemid                          <- map["item_id"]
        expression                      <- map["expression"]
    }
}
