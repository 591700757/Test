//
//  PVDProcessItemOptionModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/24.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDProcessItemOptionModel: Mappable {
    var optionid:String?
    var optionname:String?
    var voiced_name:[AnyObject]?
    
    
    required init?(map: Map ){
    
    }
    
    
    func mapping(map: Map){
        optionid    <- map["id"]
        optionname  <- map["name"]
        voiced_name <- map["voiced_name"]
    }
    
    
}
