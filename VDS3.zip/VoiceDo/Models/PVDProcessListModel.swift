//
//  PVDProcessingModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/18.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDProcessListModel: Mappable {
    var processid : String?
    var processname : String?
    var voiced_name : String?
    var creation_date : String?
    var auther : String?
    var category :NSArray?
    var processitems   :[PVDProcessItemModel]?
    var random_input:Int?
    
    required init?(map: Map){
    
    }
    
    func mapping(map : Map){
        processid               <- map["id"]
        processname             <- map["name"]
        voiced_name             <- map["voice_name"]
        creation_date           <- map["creation_date"]
        auther                  <- map["auther"]
        category                <- map["category"]
        processitems            <- map["items"]
        random_input            <- map["random_input"]
        
    }
}
