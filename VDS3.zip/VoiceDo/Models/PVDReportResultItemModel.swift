//
//  PVDReportResultItemModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/11/06.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDReportResultItemModel: Mappable {
    var id:String?
    var result:PVDReportResultItemResultModel?
    var item_operating_time:String?
    var item_user_name:String?
//    var item_start_timestamp:NSTimeInterval?//項目最新開始時間
//    var item_end_timestamp:NSTimeInterval?//項目最新終了時間
//    var item_time_for_addup:NSTimeInterval?//前回以前にこの項目に掛かった時間の合計
    
    
    // MARK: Initialization
    
    required init?(map: Map) {
    }
    
    
    func mapping(map: Map) {
        id                      <- map["id"]
        result                  <- map["result"]
        item_operating_time     <- map["item_operating_time"]
        item_user_name          <- map["item_user_name"]
        
    }

}
