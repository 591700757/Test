//
//  PVDReportResultModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/11/06.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper


class PVDReportResultModel: Mappable {
    var work_plan_id:String?
    var original_result_id:String?
    var device_id:String?
    var report_form_name:String?
    var report_form_id:String?
    var user_name:String?
    var start_time:String?
    var end_time:String?
    var operating_time:String?
    var items:[PVDReportResultItemModel]?
    var stopflag:Bool?
    var file_changed_time:String?
    var itemlist:[PVDCameraCmdModel]?
    var work_primary_id:String?
    // MARK: Initialization
    
    required init?(map: Map) {
        work_plan_id        = ""
        report_form_name    = ""
        user_name           = ""
        start_time          = ""
        end_time            = ""
        operating_time      = "00:00:00"
        stopflag            = false
        file_changed_time   = ""
    }
    
    
    func mapping(map: Map) {
        work_plan_id            <- map["work_plan_id"]
        report_form_name        <- map["report_form_name"]
        report_form_id          <- map["report_form_id"]
        user_name               <- map["user_name"]
        start_time              <- map["start_time"]
        end_time                <- map["end_time"]
        operating_time          <- map["operating_time"]
        items                   <- map["items"]
        device_id               <- map["device_id"]
        file_changed_time       <- map["file_changed_time"]
        work_primary_id         <- map["work_primary_id"]
        original_result_id      <- map["original_result_id"]
    }

}
