//
//  PVDSettingModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/11/16.
//  Updated by k.nagadimi on 2017/3/3.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDSettingModel: Mappable {
    
    
    
    var inspectionOnSpeech:String?          //発話の同時に認識開始
    var voiceDoChannel:String?              //1ch 2ch
//    var noiseReduceLevel:String?            //ノイズカット
    var siriSpeechRate:String?              //siri発話speed
    var choosedSpeaker:String?              //認識で使う話者名
    var choosedSpeakerfilePath:String?      //認識で使う話者ファイルのパス
    var cameraOff:String?                   //カメラ機能を隠す
    var ipAddress:String?                   //サーバーのIP
    var port:String?                        //サーバーのport
    var userid:String?                      //サーバーのアカウント
    var lastupdate:String?                  //最終的レポート更新時間
    var deviceid:String?                    //現在のデバイス番号
    var globalFontSize:CGFloat?             //変更可能の範囲(点検フォームとホームなと)のFont
    var globalDescriptionFontSize:CGFloat?  //変更可能の範囲(補助説明)のFont
    var workSharingFlag:Bool?               //応支援フラグ
    var workSharingGoOn:Bool?               //応支援アップロード後次の作業開始
// 2017.3.3 k.nagadomi iOS10 not working fix start
//    var workSharingArray:NSMutableArray?   //応支援引き継ぎ元列
    var workSharingArray:NSArray?            //応受援引き継ぎ元デバイス配列
// 2017.3.3 k.nagadomi iOS10 not working fix end
//    var workSharingLatestWorkId:String?      //応支援最後にアップロードしたレポート結果のwork plan id
    var workPlanId:String?                   //work plan idを保存する
    var workSharingTimeList:PVDworkSharingLastDownloadTimeModel?
    var inputScrolToTopFlag:Bool?             //true:テーブルtopまでscroll false:常に現在の項目の一つ上の項目が見えるscrollをする
    var audioFourceToUseBuildInSpeakerFlag:Bool?
    var systemSettingLocked:Bool?
    var tokenString:String?
    var logLevel:String?
    var serverPath:String?
//    var audioDumpList:PVDAudioDataInfoList?  //dumpfilelist
    var siriLangurage:String?
    var workSharingBackUpMax:Int?              //引き継ぎアップロードされた結果を複数個残る、その個数
    var statusLogFileName:String?
    var accessLogFileName:String?
    var showingModelViewflag:Bool?
    var engineLogEnable:Bool?
    var chosedEnv:String?                      //環境設定
    var envDetail:String?                      //騒音最適化の説明
    var autoUpload:Bool?                       //自動アップロード
    var unfinishedListOrder:Bool!              //false:新しい順->古い順  true:古い順->新しい順
    var unfinishedSortUpdated:Bool!                       //未完了ソート用にlasteditdateforsortを適応済み
    
    
    required init?(map: Map) {
        ipAddress = ""
        port = ""
        userid = ""
        serverPath = ""
        deviceid = ""
    }
    
    
    func mapping(map: Map) {
        inspectionOnSpeech                                      <- map["inspectionOnSpeech"]
        voiceDoChannel                                          <- map["voiceDoChannel"]
        siriSpeechRate                                          <- map["siriSpeechRate"]
        choosedSpeaker                                          <- map["choosedSpeaker"]
        choosedSpeakerfilePath                                  <- map["choosedSpeakerfilePath"]
        cameraOff                                               <- map["cameraOff"]
        ipAddress                                               <- map["ipAddress"]
        userid                                                  <- map["userid"]
        port                                                    <- map["port"]
        lastupdate                                              <- map["lastupdate"]
        deviceid                                                <- map["deviceid"]
        globalFontSize                                          <- map["globalFont"]
        workSharingFlag                                         <- map["workSharingFlag"]
        workSharingArray                                        <- map["workSharingArray"]
//        workSharingLatestWorkId                                 <- map["workSharingLatestWorkId"]
        workPlanId                                              <- map["workPlanId"]
        workSharingTimeList                                     <- map["workSharingTimeList"]
        workSharingGoOn                                         <- map["workSharingGoOn"]
        inputScrolToTopFlag                                     <- map["inputScrolToTopFlag"]
        audioFourceToUseBuildInSpeakerFlag                      <- map["audioFourceToUseBuildInSpeakerFlag"]
        systemSettingLocked                                     <- map["systemSettingLocked"]
        tokenString                                             <- map["tokenString"]
        logLevel                                                <- map["logLevel"]
        serverPath                                              <- map["serverPath"]
        siriLangurage                                           <- map["siriLangurage"]
        workSharingBackUpMax                                    <- map["workSharingBackUpMax"]
        engineLogEnable                                         <- map["engineLogEnable"]
        globalDescriptionFontSize                               <- map["globalDescriptionFontSize"]
        chosedEnv                                               <- map["chosedEnv"]
        envDetail                                               <- map["envDetail"]
        autoUpload                                              <- map["autoUpload"]
        unfinishedListOrder                                     <- map["unfinishedListOrder"]
        unfinishedSortUpdated                                   <- map["unfinishedSortUpdated"]
    }
    
}
