//
//  PVDShareDownloadListModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/03/31.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDShareDownloadListModel:Mappable{
    var items:[PVDShareDownloadRecordModel]?
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        items                      <- map["records"]
    }
    
    
    
}

class PVDShareDownloadRecordModel: Mappable {
    
    var original_result_id:String?
    var local_result_id:String?
    
    
   
    
    required init?(map: Map) {
        
    }
    

    func mapping(map: Map) {
        original_result_id                      <- map["original_result_id"]
        local_result_id                         <- map["local_result_id"]
    }
}
