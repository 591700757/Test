//
//  PVDUserModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/17.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDUserListModel:Mappable{
    var items:[PVDUserModel]?
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        items                      <- map["user"]
    }
    
    
    
}

class PVDUserModel: Mappable {

    var name:String?
    var userVoiceDataPath:String?
    var id:String?
    
    
    init?(namev: AnyObject?,
        userVoiceDataPathv: AnyObject?) {
            // Initialize stored properties.
            name = PVDSwiftUtils.getSafeStringFromAnyObject(namev)
            userVoiceDataPath = PVDSwiftUtils.getSafeStringFromAnyObject(userVoiceDataPathv)
    }
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        name                      <- map["name"]
        userVoiceDataPath         <- map["file"]
        id                        <- map["id"]
    }
}
