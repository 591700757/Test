//
//  PVDWaitingListModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/24.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper


class PVDWaitingListModel: Mappable {
    var waitingItems:[PVDWaitingModel]?
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        waitingItems         <-   map["list"]
    }
}
