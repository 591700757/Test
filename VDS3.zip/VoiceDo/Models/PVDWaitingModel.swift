//
//  PVDWaitingModel.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/11.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper

class PVDWaitingModel: Mappable {
    
    // MARK: Properties
//    var processid:String?
    var waitingTitle:String?
    var reportId:String?
    var workplanid:String?
    var lasteditDate:String?
    var lasteditDateForSort:TimeInterval?
    var work_primary_id:String?
    var work_sharing_uploaded:Bool?//引き継ぎアップロード実行済み
    var original_result_id:String?
    var auther : String?
    var category :NSArray?
    var creation_date : String?
    var voiced_name : String?
    var random_input:String?
    
    
    // MARK: Initialization
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        waitingTitle            <- map["name"]
        reportId                <- map["report_form_id"]
        lasteditDate            <- map["last_edit_time"]
        lasteditDateForSort     <- map["lasteditDateForSort"]
        workplanid              <- map["work_plan_id"]
        work_primary_id         <- map["work_primary_id"]
        work_sharing_uploaded   <- map["work_sharing_uploaded"]
        original_result_id      <- map["original_result_id"]
        auther                  <- map["auther"]
        category                <- map["category"]
        creation_date           <- map["creation_date"]
        voiced_name             <- map["voiced_name"]
        random_input            <- map["random_input"]
    }
    
}
