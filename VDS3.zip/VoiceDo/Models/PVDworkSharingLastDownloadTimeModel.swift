//
//  PVDDataLastUpdateTimeModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/03/02.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper



class PVDworkSharingLastDownloadTimeModel: Mappable {
    var items:[PVDworkSharingLastDownloadTimeItemModel]?                //1ch 2ch
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        items                                      <- map["items"]
    }
}


class PVDworkSharingLastDownloadTimeItemModel: Mappable {
    var deviceid:String?                            //発話の同時に認識開始
    var lastUpdatetimestamp:String?                 //1ch 2ch
    
    required init?(map: Map) {
        
    }
    
    
    func mapping(map: Map) {
        deviceid                                      <- map["deviceid"]
        lastUpdatetimestamp                           <- map["lastUpdatetimestamp"]
    }
}
