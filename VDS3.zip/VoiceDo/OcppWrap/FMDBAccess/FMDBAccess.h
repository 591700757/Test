//
//  FMDBAccess.h
//  VoiceDo
//
//  Created by ying.zhang on 2016/09/02.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FMDBAccess : NSObject

@end
