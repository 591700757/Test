//
//  PSRManager.h
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#ifndef __VoiceDo__PSRManager__
#define __VoiceDo__PSRManager__
#import <Foundation/Foundation.h>
#import "PSRSoundRec.h"
#import "psrconfig.h"


//wrapper
@interface PSRManager : NSObject
{
    void* _corepsrObj;    // C++クラスのインスタンスを参照するポインタ
   
//    void* _datapsrObj;    //ログメッセージインスタンス参照ポインタ
};

@property (nonatomic,strong)NSString *currentDictPath;//現在エンジンで使ってる辞書
@property (nonatomic,strong)NSString *currentUserPath;//現在使ってるユーザーのパス
@property (nonatomic,strong)NSString *currentDetail;//現在のルールの詳細(項目名)

@property (nonatomic,strong)NSString *lastRule;//前回開始したルール、認識再開用
@property (nonatomic,strong)NSString *lastDetail;

@property (nonatomic,strong)NSString *waitingRule;//入力待ち状態のルール
@property (nonatomic,strong)NSString *waitingDetail;//入力待ち状態での詳細

@property (nonatomic,strong)NSString *recogstopCommand;//認識一時停止コマンド
@property (nonatomic,strong)NSString *recogstartCommand;//認識再開コマンド



//@property (atomic,strong)NSString *backupRule;

//エンジン再起動用


//voice do
/**
 *  ボイス初期化
 *
 *  @param homeurl ファイル格納するためのフォルダーパス
 *  @param userUrl      話者ファイルパス
 *  @param iniUrl       設定ファイルパス
 *  @param dicUrl       辞書ファイルパス
 */
-(int)voicedoInit:(NSString *)homeurl
//          userUrl:(NSString *)userUrl
           iniUrl:(NSString *)iniUrl
//           dicUrl:(NSString *)dicUrl
;





/**
 *  認識開始
 *
 *  @param rule 認識ルール文字列
 */
-(int)voicedoStartInspection:(NSString *)trule  detail:(NSString *)tdetail;


-(int)voicedoStartInspectionWithOutRecordStart:(NSString *)rule;



/**
 *  認識停止
 *
 *  @param rule 認識ルール文字列
 */
-(void)voicedoStopInspection;

-(void)voicedoSetLogLevel:(int)level;



-(int)voicedoGetLogLevel;
/**
 *  認識強制停止
 */
//-(void)voicedoForceStopInspection;

/**
 *  エンジン停止
 */
-(void)voicedoClose;

//security method
-(NSString *)getMD5ByString:(NSString *)source;

//audio methods
/**
 *  changeChannelType 1ch<->2ch
 *
 *  @param psrctype channel type
 */
-(void)changeChannelType:(PSRChannelType)psrctype;
-(void)finalizeAudioQueue;











+(void)setNoiseLevel:(float)twhiteAmp;
+(void)setEngineLogAndRaw:(bool)flag;


-(void)audioUseBuildInSpeaker;

-(void)audioUseHeadPhotoSpeaker;

+(void)sendLogTextAsync:(NSDictionary *)messageDict;
+(void)sendLogTextAsyncZ:(NSString *)message;
+(void)writeInspectionLog:(NSString *)logString;
+(void)writeLogToFile:(NSString *)logString filePath:(NSString *)filePath;
+(void)removeEngineLogAndRawFile;
//Sound Record
@property (strong,nonatomic)PSRSoundRec *recordManager;


+(id)shareInstance;



//test
-(void)test;    // このメソッドをSwiftから呼べて、内部でC++コードが動けばOK、とする
+(void)test;


/**
 *  エンジンの今設定中のユーザを取得
 *
 *  @return 設定したユーザ
 */
-(NSString *)voicedoGetUser;

/**
 *  ユーザー設定
 *
 *  @param userPath ユーザのパス
 *
 *  @return ユーザー設定の結果 0 :成功　 else:失敗
 */
-(int)voicedoSetUser:(NSString *)userPath;

/**
 *  辞書設定
 *
 *  @param dicFileName 辞書のパス
 *
 *  @return 辞書設定の結果
 */
-(int)voicedoOpenDic:(NSString *)dicFileName;


/**
 *  辞書を閉じる
 *
 *  @return 辞書閉じる操作の結果
 */
-(int)voicedoCloseDic;


/**
 *  辞書を変え、ユーザを変え
 *
 *  @param closeDic    辞書を変える、新しく設定するのを区別するフラグ
 *  @param speakerPath 話者
 *  @param dicPath     辞書
 *
 *  @return 設定結果
 */
-(int)voicedoChangeUserAndDic:(BOOL)closeDic speakerPath:(NSString *)speakerPath dicPath:(NSString *)dicPath  showMessage:(BOOL)showMessage;


//UNIT TEST用:
-(BOOL)stopSoundRecord:(NSNotification *)stopSoundRecord;



-(BOOL)isHeadsetPluggedIn;


-(void)setbackupRule:(NSString *)crule;


-(void)UT_PSRManager30;
-(void)UT_PSRManager31;
-(void)ut_CallLog:(NSString *)logString;
-(void)ut_CallLogNull;
-(void)ut_SRStart;
-(void)ut_SRStop;
-(void)ut_SRFailure:(int)failureCode;
-(void)ut_SRSuccess;
-(int)psr_runing_busy;
-(void)unittest_SRStatus:(int)status param:(int)param;
-(void)unittest_SRException;
-(int)unittest_SRInitTest:(NSString *)doc_dir inifile:(NSString *)inifile;
-(NSString *)unittest_getInspectionResult;
-(int)unittest_PSRStart:(NSString *)rule;
-(void)unittest_psrstop;
-(void)unittest_PSRClose;
-(int)unnittest_SetLogLevel:(int)level;
-(void)unittest_call_alarm_Null;
-(int)unittest_psr_open_dic:(NSString *)filepath;
-(int)unittest_psr_set_user:(NSString *)filepath;
-(NSString *)unittest_psr_get_user;

-(NSString *)getbackupRule;
-(NSString *)getcurrentRule;
@end






#endif /* defined(__VoiceDo__PSRCore__) */
