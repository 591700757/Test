//
//  PSRManager.cpp
//  VoiceDo
//
//  Created by user2 on 2015/09/09.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#include "PSRManager.h"
#include <cstddef>
#include <vector>
#include <iostream>
#include "PocketSRInterface.h"
#include "PSRCore.h"
#import  "SVProgressHUD.h"
#import  <AudioToolbox/AudioServices.h>
#import  "CocoaSecurity.h"
#include "PSRLocalizedInfo.h"
#import  "VoiceDo-Swift.h"

//#include "VoiceDo-swift.h"
//#include "PSRSoundRec.h"
extern float whiteAmp;  // PocketSRで定義 ,ノイズ関連
extern bool  thread_fan_enableraw;//rawログを出す
extern bool  threadmt_scorelog;
extern bool  threadfan_analysis_log_on;
extern bool  pocketfan_score_log_on;
extern bool  threadfan_score_log_on;
extern bool  log_print_engine_log_on;
extern char  logbuglog_path[];
extern char  engine_dumpraw_path[];
extern char  inpection_score_path[];
extern char  engine_analysis_path[];

//fortest

static NSTimeInterval lastStartInspectionTime;
//static BOOL isStarted;
static int inspectionStartedCnt;


@implementation PSRManager

-(id)init {
    self = [super init];
    
    if (self) {
        _corepsrObj = &PSRCore::getInstance();
        

        _recordManager = [PSRSoundRec shareInstance];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(voicedoRestartRuleAction:) name:kRestartVoiceDoRuleNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopSoundRecord:) name:kStopSoundRecordNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startBackupRule:) name:kStartBackupRuleNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stopInspectionAction:) name:kStopInspectionNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startWaitingRuleAction:) name:kStartWaitingRuleNotification object:nil];
        
        inspectionStartedCnt = 0;
        
    }
    
    return self;
}



+(id)shareInstance{
    NSString *uxxx058 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-058", nil)];
    static PSRManager *shareInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareInstance = [[self alloc] init];
        PSRLocalizedInfo& obj = *reinterpret_cast<PSRLocalizedInfo*>(&PSRLocalizedInfo::getInstance());
        for(int i = 1; i < LOGCOUNTS; i++){
            NSString *logName = [NSString stringWithFormat:@"logMessage%d",i];
            if([[NSString alloc] initWithFormat:NSLocalizedString(logName, nil)] != NULL){
                sprintf(obj.logMessages[i], "%s",[[[NSString alloc] initWithFormat:NSLocalizedString(logName, nil)] UTF8String]);
            }else{
                sprintf(obj.logMessages[i], "[%d]%s",i,[uxxx058 UTF8String]);
                dispatch_async(dispatch_get_main_queue(), ^{
                    [SVProgressHUD showErrorWithStatus:uxxx058];
                });
            }
            
        }

    });
    
    return shareInstance;
}

-(void)dealloc {
    
    delete static_cast<PSRCore*>(_corepsrObj);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kRestartVoiceDoRuleNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kStopSoundRecordNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kStartBackupRuleNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kStopInspectionNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kStartWaitingRuleNotification object:nil];
}

#pragma mark - voicedo class methods
/**
 *  ステータスボードで状態を出す
 *
 *  @param message 
 */
+(void)sendLogTextAsync:(NSDictionary *)messageDict{
    [[NSNotificationCenter defaultCenter] postNotificationName:kSetLogTextNotification object:nil userInfo:messageDict];

}

+(void)sendLogTextAsyncZ:(NSString *)message{
    if(message == nil){
        NSLog(@"try to send nil message");
        return ;
    }
    if([[self shareInstance] voicedoGetLogLevel] > 0){
        [[NSNotificationCenter defaultCenter] postNotificationName:kSetLogTextNotification object:nil userInfo:@{kLogViewKey:message}];
    }
    
    
}



/**
 *  アプリ側のログ記録関数
 *
 *  @param logString <#logString description#>
 */
+(void)writeInspectionLog:(NSString *)logString{
    NSDate *date = [NSDate date];
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierJapanese];
    NSDateComponents *comps = [calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitNanosecond) fromDate:date];
    
    
    NSString *logFolder = [NSHomeDirectory() stringByAppendingPathComponent:kInspectionLogFolder];
    NSString *logFullPath = [NSString stringWithFormat:@"%@/%ld_%ld_%ld.txt",logFolder,(long)comps.year,(long)comps.month,(long)comps.day];
    NSString *logHeader = [NSString stringWithFormat:@"%ld:%ld:%ld.%ld :",(long)comps.hour,(long)comps.minute,(long)comps.second,(long)comps.nanosecond];
    
    if([[NSFileManager defaultManager] fileExistsAtPath:[NSHomeDirectory() stringByAppendingPathComponent:logFolder]] == false){
        [[NSFileManager defaultManager] createDirectoryAtPath:logFolder withIntermediateDirectories:true attributes:nil error:nil];
    }
    NSString *logStringWithTime = [NSString stringWithFormat:@"%@%@\n",logHeader,logString];
//    NSLog(@"%@",[NSString stringWithFormat:@"%@%@\n",logHeader,logString]);
    [PSRManager writeLogToFile:logStringWithTime filePath:logFullPath];
    
}

/**
 *  ログを記録
 *
 *  @param logString <#logString description#>
 *  @param filePath  <#filePath description#>
 */
+(void)writeLogToFile:(NSString *)logString filePath:(NSString *)filePath{
    @autoreleasepool {
        if([logString lengthOfBytesUsingEncoding:NSUTF8StringEncoding] == 0){
            NSLog(@"try to write log with no message");
            return ;
        }
        
        NSLog(@"%@",logString);
        
        
        NSData *logData = [logString dataUsingEncoding:NSUTF8StringEncoding];
        if([[NSFileManager defaultManager] fileExistsAtPath:filePath] == false){
            [[NSFileManager  defaultManager] createFileAtPath:filePath contents:logData attributes:nil];
            return ;
        }
        
        NSFileHandle *filehandle = [NSFileHandle fileHandleForWritingAtPath:filePath];
        [filehandle seekToEndOfFile];
        [filehandle writeData:logData];
        [filehandle closeFile];
    }
}



#pragma mark - voice do engine manager methods
-(int)voicedoChangeUserAndDic:(BOOL)closeDic speakerPath:(NSString *)speakerPath dicPath:(NSString *)dicPath showMessage:(BOOL)showMessage{
    NSString *uxxx049 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-049", nil)];
    NSString *uxxx050 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-050", nil)];
    NSString *uxxx051 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-051", nil)];
    NSString *uxxx052 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-052", nil)];

    
    int ret = -1;
    if([[NSFileManager defaultManager] fileExistsAtPath:speakerPath] == false){
        if(showMessage == true){
            dispatch_async(dispatch_get_main_queue(), ^{
                [SVProgressHUD showErrorWithStatus:uxxx052];
            });
        }

        return ret;
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:dicPath] == false){

        return ret;
    }
    
    if((ret = [self voicedoSetUser:speakerPath]) != 0){
        if(showMessage == true){
            dispatch_async(dispatch_get_main_queue(), ^{
                [SVProgressHUD showErrorWithStatus:uxxx049];
            });
        }
        
        
        return ret;
    }
    if(closeDic == true){
        if((ret = [self voicedoCloseDic]) != 0){
            if(showMessage == true){
                dispatch_async(dispatch_get_main_queue(), ^{
                    [SVProgressHUD showErrorWithStatus:uxxx050];
                });
            }
            return ret;
        }
    }
    
    if((ret = [self voicedoOpenDic:dicPath]) != 0){
        if(showMessage == true){
            dispatch_async(dispatch_get_main_queue(), ^{
                [SVProgressHUD showErrorWithStatus:uxxx051];
            });
        }

        return ret;
    }
    
    return 0;
    
}




-(int)voicedoOpenDic:(NSString *)dicFileName{
    NSString *uxxx055 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-055", nil)];
    int ret = -1;
    if(dicFileName == nil){
        return ret;
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:dicFileName] == false){
        return ret;
    }
    
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    ret = obj.psr_open_dic([dicFileName UTF8String]);
    if(ret == 0){
        NSArray *tmpArray = [dicFileName componentsSeparatedByString:@"/"];
        if(tmpArray.count > 1){
            self.currentDictPath = tmpArray[tmpArray.count - 1];
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                [SVProgressHUD showErrorWithStatus:uxxx055];
            });
        }
        
        ret = 0;
        NSLog(@"voicedoOpenDic:%@ success",dicFileName);
    }else{
        NSLog(@"voicedoOpenDic:%@ failed",dicFileName);
    }
    
    return ret;
}

-(int)voicedoCloseDic{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    self.currentDictPath = @"";
    return obj.psr_close_dic();
}


-(int)voicedoSetUser:(NSString *)userPath{
    NSString *uxxx056 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-056", nil)];
    if(userPath == nil){
        return -1;
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:userPath] == false){
        return -1;
    }
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    int ret = obj.psr_set_user([userPath UTF8String]);
    if(ret == 0){
        NSArray *tmpArray = [userPath componentsSeparatedByString:@"/"];
        if(tmpArray.count > 1){
            self.currentUserPath = tmpArray[tmpArray.count - 1];
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                [SVProgressHUD showErrorWithStatus:uxxx056];
            });
        }
    }
    return ret;
}



-(NSString *)voicedoGetUser{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    const char *retUser = obj.psr_get_user();
    if(retUser == NULL){
        //ユーザ取得失敗
        return NULL;
    }
    NSData *sjisData = [NSData dataWithBytes:retUser length:strlen(retUser)];
    // 対象のNSDataがsjisコードであることを指定してNSStringを作成
    NSString *nsString = [[NSString alloc] initWithData:sjisData encoding:NSShiftJISStringEncoding ];
    return nsString;
}


-(int)voicedoInit:(NSString *)homeurl
           iniUrl:(NSString *)iniUrl
{
    if((homeurl == nil)||(homeurl == NULL)||([[NSFileManager defaultManager] fileExistsAtPath:homeurl] == false)){
        return -1;
    }
    if((iniUrl == nil)||(iniUrl == NULL)||([[NSFileManager defaultManager] fileExistsAtPath:iniUrl] == false)){
        return -1;
    }
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
 
    char homeDir[PATH_MAX];

    char iniDir[PATH_MAX];
    
    char docDir[PATH_MAX];
    
    sprintf(homeDir, "%s",[homeurl UTF8String]);

    sprintf(iniDir, "%s",[iniUrl UTF8String]);
    
    sprintf(docDir, "%s",[[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/"] UTF8String]);

    [[NSUserDefaults standardUserDefaults] setObject:@"initing" forKey:kInitFlagKey];
    [[NSUserDefaults standardUserDefaults]  synchronize];
    
    obj.removePipe(docDir);
    int initFlag = obj.psr_init(homeDir,iniDir);


    [[NSUserDefaults standardUserDefaults] setObject:@"done" forKey:kInitFlagKey];
    [[NSUserDefaults standardUserDefaults]  synchronize];
    
    
    //認識結果コールバック設置
    auto resultfunc =  [](char *result,bool success) {

        NSString *result_ns2 =[PSRManager getResultFromBase:result];
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"結果受け取り:func:%s,result_ns2:%@",__FUNCTION__,result_ns2]];
        NSRange range = [result_ns2 rangeOfString:@"不要語"];
        NSString *onWait = [[NSUserDefaults standardUserDefaults] objectForKey:@kHVDWaitModeOnFlagKey];
        NSString *waitKeyWord = [[NSUserDefaults standardUserDefaults] objectForKey:kHVDWaitBindKey];
        [[NSUserDefaults standardUserDefaults] setObject:result_ns2 forKey:kResultKey];
        [[NSUserDefaults standardUserDefaults] synchronize];
        //ログに出す
        [[NSNotificationCenter defaultCenter] postNotificationName:kAudioDumpResultNotification object:nil userInfo:@{kResultKey:result_ns2}];
        
        //不要語チェック
        if (range.location != NSNotFound) {
            //不要語、リトライ
            NSString *audioDumpModel = [[NSUserDefaults standardUserDefaults] objectForKey:kAudioDumpModeKey];
            if([audioDumpModel isEqualToString:@"on"] == false){
                [[NSNotificationCenter defaultCenter] postNotificationName:kRestartVoiceDoRuleNotification object:@{kResultKey:result_ns2}];
            }
            if([onWait isEqualToString:@"true"] == true){
                [PVDSwiftUtils showInfoWithColor:[UIColor colorWithRed:0.118 green:0.565 blue:1.0 alpha:1] message:[NSString stringWithFormat:@"最初に「%@」と発話してください",waitKeyWord]];
            }
            return ;
            
        }
        
        //不要語以外且つ認識コントロールコマンド以外は録音を停止して認識結果を通知する
        [[NSNotificationCenter defaultCenter] postNotificationName:kStopInspectionNotification object:nil userInfo:nil];//ルール停止

        
        NSArray *resultArray = [result_ns2 componentsSeparatedByString:@","];
        
        
        
        if([onWait isEqualToString:@"true"] == true){
            if((resultArray.count >= 2)&&([resultArray[0] isEqualToString:waitKeyWord] == true)&&([resultArray[1] isEqualToString:@"制御語"] == true)){
                //入力待ち状態を解除して
                [[NSUserDefaults standardUserDefaults] setObject:@"false" forKey:@kHVDWaitingFlagKey];
                [[NSUserDefaults standardUserDefaults] synchronize];
                dispatch_async(dispatch_get_main_queue(),^{
                    // ここに実行したいコード
                    NSLog(@"ring system sound");
                    AudioServicesPlaySystemSound (1256);
                    
                });
                //入力待ちルールを開始する
                [[NSNotificationCenter defaultCenter] postNotificationName:kStartWaitingRuleNotification object:nil];
                return ;
            }else{
                [PSRManager sendLogTextAsync:@{kLogViewKey:@"入力待ち中です"}];
            }
        }
        
        
        
        if((resultArray.count >= 2)&&([resultArray[0] isEqualToString:waitKeyWord] == true)&&([resultArray[1] isEqualToString:@"制御語"] == true)){

            //音を鳴らす
            if([onWait isEqualToString:@"true"] == true){
                
            }


            
            
        }


        [[NSUserDefaults standardUserDefaults] setObject:@"true" forKey:@kHVDWaitingFlagKey];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [[NSNotificationCenter defaultCenter] postNotificationName:kReceivedInpectionResultNotification object:nil userInfo:@{kResultKey:result_ns2}];//認識成功

    };
    
    //ログコールバック
    obj.set_result_call(resultfunc);
    
    auto logfunc = [](std::string logstring){
        if((logstring.empty() == false)&&(logstring.length() != 0)){
            NSString *nsString = [NSString stringWithUTF8String:logstring.c_str()];
            if(nsString == nil){
                dispatch_async(dispatch_get_main_queue(), ^{
                    [SVProgressHUD showErrorWithStatus:@"ログ出力失敗:空のメッセージです"];
                });
                return ;
            }
            [PSRManager sendLogTextAsync:@{kLogViewKey:nsString}];
            NSLog(@"%@",nsString);
#ifdef kLogInspection
            if([[NSString stringWithUTF8String:logstring.c_str()] isEqualToString:@"音声の終端確定"]){
                lastStartInspectionTime = [[NSDate date] timeIntervalSince1970];
            }
#endif
        }else{
            NSLog(@"log found null in log func");
        }
    };
    obj.set_log_call(logfunc);
    
    //アラムを出す
    auto alarmfunc = [](std::string logstring){
//        NSData *sjisData = [NSData dataWithBytes:logstring.c_str() length:strlen(logstring.c_str())];
        // 対象のNSDataがsjisコードであることを指定してNSStringを作成
        NSString *nsString = [NSString stringWithUTF8String:logstring.c_str()];
        if(nsString == nil){
            dispatch_async(dispatch_get_main_queue(), ^{
                [SVProgressHUD showErrorWithStatus:@"アラム出力失敗:空のメッセージです"];
            });
            
            return ;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD showInfoWithStatus:nsString];
        });
        

        
    };
    obj.set_alarm(alarmfunc);
    

    
    
    //バックアップルール適用するためのstop callback
    auto stopfunc = [](){//stop callback->start new rule
         [[NSNotificationCenter defaultCenter] postNotificationName:kStartBackupRuleNotification object:nil userInfo:nil];
        
        
    };
    obj.set_stopCB(stopfunc);
    
    auto stopAudiofunc = [](){//stop audio and rule
        [[NSNotificationCenter defaultCenter] postNotificationName:kStopSoundRecordNotification object:nil userInfo:nil];
        
    };
    obj.set_stopAudioCB(stopAudiofunc);
    
    //
    auto startfunc = [](void){
        [[NSNotificationCenter defaultCenter] postNotificationName:kStartInspectionCallbackNotification object:nil userInfo:nil];
        
        
    };
    
    obj.set_startCB(startfunc);
    //stopcvが実行されたコールバック
    auto stopnfunc = [](void){
        [[NSNotificationCenter defaultCenter] postNotificationName:kStopInspectionCallbackNotification object:nil];
    };
    obj.set_stopNCB(stopnfunc);
    
    
    return initFlag;
}












-(void)voicedoRestartRuleAction:(NSNotification *)notification{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,backupRule:%s,currentRule:%s",__FUNCTION__,obj.get_backup_rule().c_str(),obj.current_rule]];
    }
    
    if(obj.get_backup_rule().empty() == true){
        obj.set_backup_rule(std::string(obj.current_rule));
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,backupRule:%s,back up rule is set",__FUNCTION__,obj.get_backup_rule().c_str()]];
        
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:kStopInspectionNotification object:nil userInfo:notification.userInfo];//ルール停止
    
    
}


-(void)voicedoSetLogLevel:(int)level{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.log_level = level;
}


-(int)voicedoGetLogLevel{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    return obj.log_level;
}

-(BOOL)stopSoundRecord:(NSNotification *)stopSoundRecord{

    if([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceAllDump]){
        return [_recordManager stopWithFile:NO];
    }else if([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceChoosedDump]){
        return [_recordManager stopWithFile:YES];
    }else{
        return [_recordManager stop];
    }
}
/**
 *  バックアップルールを開始する
 *
 *  @param notification 通知内容
 */
-(void)startBackupRule:(NSNotification *)notification{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s start],g_backup_rule:%s,currentRule:%s",__FUNCTION__,obj.get_backup_rule().c_str(),obj.current_rule]];
    }
    
    if(obj.get_backup_rule().empty() != true){
        NSString *tmpBackupRule = [NSString stringWithUTF8String:obj.get_backup_rule().c_str()];
        obj.clear_backup_rule();
        //account_report_rule
        [self voicedoStartInspection:tmpBackupRule detail:_lastDetail];
    }
    
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s end],g_backup_rule:%s,currentRule:%s",__FUNCTION__,obj.get_backup_rule().c_str(),obj.current_rule]];
    }
    
}

-(void)stopInspectionAction:(NSNotification *)notification{

    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s start],current rule:%s stoped by notification",__FUNCTION__,obj.current_rule]];
    }
    int ret = obj.psr_stop();//ルール停止通知でルール停止
    if(ret == -1){
        [SVProgressHUD showInfoWithStatus:@"ルール停止失敗"];
    }
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s end],current rule:%s stoped by notification",__FUNCTION__,obj.current_rule]];
    }
    
}

-(void)startWaitingRuleAction:(NSNotification *)notification{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s start],current rule:%s ，_waitingRule:%@",__FUNCTION__,obj.current_rule,_waitingRule]];
    }
    if(_waitingRule != NULL){
        [self voicedoStartInspection:_waitingRule detail:_waitingDetail];
        _waitingRule = NULL;
        _waitingDetail = NULL;
    }else{
        NSLog(@"error:waiting rule is null while try to start waiting rule");
    }
}






-(int)voicedoStartInspection:(NSString *)trule  detail:(NSString *)tdetail{
    NSString *crule = trule;
    NSString *cdetail = tdetail;
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    
    
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s start],isbusy(read):%d,g_backup_rule:%s,current rule:%s,rule to start:%@,detail:%@",
                                        __FUNCTION__,obj.psr_runing_busy(),obj.get_backup_rule().c_str(),obj.current_rule,crule,cdetail]];
    }
    NSString *onWait = [[NSUserDefaults standardUserDefaults] objectForKey:@kHVDWaitModeOnFlagKey];
    NSString *waitFlag = [[NSUserDefaults standardUserDefaults] objectForKey:@kHVDWaitingFlagKey];
    //Hey Voicedo機能
    if([onWait isEqualToString:@"true"]&&[waitFlag isEqualToString:@"true"]){//入力待ちモード+「入力」待ち
        crule = @"wait_keyword";
        cdetail = @"入力待ちモード";
        if([trule isEqualToString:@"wait_keyword"] == false){
            
            _waitingRule = trule;
            _waitingDetail = tdetail;
        }else{
            NSLog(@"try to set waitKeyWord to waiting Rule");
        }

    }
    //Hey Voicedo機能
    NSString *uxxx060 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-060", nil)];
    if(crule == nil){
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD showErrorWithStatus:@"rule is null"];
        });
        return -1;
    }

    int ruleStart = -1;
    
    _lastRule = crule;
    _lastDetail = cdetail;


    if(obj.psr_runing_busy() == 0){//認識停止中で正常開始
        if(obj.log_level > 0){
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s ] running flag is not busy",__FUNCTION__]];
        }
        
        NSString *forcetoBuildIn = [[NSUserDefaults standardUserDefaults] objectForKey:kForceToUseBuildInSpeeakKey];
        if([forcetoBuildIn isEqualToString:@"true"]){
            NSLog(@"force to use build in speaker");
            [_recordManager audioUseHeadPhotoSpeaker];
        }
        self.currentDetail = cdetail;
        //Audio Dumpを残すう場合
        if([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceAllDump]){//全ての認識にAudioDumpを残す
            [_recordManager recordWithFile:cdetail rule:crule currentDict:self.currentDictPath userPath:self.currentUserPath chosedDumpMode:NO];
        }else if([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceChoosedDump]){//ボタンタップでAudioDumpを残す
            [_recordManager recordWithFile:cdetail rule:crule currentDict:self.currentDictPath userPath:self.currentUserPath chosedDumpMode:YES];
        }else{//Audio Dumpを残さない
            [_recordManager record];
        }
        //ルール開始
        if(obj.psr_start((char *)[crule UTF8String]) != 0){//ルール開始失敗
            //Audioを止める
            if([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceAllDump]){
                [_recordManager stopWithFile:NO];
            }else if([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceChoosedDump]){
                [_recordManager stopWithFile:YES];
            }else{
                [_recordManager stop];
            }
            //update running state to rule stop
            obj.psr_set_running_status(0);
            dispatch_async(dispatch_get_main_queue(), ^{
                [PSRManager writeInspectionLog:uxxx060];
            });
        }else{
            //update running state to rule start
            obj.psr_set_running_status(1);
            ruleStart = 0;
        }
    }else if(obj.psr_runing_busy() == 1){//認識未停止での開始=>バックアップルール設定
        if(obj.log_level > 0){
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s ] running flag is  busy",__FUNCTION__]];
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s ] back up rule is set",__FUNCTION__]];
        }
        
        if(obj.get_backup_rule().empty() == true){
            
            obj.set_backup_rule(std::string([crule UTF8String]));
            printf("back up is set to %s",obj.get_backup_rule().c_str());
            [self voicedoStopInspection];//バックアップルールを反映するための停止、停止前の結果(ファイルへ保存用の物)はないと見なす
        }else{
            obj.set_backup_rule(std::string([crule UTF8String]));
        }
        
    }else{
        _lastDetail = @"engine closing";
        dispatch_async(dispatch_get_main_queue(), ^{
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s] engine closing",__FUNCTION__]];
        });
    }
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s end],isbusy(read):%d,g_backup_rule:%s,current rule:%s,rule to start:%@,detail:%@",__FUNCTION__,obj.psr_runing_busy(),obj.get_backup_rule().c_str(),obj.current_rule,crule,cdetail]];
    }
    return ruleStart;
}

/**
 *  Audio再生の時に使うルール開始
 *
 *  @param rule 認識ルール
 */
-(int)voicedoStartInspectionWithOutRecordStart:(NSString *)rule{
    printf("start rule:%s",[rule UTF8String]);
    int ret = -1;
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.psr_runing_busy() == false){//認識停止中で正常開始
        obj.psr_set_running_status(1);
        ret  = obj.psr_start((char *)[rule UTF8String]);
    }else{
        ret = -2;
    }
    return  ret;
}


-(void)voicedoStopInspection{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s start] g_backup_rule:%s,current rule:%s",__FUNCTION__,obj.get_backup_rule().c_str(),obj.current_rule]];
    }
    int ret = obj.psr_stop();//マニュアルできにルールを停止する
    if(ret == -1){
        [SVProgressHUD showInfoWithStatus:@"ルール停止失敗"];
    }
    if(obj.log_level > 0){
        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"[func:%s end] g_backup_rule:%s,current rule:%s",__FUNCTION__,obj.get_backup_rule().c_str(),obj.current_rule]];
    }
}







-(void)voicedoClose{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.psr_close();
    
    
}


-(void)finalizeAudioQueue{
    [_recordManager finalizeQueue];
}




-(void)audioUseHeadPhotoSpeaker{
    [_recordManager audioUseHeadPhotoSpeaker];
}
-(void)audioUseBuildInSpeaker{
    [_recordManager audioUseBuildInSpeaker];
}


-(BOOL)isHeadsetPluggedIn{
    return [_recordManager isHeadsetPluggedIn];
}


#pragma mark - security methods
-(NSString *)getMD5ByString:(NSString *)source{
    CocoaSecurityResult *md5 = [CocoaSecurity md5:source];

    return md5.hexLower;
}



#pragma mark -
#pragma mark - Sound Rec methods
-(void)changeChannelType:(PSRChannelType)psrctype{
    [_recordManager resetQueue:psrctype];
}

#pragma  mark -
#pragma mark - エンジンのパラメータ設定
+(void)setNoiseLevel:(float)twhiteAmp{
    
    whiteAmp = twhiteAmp;
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%.1f",twhiteAmp] forKey:kNrLevelKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(void)setEngineLogAndRaw:(bool)flag{

    thread_fan_enableraw        = flag;
    threadmt_scorelog           = flag;//スコーアは必ず出力
    threadfan_analysis_log_on   = flag;
    pocketfan_score_log_on      = flag;
    threadfan_score_log_on      = flag;
    log_print_engine_log_on     = flag;


}


+(void)removeEngineLogAndRawFile{
    NSString *debuglogfilepath = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithUTF8String:logbuglog_path]];
    NSString *pathOfEngineDump = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithUTF8String:engine_dumpraw_path]];
    NSString *scorepath = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithUTF8String:inpection_score_path]];
    NSString *engineanalysis = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithUTF8String:engine_analysis_path]];
    if([[NSFileManager defaultManager] fileExistsAtPath:debuglogfilepath] == true){
        [[NSFileManager defaultManager] removeItemAtPath:debuglogfilepath error:nil];
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:pathOfEngineDump] == true){
        [[NSFileManager defaultManager] removeItemAtPath:pathOfEngineDump error:nil];
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:scorepath] == true){
        [[NSFileManager defaultManager] removeItemAtPath:scorepath error:nil];
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:engineanalysis] == true){
        [[NSFileManager defaultManager] removeItemAtPath:engineanalysis error:nil];
    }
}



#pragma mark - 不要語と読みを除外
+(NSString *)getResultFromBase:(char *)baseString{
    NSString *uxxx057 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-057", nil)];
   
    NSData *sjisData = [NSData dataWithBytes:baseString length:strlen(baseString)];
    // 対象のNSDataがsjisコードであることを指定してNSStringを作成
    NSMutableString *displayResult = [NSMutableString string];
    NSString *nsString = [[NSString alloc] initWithData:sjisData encoding:NSShiftJISStringEncoding ];
//    [PSRManager sendLogTextAsync:@{kLogViewKey:nsString}];
    NSString *retString = @"";
    NSArray *tempArray = [nsString componentsSeparatedByString:@";"];

    //複数の結果がある場合、確率の高い方を選ぶ
    if(tempArray != nil){
        //認識結果表示用文字列を作る
        long kcounter = tempArray.count - 1;
        for (int j = 1; kcounter >= 0; kcounter--) {
            @autoreleasepool {
                if((tempArray[kcounter] == nil)||([tempArray[kcounter] isEqualToString:@""])){
                    continue;
                }
                NSString *reformartString = [self getValueFromInspectionResult:tempArray[kcounter]];
                switch (j) {
                    case 1:
                        [displayResult appendFormat:@"①"];
                        break;
                    case 2:
                        [displayResult appendFormat:@"②"];
                        break;
                    default:
                        [displayResult appendFormat:@"◉"];
                        break;
                }

                [displayResult appendString:reformartString];
                [displayResult appendString:@","];
                j++;
                //使える結果を認識結果にする
                if(retString.length == 0){
                    NSArray *retArray = [reformartString componentsSeparatedByString:@"/"];
                    if((retArray != nil)&&(retArray.count > 0)&&([retArray[0] isEqualToString:@""] == NO)){
                        retString = retArray[0];
                    }else{
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [SVProgressHUD showErrorWithStatus:uxxx057];
                        });
                    }
                }
            }
            
        }
    }else{
        dispatch_async(dispatch_get_main_queue(), ^{
           [SVProgressHUD showErrorWithStatus:uxxx057];
        });
    }
    if([displayResult isEqualToString:@""] == NO){
        [PSRManager sendLogTextAsync:@{kLogViewKey:displayResult,kOptionKey:@"2"}];
    }
    

    return retString;

}



+(NSString *)getValueFromInspectionResult:(NSString *)nsString{
    NSString *retString = @"";
    int i,copyflag;
    NSMutableString *ms = [NSMutableString string];
    //読みを除外
    for(i = 0,copyflag = 0;i< nsString.length ; i++){
        unichar ele = [nsString characterAtIndex:i];
        if(ele == '/'){
            copyflag = 1;//disable copy: skip util meet next :
        }
        if((copyflag == 1)&&(ele != '/')&&(ele != ':')){
            [ms appendFormat:@"%C",ele];
        }
        if(ele == ':'){//enable copy
            copyflag = 0;
            continue;
        }
        if(copyflag == 1){
            continue;
        }
        retString = [NSString stringWithFormat: @"%@%C",retString, ele];
    }
    //順不同入力対応
    NSArray *jarray = [retString componentsSeparatedByString:@"__"];
    NSString *preString = @"";
    NSString *sufString = @"";
    if(jarray.count == 2){
        preString = jarray[0];
        sufString = jarray[1];
    }else{
        sufString = retString;
    }
//    let res1Array = inputString.componentsSeparatedByString("__")
    
    //数字結果の整形
    bool negativeflag = false,numberflag = true;
    long precision = 0;//少数点の精度
    double numret = 0.f;
    NSString *formatString;
    NSScanner *scanner;
    NSArray *numArray = [sufString componentsSeparatedByString:@","];
    if((numArray != nil)&&(numArray.count > 1)){
        //        NSCharacterSet* notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        for(i = 0;i < numArray.count ; i++){
            NSString *tmp = numArray[i];
            if((tmp == nil)||([tmp isEqualToString:@""])){
                continue;
            }
            if(([tmp isEqualToString:@"-"] == true)&&( i == 0)){
                negativeflag = true;
                continue;
            }
            scanner = [NSScanner scannerWithString:tmp];
            double tmpdouble;
            BOOL success = [scanner scanDouble:&tmpdouble];
            if (success == true)
            {
                long decimalLength = tmp.length - [NSString stringWithFormat:@"%d",(int)tmpdouble].length - 1;
                if((decimalLength > precision)&&(decimalLength > 0)){//精度の更新
                    precision = decimalLength;
                }
                numret = numret + tmpdouble;
            }else{
                numberflag = false;
                break;
            }
            
        }//
        if(numberflag == true){
            if(negativeflag == true){
                numret = (-1)*numret;
            }
            if(precision > 0){
                formatString = [NSString stringWithFormat:@"%%0.%ldf",precision];
                sufString = [NSString stringWithFormat:formatString,numret];
            }else{
                sufString = [NSString stringWithFormat:@"%d",(int)numret];
            }
        }
    }
    
    if([preString isEqualToString:@""] == false){
        return [NSString stringWithFormat:@"%@__%@/%@",preString,sufString,ms];
    }else{
        return [NSString stringWithFormat:@"%@/%@",sufString,ms];
    }
    
}




#pragma mark -
#pragma mark - test methods
-(void)test {
    printf("%s",logbuglog_path);

}


-(void)setbackupRule:(NSString *)crule{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if([crule isEqualToString:@""] == YES){
        obj.clear_backup_rule();
    }else{
        obj.set_backup_rule(std::string([crule UTF8String]));
    }

    
}


-(NSString *)getbackupRule{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    return [NSString stringWithUTF8String:obj.get_backup_rule().c_str()];
}


-(NSString *)getcurrentRule{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    return [NSString stringWithUTF8String:obj.current_rule];
}
+(void)test{
    printf("%s",logbuglog_path);
}



-(void)saveInspectionLog:(NSString *)log{
    @autoreleasepool {
        NSString *debuglogfilepath = [NSHomeDirectory() stringByAppendingPathComponent:@kInspectionDebugLogFile];
        
        if([[NSFileManager defaultManager] fileExistsAtPath:debuglogfilepath] == false){
            [[NSFileManager defaultManager] createFileAtPath:debuglogfilepath contents:nil attributes:nil];
        }
        
        NSData *logData = [log dataUsingEncoding:NSUTF8StringEncoding];
        
        NSFileHandle *myHandle = [NSFileHandle fileHandleForWritingAtPath:debuglogfilepath];
        
        [myHandle seekToEndOfFile];
        [myHandle writeData:logData];
        [myHandle closeFile];
    }
    
}


-(void)UT_PSRManager30{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest30();

}

-(void)UT_PSRManager31{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest31();
    
}


-(void)ut_CallLog:(NSString *)logString{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    char tmpString[128];
    sprintf(tmpString, "%s",[logString cStringUsingEncoding:NSUTF8StringEncoding]);
    obj.call_log(tmpString);
}

-(void)ut_CallLogNull{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.utcalllogNull();
}

-(void)ut_SRStart{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_srStartCB();
}


-(void)ut_SRStop{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_SRStopCB();
}

-(void)ut_SRFailure:(int)failureCode{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_SRFailureCB(failureCode);
}


-(void)ut_SRSuccess{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_SRSuccessCB();
}

-(int)psr_runing_busy{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    return obj.psr_runing_busy();
}

-(void)unittest_SRStatus:(int)status param:(int)param{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_SRStatus(status, param);
}

-(void)unittest_SRException{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_SRExceptinCB();
}


-(int)unittest_SRInitTest:(NSString *)doc_dir inifile:(NSString *)inifile{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    char homeDir[PATH_MAX];
    
    char iniDir[PATH_MAX];
    if((doc_dir == nil)&&(inifile == nil)){
        return obj.unittest_SRinit(NULL, NULL);
    }else if(doc_dir == nil){
        sprintf(iniDir, "%s",[inifile UTF8String]);
        return obj.unittest_SRinit(NULL, iniDir);
    }else if(inifile == nil){
        sprintf(homeDir, "%s",[doc_dir UTF8String]);
        return obj.unittest_SRinit(homeDir, nil);
    }else{
        sprintf(homeDir, "%s",[doc_dir UTF8String]);
        
        sprintf(iniDir, "%s",[inifile UTF8String]);
        
        return obj.unittest_SRinit(homeDir, iniDir);
    }


}

-(NSString *)unittest_getInspectionResult{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.unittest_getInspectionResult() == NULL){
        return NULL;
    }
    return [NSString stringWithCString: obj.unittest_getInspectionResult() encoding:NSUTF8StringEncoding];
}


-(int)unittest_PSRStart:(NSString *)rule{
    char trule[PATH_MAX];
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    sprintf(trule, "%s",[rule UTF8String]);
    return obj.unittest_PSRStart(trule);
    
}


-(void)unittest_psrstop{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_PSRStop();
}

-(void)unittest_PSRClose{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unnittest_PSRClose();
}

-(int )unnittest_SetLogLevel:(int)level{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    return obj.unnittest_SetLogLevel(level);
}

-(void)unittest_call_alarm_Null{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    obj.unittest_Call_alarm_NULL();
}

-(int)unittest_psr_open_dic:(NSString *)filepath{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if((filepath == nil)||([filepath isEqualToString: @""])){
        return obj.unittest_psr_open_dic(NULL);
    }
    char filetmp[PATH_MAX];
    sprintf(filetmp, "%s",[filepath UTF8String]);
    return obj.unittest_psr_open_dic(filetmp);
    
}

-(int)unittest_psr_set_user:(NSString *)filepath{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if((filepath == nil)||([filepath isEqualToString: @""])){
        return obj.unittest_psr_set_user(NULL);
    }
    char filetmp[PATH_MAX];
    sprintf(filetmp, "%s",[filepath UTF8String]);
    return obj.unittest_psr_set_user(filetmp);
}
-(NSString *)unittest_psr_get_user{
    PSRCore& obj = *reinterpret_cast<PSRCore*>(_corepsrObj);
    if(obj.unittest_psr_get_user() == NULL){
        return NULL;
    }
    
    return [NSString stringWithCString: obj.unittest_psr_get_user() encoding:NSUTF8StringEncoding];
}


@end


