//
//  PSRSoundRec.h
//  VoiceDo
//
//  Created by user2 on 2015/09/10.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AudioToolbox/AudioFile.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#include <Foundation/Foundation.h>
#import "psrconfig.h"
#import "MCAudioFileStream.h"
#import <pthread.h>
#define BUFFERED_SEC 0.02
#define QUEUE_NUM 5


@interface PSRSoundRec : NSObject{
    AudioQueueBufferRef queueBuffer[QUEUE_NUM];
    AudioFileID					mRecordFile;
    AudioStreamBasicDescription dataformat;
    SInt64 currentPacket;
    
    
}

@property AudioFileID mRecordFile;
@property SInt64 currentPacket;
//@property pthread_mutex_t dump_mutex;

@property (nonatomic,assign)AudioStreamBasicDescription monauralFormat;
@property (nonatomic,assign)AudioStreamBasicDescription stereoFormat;

@property (nonatomic,assign)AudioQueueRef queue;
@property (nonatomic,assign)UInt32 queueSize;
@property (nonatomic,assign)PSRChannelType channelType;
@property (nonatomic,assign)NSTimer *metertimer;
@property (nonatomic)AudioStreamBasicDescription dataformat;
@property (nonatomic,assign)BOOL mIsRunning;

@property (nonatomic,strong)NSDateFormatter *mAudioDumpDateFomatter;


@property (nonatomic, strong) void (^showMeterBlock)(CGFloat);

-(id)initWithChannelType:(PSRChannelType)channletype;
-(bool)stop;
-(void)record;
- (void) recordWithFile:(NSString *)recordDetail rule:(NSString *)rule currentDict:(NSString *)currentDict userPath:(NSString *)userPath chosedDumpMode:(BOOL)chosedDumpMode;
- (bool) stopWithFile:(BOOL)chosedDumpMode ;
-(void)resetQueue:(PSRChannelType)channletype;
-(void)finalizeQueue;
-(void)audioUseHeadPhotoSpeaker;
-(void)audioUseBuildInSpeaker;
- (BOOL)isHeadsetPluggedIn;
-(NSString *)connecttypeString;
-(BOOL)isRouteSetToBT;
-(NSString *)getAudioDumpTimpStamp:(NSDate *)date;

+(AudioStreamBasicDescription)getMonauralFormat;
+(AudioStreamBasicDescription)getStereoFormat;
+(id)shareInstance;


-(void)onshowMeterBlock:(void(^)(CGFloat))meterBlock ;

+(void)testAudioData:(const void *)packets
       numberOfBytes:(UInt32)numberOfBytes
     numberOfPackets:(UInt32)numberOfPackets
  packetDescriptions:(AudioStreamPacketDescription *)packetDescriptioins;

-(id)unittest_init;
-(void)unittest_recordCallback;
@end
