//
//  PSRSoundRec.m
//  VoiceDo
//
//  Created by user2 on 2015/09/10.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import  "PSRSoundRec.h"
#import  "PSRManager.h"
#import  "SVProgressHUD.h"
#include "PocketSRInterface.h"
#import  "VoiceDo-Swift.h"




#ifdef FILE_OUT
static FILE *fp = NULL;
#endif

@interface PSRSoundRec()

@end
extern float whiteAmp;  // PocketSRで定義
@implementation PSRSoundRec{

}
BOOL gaudioIsStarted;
@synthesize mRecordFile,currentPacket,dataformat;

-(id)init{
    self = [super init];
    if (self) {
        self.queue = NULL;
        self.queueSize = 0;

        _channelType = PSRChannelTypeUnknown;
        NSError *error = nil;
        BOOL success;
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];

        success = [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord
                                                     withOptions:(AVAudioSessionCategoryOptionDefaultToSpeaker |
                                                                  AVAudioSessionCategoryOptionAllowBluetooth) error:&error];

        [[AVAudioSession sharedInstance] setActive:YES error:nil];
        gaudioIsStarted = false;
        if(!success){
            NSLog(@"AudioSession setActive error [%@]", [error localizedDescription]);
        }
    }
    return  self;
}

-(void)dealloc{
}

-(id)initWithChannelType:(PSRChannelType)channletype{
    self = [super init];
    if (self) {
        self.queue = NULL;
        self.queueSize = 0;
        _channelType = PSRChannelTypeUnknown;
        [self resetQueue:channletype];
        
    }
    return  self;

}

+(id)shareInstance{
    static PSRSoundRec *shareInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareInstance = [[self alloc] init];
    });
    
    return shareInstance;
}

//モノラル 1ch
+(AudioStreamBasicDescription)getMonauralFormat{
    AudioStreamBasicDescription format;
    format.mSampleRate = 11025.0;
    format.mFormatID = kAudioFormatLinearPCM;
    format.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;
    format.mFramesPerPacket = 1;
    format.mChannelsPerFrame = 1;
    format.mBitsPerChannel = 16;
    format.mBytesPerPacket = 2;
    format.mBytesPerFrame = 2;
    format.mReserved = 0;
    return format;
}

// ステレオ 2ch
+(AudioStreamBasicDescription)getStereoFormat{
    AudioStreamBasicDescription format;
    format.mSampleRate = 11025.0;
    format.mFormatID = kAudioFormatLinearPCM;
    format.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;
    format.mFramesPerPacket = 1;
    format.mChannelsPerFrame = 2;
    format.mBitsPerChannel = 16;
    format.mBytesPerPacket = 4;
    format.mBytesPerFrame = 4;
    format.mReserved = 0;

    return format;
}



#ifdef __cplusplus
extern "C"
{
#endif
    
    static void recordCallback(
                               void *inUserData,
                               AudioQueueRef inAQ,
                               AudioQueueBufferRef inBuffer,
                               const AudioTimeStamp *inStartTime,
                               UInt32 inNumberPacketDescriptions,
                               const AudioStreamPacketDescription *inPacketDescs
                               )
    {
        double ddflag = [[NSUserDefaults standardUserDefaults] doubleForKey:kMikeZeroInputCountKey];
        if(ddflag > 0){
            ddflag = ddflag  - 1;
            [[NSUserDefaults standardUserDefaults] setDouble:ddflag forKey:kMikeZeroInputCountKey];
            AudioQueueEnqueueBuffer(inAQ, inBuffer, 0, NULL);
            return ;
        }
        PSRSoundRec *shareInstance = [PSRSoundRec shareInstance];
        OSStatus status = noErr;
//レコードファイル記録
        if(([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceAllDump])||([[[NSUserDefaults standardUserDefaults] objectForKey:kSaveRecordDumpKey] isEqualToString:@kDumpChoiceChoosedDump])){
            
            status = AudioFileWritePackets(
                                                    shareInstance.mRecordFile,
                                                    NO,
                                                    inBuffer->mAudioDataByteSize,
                                                    inPacketDescs,
                                                    shareInstance.currentPacket,
                                                    &inNumberPacketDescriptions,
                                                    inBuffer->mAudioData);
            
            if (status == noErr) {
                shareInstance.currentPacket += inNumberPacketDescriptions;
            }
            
        }
#ifdef FILE_OUT
        char fname[PATH_MAX];
        snprintf(fname, PATH_MAX, "%s/Documents/debug_sound0.raw", (char *)[NSHomeDirectory() UTF8String]);
        if(([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%s",fname]] == false)||(fp == NULL)){
            if((fp = fopen(fname, "w")) == NULL){
                NSLog(@"ファイルのオープンに失敗しました(%s)", fname);
            }
        }

#endif
//レコードファイル記録END
        
        static char buffer[44100 * 2];
        int bytePerPacket = 2;
        AudioStreamBasicDescription format;
//        NSString *uxxx059 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-059", nil)];
        iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();
        if (shareInstance.channelType == PSROneChannelType){
            format = [PSRSoundRec getMonauralFormat];
        }else if(shareInstance.channelType == PSRTwoChannelType){
            format = [PSRSoundRec getStereoFormat];
        }
        bytePerPacket = format.mBytesPerFrame;
        
        UInt32 readSize = inBuffer->mAudioDataByteSize;
        short level, max;
        memset(buffer, 0000, sizeof(buffer));
        
        if(0 < readSize){
            // 音声データを認識エンジンに渡す
            if (shareInstance.channelType == PSROneChannelType) {
                max = 0;
                for(int i = 0; i < readSize / bytePerPacket; i++){
                    memcpy(buffer + i * bytePerPacket * 2, (char *)inBuffer->mAudioData + i * bytePerPacket, bytePerPacket);

                    level = *(short *)((char *)inBuffer->mAudioData + i * bytePerPacket);

                    if (max < abs(level)) max = abs(level);
                    // モノラルの場合、右側に一定レベルの値を書き込みステレオにする
                    // 認識エンジンが左右差を見ているので、左をコピーするのでは駄目
                    memset(buffer + i * bytePerPacket * 2 + bytePerPacket, 0000, sizeof(short));
                }
                g_pIf->WaveDataSet(buffer, readSize * 2);
//                if(g_pIf->WaveDataSet(buffer, readSize * 2) == false){
//                    dispatch_async(dispatch_get_main_queue(), ^{
//                        [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,WaveDataSet set failed",__FUNCTION__]];
//                    });
//                }
#ifdef FILE_OUT
                fwrite(buffer, readSize * 2, 1, fp);
#endif

#ifndef  LEVEL_METER

                
                [[NSNotificationCenter defaultCenter] postNotificationName:kMeterChangeNotification object:nil userInfo:@{kMeterValueKey:[NSString stringWithFormat:@"%hd",max]}];
                if(shareInstance.showMeterBlock !=  nil){
                    shareInstance.showMeterBlock(max);
                }
#endif
            }
            else {
                max = 0;
                for(int i = 0; i < readSize / bytePerPacket; i++){
                    level = *(short *)((char *)inBuffer->mAudioData + i * bytePerPacket);
                    if (max < abs(level)) max = abs(level);
                }
                memcpy(buffer, inBuffer->mAudioData, readSize);
                g_pIf->WaveDataSet(buffer, readSize);
#ifdef FILE_OUT
                fwrite(buffer, readSize, 1, fp);
#endif
#ifndef LEVEL_METER
                [[NSNotificationCenter defaultCenter] postNotificationName:kMeterChangeNotification object:nil userInfo:@{kMeterValueKey:[NSString stringWithFormat:@"%hd",max]}];
                if(shareInstance.showMeterBlock !=  nil){
                    shareInstance.showMeterBlock(max);
                }
#endif
            }
        }
        if(status == noErr){
            AudioQueueEnqueueBuffer(inAQ, inBuffer, 0, NULL);
        }else{
            NSLog(@"ut:AudioFileWritePackets failed");
        }
    }
#ifdef __cplusplus
}
#endif
//再現
+(void)testAudioData:(const void *)packets
                       numberOfBytes:(UInt32)numberOfBytes
                     numberOfPackets:(UInt32)numberOfPackets
                  packetDescriptions:(AudioStreamPacketDescription *)packetDescriptioins{
    PSRSoundRec *shareInstance = [PSRSoundRec shareInstance];

    static char buffer[44100 * 2];

    iOS::PocketSRInterface *g_pIf = iOS::PocketSRInterface::GetInstance();

    short level, max;
    int bytePerPacket = numberOfBytes/numberOfPackets;
    memset(buffer, 0000, sizeof(buffer));

    if(0 < numberOfBytes){
        // 音声データを認識エンジンに渡す
        if (shareInstance.channelType == PSROneChannelType) {
            max = 0;
            for(int i = 0; i < numberOfPackets; i++){
                memcpy(buffer + i * bytePerPacket * 2, (char *)packets + i * bytePerPacket, bytePerPacket);
                

                level = *(short *)((char *)packets + i * bytePerPacket);
                if (max < abs(level)) max = abs(level);
                // モノラルの場合、右側に一定レベルの値を書き込みステレオにする
                // 認識エンジンが左右差を見ているので、左をコピーするのでは駄目

                memset(buffer + i * bytePerPacket * 2 + bytePerPacket, 0000, sizeof(short));

            }


            g_pIf->WaveDataSet(buffer, numberOfBytes * 2);


        }

    }
    
 
}



- (BOOL)isHeadsetPluggedIn {
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {

        if ([[desc portType] isEqualToString:AVAudioSessionPortBluetoothHFP])
            return YES;
        
    }
    return NO;
}

-(NSString *)connecttypeString{
//    NSString *targetString;
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {
        
        if ([[desc portType] isEqualToString:AVAudioSessionPortBluetoothHFP]){
            return @"BlueToothヘッドセット接続";
        }else if(([[desc portType] isEqualToString:AVAudioSessionPortHeadphones])){
            return @"ヘッドセット接続";
        }else if(([[desc portType] isEqualToString:@"USBAudio"])){
            return @"VoiceDo優先ヘッドセット";
        }
    }
        
    
    return @"接続なし";

}


-(BOOL)isRouteSetToBT{
    UInt32 size = sizeof(CFStringRef);
    CFStringRef route;
    OSStatus result = AudioSessionGetProperty(kAudioSessionProperty_AudioRoute, &size, &route);
    NSLog(@"route = %@,result:%d", route,result);
    
    return true;
}



-(void)resetQueue:(PSRChannelType)channletype
{
    // Queueのサイズ
    AudioStreamBasicDescription format;
    switch (channletype) {
        case PSROneChannelType:{
            NSLog(@"1chに切り替わる");
            format = [PSRSoundRec getMonauralFormat];
            _channelType = PSROneChannelType;
            dataformat = format;
            break;
        }
        case PSRTwoChannelType:{
            NSLog(@"2chに切り替わる");
            _channelType = PSRTwoChannelType;
            format = [PSRSoundRec getStereoFormat];
            dataformat = format;
            break;
        }
        default:{
            NSLog(@"イレギュラーの引数:channletype=%ld,チャンネル設置失敗",(long)channletype);
            _channelType = PSRChannelTypeUnknown;
            return ;
        }
    }

    // 認識用バッファより小さく
    _queueSize = format.mBytesPerPacket * format.mSampleRate * BUFFERED_SEC;
    
    // 入力用AudioQueueの確保
    if (_queue != NULL) {
        [self finalizeQueue];

    }
    
    AudioQueueNewInput(&format, recordCallback, (__bridge void *)self, NULL, NULL,  0, &_queue);
    for(int i = 0; i < QUEUE_NUM; i++){
        AudioQueueAllocateBuffer(_queue, _queueSize, &queueBuffer[i]);
    }

    
#ifdef LEVEL_METER
    // レベルメータの有効化
    UInt32 enabledLevelMeter = true;
    OSStatus avitiveMeter =  AudioQueueSetProperty(_queue, kAudioQueueProperty_EnableLevelMetering, &enabledLevelMeter, sizeof(UInt32));
    NSLog(@"avitiveMeter:%d",(int)avitiveMeter);
    // レベル取得のタイマー設定
    if(_metertimer == nil){
        _metertimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(detectLevel:) userInfo:nil repeats:YES];
    }
#endif
}

-(void)finalizeQueue
{

    AudioQueueDispose(_queue, YES);
    _queue = NULL;
}


-(void)audioUseBuildInSpeaker{
    dispatch_async(dispatch_get_main_queue(), ^{
        OSStatus status;
        AudioSessionInitialize(NULL, NULL, NULL, NULL);
        UInt32 sessionCategory = kAudioSessionCategory_PlayAndRecord; // 1
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        
        status = AudioSessionSetProperty (
                                 kAudioSessionProperty_AudioCategory, // 2
                                 sizeof (sessionCategory), // 3
                                 &sessionCategory // 4
                                 );
        if(status != 0){
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,audioUseBuildInSpeaker(kAudioSessionProperty_AudioCategory): %d",__FUNCTION__,(int)status]];
        }
        
        UInt32 ASRoute = kAudioSessionOverrideAudioRoute_Speaker;
        
        status = AudioSessionSetProperty (
                                 kAudioSessionProperty_OverrideCategoryDefaultToSpeaker,
                                 sizeof (ASRoute),
                                 &ASRoute
                                 );
        if(status != 0){
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,audioUseBuildInSpeaker(kAudioSessionProperty_OverrideCategoryDefaultToSpeaker): %d",__FUNCTION__,(int)status]];
        }
        [audioSession setActive:YES error:nil];
    });
    
}

-(void)audioUseHeadPhotoSpeaker{
    if([self isHeadsetPluggedIn] == true){
        return ;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        NSError *error;
        BOOL success;
        
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        success = [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord
                                withOptions:(AVAudioSessionCategoryOptionDefaultToSpeaker |
                                             AVAudioSessionCategoryOptionAllowBluetooth) error:&error];
        if(success != 0){
            [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,setCategory: %d",__FUNCTION__,(int)success]];
        }
        
        [audioSession setActive:YES error:nil];
        
    });

}

-(void)record
{
    [PSRManager sendLogTextAsyncZ:[NSString stringWithFormat:@"func:%s IN",__FUNCTION__]];
    NSString *uxxx061 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-061", nil)];
    if(gaudioIsStarted == true){
#ifdef DEBUG
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD showErrorWithStatus:uxxx061];
        });
#else
        
#endif
        [PSRManager sendLogTextAsyncZ:uxxx061];
    }
    if(_showMeterBlock != nil){
        _showMeterBlock(0);
    }
    
    // 録音開始
    for(int i = 0; i < QUEUE_NUM; i++){
        AudioQueueEnqueueBuffer(_queue, queueBuffer[i], 0, NULL);
    }

    OSStatus stat = AudioQueueStart(_queue, NULL);
    if(stat == 0){
        gaudioIsStarted = true;
    }
    [PSRManager sendLogTextAsyncZ:[NSString stringWithFormat:@"func:%s OUT1,AudioQueueStart(record): %d",__FUNCTION__,(int)stat]];
    

}




- (void) recordWithFile:(NSString *)recordDetail rule:(NSString *)rule currentDict:(NSString *)currentDict userPath:(NSString *)userPath chosedDumpMode:(BOOL)chosedDumpMode{
    NSString *uxxx061 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-061", nil)];
    NSString *uxxx063 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-063", nil)];
    NSString *uxxx064 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-064", nil)];
    if(currentDict == nil){
        dispatch_sync(dispatch_get_main_queue(), ^{
           [SVProgressHUD showErrorWithStatus:uxxx063];
        });
        return ;
    }
    
    if(userPath == nil){
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD showErrorWithStatus:uxxx064];
        });
        return ;
    }
    
    CFURLRef url = nil;
    UInt32 size;
    
    NSString *nameDump = [NSString stringWithFormat:@"%@_無効_%@_%@.caf",[self getAudioDumpTimpStamp:[NSDate date]],[[[recordDetail  stringByReplacingOccurrencesOfString:@"/" withString:@"_"] stringByReplacingOccurrencesOfString:@" " withString:@"_"] stringByReplacingOccurrencesOfString:@"　" withString:@"_"],rule];
    NSString *pathOfDump;
    NSString *folderOfDump;
    
    
    if(chosedDumpMode == NO){
        folderOfDump = [NSHomeDirectory() stringByAppendingPathComponent:kInspectionDumpPath];
        pathOfDump = [NSString stringWithFormat:@"%@/%@",folderOfDump,nameDump];
        [[PVDDatabaseAccess sharedInstance] addnewTmpDumpRecord:nameDump starttime:[[NSDate date] timeIntervalSince1970] currentRule:rule userfilePath:userPath dicfilePath:currentDict tmptableFlag:NO];
    }else{
        folderOfDump = [NSHomeDirectory() stringByAppendingPathComponent:kInspectionDumpTmpPath];
        pathOfDump = [NSString stringWithFormat:@"%@/%@",folderOfDump,nameDump];
        [[PVDDatabaseAccess sharedInstance] addnewTmpDumpRecord:nameDump starttime:[[NSDate date] timeIntervalSince1970] currentRule:rule userfilePath:userPath dicfilePath:currentDict tmptableFlag:YES];
    }
    
    if([[NSFileManager defaultManager] fileExistsAtPath:folderOfDump] == NO){
        [[NSFileManager defaultManager] createDirectoryAtPath:folderOfDump withIntermediateDirectories:true attributes:nil error:nil];
    }
    url = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 *)[pathOfDump UTF8String], [pathOfDump lengthOfBytesUsingEncoding:NSUTF8StringEncoding], NO);
    currentPacket = 0;
    // create the audio file
    AudioQueueNewInput(&dataformat, recordCallback, (__bridge void *)self,  NULL, NULL, 0, &_queue);
    size = sizeof(dataformat);
    AudioQueueGetProperty(_queue, kAudioQueueProperty_StreamDescription,
                          &dataformat, &size);
    
    OSStatus status = AudioFileCreateWithURL(url, kAudioFileCAFType, &dataformat, kAudioFileFlags_EraseFile, &mRecordFile),status2;
//    NSLog(@"AudioFileCreateWithURL:%d",(int)status);
    CFRelease(url);
    UInt32 cookieSize;
    
    if (AudioQueueGetPropertySize (_queue,kAudioQueueProperty_MagicCookie,&cookieSize) == noErr) {
        char* magicCookie = (char *) malloc (cookieSize);
        if (AudioQueueGetProperty (_queue,kAudioQueueProperty_MagicCookie,magicCookie,&cookieSize) == noErr) {
            AudioFileSetProperty (mRecordFile,kAudioFilePropertyMagicCookieData,cookieSize,magicCookie);
        }
        free (magicCookie);
    }
    
    // 認識用バッファより小さく
    _queueSize = dataformat.mBytesPerPacket * dataformat.mSampleRate * BUFFERED_SEC;
    
    for(int i=0; i < QUEUE_NUM; i++)
    {
        AudioQueueAllocateBuffer(_queue,_queueSize,&queueBuffer[i]);
        AudioQueueEnqueueBuffer(_queue,queueBuffer[i],0,nil);
    }
    // start the queue
//    self.mIsRunning = true;
    if(gaudioIsStarted == true){
#ifdef DEBUG
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD showErrorWithStatus:uxxx061];
        });
#else
        [PSRManager writeInspectionLog:uxxx061];
#endif
//        return ;
    }
    status2 = AudioQueueStart(_queue, NULL);
    if(status2 == 0){
        gaudioIsStarted = true;
    }
    [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,AudioFileCreateWithURL(record):%d,AudioQueueStart(record): %d",__FUNCTION__,(int)status,(int)status2]];
}


//todo chosed dump mode
- (bool) stopWithFile:(BOOL)chosedDumpMode {

    NSString *uxxx062 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-062", nil)];
    OSStatus status1,status2,status3;
    UInt32 cookieSize;
    
    if (AudioQueueGetPropertySize (_queue,kAudioQueueProperty_MagicCookie,&cookieSize) == noErr) {
        char* magicCookie = (char *) malloc (cookieSize);
        if (AudioQueueGetProperty (_queue,kAudioQueueProperty_MagicCookie,magicCookie,&cookieSize) == noErr) {
            AudioFileSetProperty (mRecordFile,kAudioFilePropertyMagicCookieData,cookieSize,magicCookie);
        }
        free (magicCookie);
    }
    if(gaudioIsStarted == false){
        [PSRManager writeInspectionLog:uxxx062];

    }
    status1 = AudioQueueStop(_queue, YES);
    if(status1 == 0){
        gaudioIsStarted = false;
    }
    status2 = AudioQueueDispose(_queue, YES);
    _queue = NULL;
    status3 = AudioFileClose(mRecordFile);
    
    if(chosedDumpMode == NO){
        [[PVDDatabaseAccess sharedInstance] updateAudioDumpRecord:NO];
    }else{
        [[PVDDatabaseAccess sharedInstance] updateAudioDumpRecord:YES];
    }
    [PSRManager writeInspectionLog:[NSString stringWithFormat:@"func:%s,AudioQueueStop(recordStop):%d,AudioQueueDispose(recordStop):%d,AudioFileClose(recordStop):%d",__FUNCTION__,(int)status1,(int)status2,(int)status3]];
    if((status1 != 0)||(status2 != 0)||(status3 != 0)){
        return  false;
    }else{
        return true;
    }
}


-(bool)stop
{
    [PSRManager sendLogTextAsyncZ:[NSString stringWithFormat:@"func:%s IN",__FUNCTION__]];
  
    

    NSString *uxxx062 = [[NSString alloc] initWithFormat:NSLocalizedString(@"UXXX-062", nil)];
    if(gaudioIsStarted == false){
        [PSRManager sendLogTextAsyncZ:uxxx062];
//        return true;
    }
    // 録音中止
    OSStatus status = AudioQueueStop(_queue, YES);
    if(status == 0){
        gaudioIsStarted = false;
    }

    [[NSNotificationCenter defaultCenter] postNotificationName:kMeterChangeNotification object:nil userInfo:@{kMeterValueKey:@0}];
    if(_showMeterBlock != nil){
        _showMeterBlock(0);
    }
    [PSRManager sendLogTextAsyncZ:[NSString stringWithFormat:@"func:%s OUT,AudioQueueStop(stop):%d",__FUNCTION__,(int)status]];
    
#ifdef FILE_OUT
    fclose(fp);
#endif
    if(status != 0){
        return false;
    }else{
        return true;
    }
}


-(void)detectLevel: (NSTimer *) ptimer
{
    AudioQueueLevelMeterState levelMeter;
    UInt32 levelMeterSize = sizeof(AudioQueueLevelMeterState);
    AudioQueueGetProperty(_queue, kAudioQueueProperty_CurrentLevelMeterDB, &levelMeter, &levelMeterSize);
#ifdef DEBUG
//     最大レベル
    NSLog(@"最大レベル: %f", levelMeter.mPeakPower);
//     平均レベル
    NSLog(@"平均レベル: %f", levelMeter.mAveragePower);
#endif
    [[NSNotificationCenter defaultCenter] postNotificationName:kMeterChangeNotification object:nil userInfo:@{kMeterValueKey:[NSString stringWithFormat:@"%f",levelMeter.mPeakPower + LEVEL_MAX]}];
    if(_showMeterBlock != nil){
        _showMeterBlock((levelMeter.mPeakPower + LEVEL_MAX));
    }
    

}

-(NSString *)getAudioDumpTimpStamp:(NSDate *)date{
    if(self.mAudioDumpDateFomatter == nil){
        self.mAudioDumpDateFomatter = [[NSDateFormatter alloc] init];
        self.mAudioDumpDateFomatter.dateFormat = @"yyyyMMdd_HHmmss";
    }
    return [self.mAudioDumpDateFomatter stringFromDate:date];

}




//


-(void)onshowMeterBlock:(void(^)(CGFloat))meterBlock{
    _showMeterBlock = meterBlock;
}

-(id)unittest_init{

    if (true) {
        self.queue = NULL;
        self.queueSize = 0;
        
        _channelType = PSRChannelTypeUnknown;
        NSError *error = nil;
        BOOL success;
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        
        success = [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord
                                withOptions:(AVAudioSessionCategoryOptionDefaultToSpeaker |
                                             AVAudioSessionCategoryOptionAllowBluetooth) error:&error];
        success = false;
        [[AVAudioSession sharedInstance] setActive:YES error:nil];
        gaudioIsStarted = false;
        if(!success){
            NSLog(@"AudioSession setActive error [%@]", [error localizedDescription]);
        }
//        self.mIsRunning = false;
    }
    return  self;
}

-(void)unittest_recordCallback{
    AudioQueueRef inAQ = nullptr;
    AudioQueueBufferRef inBuffer = nullptr;
    inBuffer->mAudioDataByteSize = 0;
    
    recordCallback(NULL, inAQ, inBuffer, NULL, 0, NULL);
    
}

@end
