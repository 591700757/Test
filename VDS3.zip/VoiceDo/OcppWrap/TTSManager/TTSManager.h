//
//  TTSManager.h
//  VoiceDo
//
//  Created by user2 on 2015/09/15.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TTSManager : NSObject


+(id)shareInstance;


//-(void)initTts;
//-(void)startTts:(NSString *)result_ns2;
//-(void)stopTts;
//-(void)closeTts;




//-(BOOL)getTtsIsSynthesised;         //合成完了したか false:合成完了した　true:合成中
@end
