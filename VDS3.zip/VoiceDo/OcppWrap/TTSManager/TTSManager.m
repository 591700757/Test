//
//  TTSManager.m
//  VoiceDo
//
//  Created by user2 on 2015/09/15.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import "TTSManager.h"
//#import "TtsTest.h"
#import "psrconfig.h"

@implementation TTSManager

-(id)init {
    self = [super init];
    
    if (self) {
        
        
        
    }
    
    return self;
}

+(id)shareInstance{
    static TTSManager *shareInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareInstance = [[self alloc] init];
    });
    return shareInstance;
}

//
//-(void)initTts{
//    NSString *doc_dir = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
//    TtsInit((char *)[doc_dir UTF8String]);
//}
//
//
//-(void)startTts:(NSString *)result_ns2{
//    //音声合成がOffの場合は即return
//    NSString *ttsOnflag = [[NSUserDefaults standardUserDefaults] objectForKey:kInspectWithSpeechKey];
//    if([ttsOnflag isEqualToString:@"false"]){
//        NSLog(@"tts start while ttsOnflag is false");
//        return ;
//    }
//    
//    
//    if((result_ns2 == nil)||(result_ns2.length == 0)||([result_ns2 isEqual:[NSNull null]])){
//        NSLog(@"異常の合成請求です、result_ns2:%@",result_ns2);
//        return ;
//    }
////    char result_utf8[PATH_MAX];
////    snprintf(result_utf8, PATH_MAX, "%s", [result_ns2 UTF8String]);
//    
//
//    NSLog(@"result_ns2:%@,[result_ns2 cStringUsingEncoding:NSShiftJISStringEncoding]:%s",result_ns2,[result_ns2 cStringUsingEncoding:NSShiftJISStringEncoding]);
//    TtsStart((char *)[result_ns2 cStringUsingEncoding:NSShiftJISStringEncoding]);
//}
//
//
//-(void)stopTts{
//    TtsStop();
//}
//
//
//-(void)closeTts{
//    TtsClose();
//}
//
//-(BOOL)getTtsIsSynthesised{
////この関数がstart音読んだら、音声が終わってもtrueのままです
////    return TtsIsSynthesised();
//    return TtsisPlaying();
//}



@end
