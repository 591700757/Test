//
//  ZipArchiveManager.h
//  VoiceDo
//
//  Created by user2 on 2015/10/09.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZipArchiveManager : NSObject
+(BOOL)unzipFileWithZipArchive:(NSString *)zipPath destinationPath:(NSString *)destinationPath;


+(BOOL)unzipfilewithPassword:(NSString *)zipPath destinationPath:(NSString *)destination password:(NSString *)password;

+ (BOOL)createZipFileAtPath:(NSString *)path
    withContentsOfDirectory:(NSString *)directoryPath
        keepParentDirectory:(BOOL)keepParentDirectory;



+(BOOL)createZipFileAtPath:(NSString *)path withFilesAtPaths:(NSArray *)filePath;
@end
