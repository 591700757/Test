//
//  ZipArchiveManager.m
//  VoiceDo
//
//  Created by user2 on 2015/10/09.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#import "ZipArchiveManager.h"
#import "Main.h"

@implementation ZipArchiveManager

+(BOOL)unzipFileWithZipArchive:(NSString *)zipPath destinationPath:(NSString *)destinationPath{
    
     return [Main unzipFileAtPath:zipPath toDestination:destinationPath delegate:nil];

}


+(BOOL)unzipfilewithPassword:(NSString *)zipPath destinationPath:(NSString *)destination password:(NSString *)password{
    BOOL result = [Main unzipFileAtPath:zipPath toDestination:destination overwrite:true password:password error:nil];
    return result;
}


+ (BOOL)createZipFileAtPath:(NSString *)path
    withContentsOfDirectory:(NSString *)directoryPath
        keepParentDirectory:(BOOL)keepParentDirectory{

    return  [Main createZipFileAtPath:path withContentsOfDirectory:directoryPath keepParentDirectory:keepParentDirectory];

}

+(BOOL)createZipFileAtPath:(NSString *)path withFilesAtPaths:(NSArray *)filePath{
    return [Main createZipFileAtPath:path withFilesAtPaths:filePath];
}


@end
