//
//  PVDAudioDataModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/03/01.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDAudioDataModel: NSObject {

}
