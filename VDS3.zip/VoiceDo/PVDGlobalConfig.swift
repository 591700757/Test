//
//  PVDGlobalConfig.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/28.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import Alamofire
import AVFoundation

extension Sequence {
    func find(_ predicate: (Self.Iterator.Element) throws -> Bool) rethrows -> Self.Iterator.Element? {
        for element in self {
            if try predicate(element) {
                return element
            }
        }
        return nil
    }
}


extension String {
    
    // Returns true if the string has at least one character in common with matchCharacters.
    func containsCharactersIn(_ matchCharacters: String) -> Bool {
        let characterSet = CharacterSet(charactersIn: matchCharacters)
        return self.rangeOfCharacter(from: characterSet) != nil
    }
    
    // Returns true if the string contains only characters found in matchCharacters.
    func containsOnlyCharactersIn(_ matchCharacters: String) -> Bool {
        let disallowedCharacterSet = CharacterSet(charactersIn: matchCharacters).inverted
        return self.rangeOfCharacter(from: disallowedCharacterSet) == nil
    }
    
    // Returns true if the string has no characters in common with matchCharacters.
    func doesNotContainCharactersIn(_ matchCharacters: String) -> Bool {
        let characterSet = CharacterSet(charactersIn: matchCharacters)
        return self.rangeOfCharacter(from: characterSet) == nil
    }
    
    // Returns true if the string represents a proper numeric value.
    // This method uses the device's current locale setting to determine
    // which decimal separator it will accept.
    func isNumeric() -> Bool
    {
        let scanner = Scanner(string: self)
        
        // A newly-created scanner has no locale by default.
        // We'll set our scanner's locale to the user's locale
        // so that it recognizes the decimal separator that
        // the user expects (for example, in North America,
        // "." is the decimal separator, while in many parts
        // of Europe, "," is used).
        scanner.locale = Locale.current
        
        return scanner.scanDecimal(nil) && scanner.isAtEnd
    }
    
    func stringByAppendingPathComponent(_ path: String) -> String {
        return (self as NSString).appendingPathComponent(path)
    }
    
    
    func substring(_ start: Int) -> String {
        
        return self.substring(from: self.characters.index(self.startIndex, offsetBy: start))
    }
    
    func substring(_ start: Int, length:Int) -> String {
        return self.substring(from: self.characters.index(self.startIndex, offsetBy: start)).substring(to: self.characters.index(self.startIndex, offsetBy: length))
    }
}

extension UIApplication {
    
    class func appVersion() -> String {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
    }
    
    class func appBuild() -> String {
        return Bundle.main.object(forInfoDictionaryKey: kCFBundleVersionKey as String) as! String
    }
    
    class func versionBuild() -> String {
        let version = appVersion(), build = appBuild()
        
        return version == build ? "v\(version)" : "v\(version)(\(build))"
    }
}

let kScreenWidth = UIScreen.main.bounds.size.width
let kScreenHeight = UIScreen.main.bounds.size.height

let kLibDomainPath = NSHomeDirectory().stringByAppendingPathComponent("Library/")
let kDocDomainPath = NSHomeDirectory().stringByAppendingPathComponent("Documents/")

let kbackupFolder = NSHomeDirectory().stringByAppendingPathComponent("Library/BackUpResultFiles/")//アップロード完了、引き継ぎ済みファイルのバックアップ
let ktmpbackupFolder = NSHomeDirectory().stringByAppendingPathComponent("Documents/BackUpResultFiles/")
let kreportsFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Library/reportinfo")
let kspeakerFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Library/infospeaker")  //話者ダウンロードの時の話者のフォルダー
let kinitFolderPath     = NSHomeDirectory().stringByAppendingPathComponent("Library/init")
let kreportZipfilePath = NSHomeDirectory().stringByAppendingPathComponent("Library/inforeport.zip")
let kspeakerZipfilePath = (NSHomeDirectory() as NSString).appendingPathComponent("Library/infospeaker.zip")


let ksynthfolderPath = NSHomeDirectory().stringByAppendingPathComponent("Library/Synth")
let kttsenginePath = NSHomeDirectory().stringByAppendingPathComponent("Library/TTSEngine.ini")
let kinitfileZipfilePath = NSHomeDirectory().stringByAppendingPathComponent("Library/init.zip")
let kSpeakerfileBackupPath = NSHomeDirectory().stringByAppendingPathComponent("Library/speakerBK/")
let kUnfinishedFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Library/unfinished/")
let kUnfinishedUploadTmpFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Library/TMPUnfinishedUpload/result")
let kFinishedFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Library/result/")

let kUnfinishedJsonPath = NSHomeDirectory().stringByAppendingPathComponent("Documents/unfinished.json")         //ホーム画面の未完了テーブルのリストのjson data
let kfinishedJsonPath = NSHomeDirectory().stringByAppendingPathComponent("Library/finished.json")             //ホーム画面の完了テーブルのリストのjson data
let kbindJsonPath = NSHomeDirectory().stringByAppendingPathComponent("Library/bind.json")            //制御語ファイルのパス
//引き継ぎダウンロードの記録json
let kShareDownloadListJson = NSHomeDirectory().stringByAppendingPathComponent("Library/shareDownloadListJson.json")   //引き継ぎファイルダウンロードの記録json
let khomejsonFolder =  NSHomeDirectory().stringByAppendingPathComponent("Library/homejson")
let kHomeSpeakerJsonFilePath = NSHomeDirectory().stringByAppendingPathComponent("Library/homejson/speaker.json")
let kHomeSpeakerFolderPath =  NSHomeDirectory().stringByAppendingPathComponent(kHomeSpeakerFolder)       //話者ダウンロードの解凍フォルダー
let kworksharingTmpFoder =  NSHomeDirectory().stringByAppendingPathComponent("Library/workSharing/")              //作業引き継ぎダウンロード後の解凍フォルダー
let kworksharingUpdateFoder =  NSHomeDirectory().stringByAppendingPathComponent("Library/workSharingUpdate/")
let kworksharingTmpzip =  NSHomeDirectory().stringByAppendingPathComponent("Library/worklist.zip")
let kdicForSpeachPathKey = NSHomeDirectory().stringByAppendingPathComponent("Library/homejson/dic_for_speech.txt")


let kresultZipFileName = NSHomeDirectory().stringByAppendingPathComponent("Library/result.zip")

let kpathForReportFolder = NSHomeDirectory().stringByAppendingPathComponent("Library/homejson/reports/")
let kpathForEnvironmentJson = NSHomeDirectory().stringByAppendingPathComponent("Library/environment.json")
let kpathOfdownloadEngineSR = NSHomeDirectory().stringByAppendingPathComponent("Library/sr.ini")
let kpathOfdownloadEngineData = NSHomeDirectory().stringByAppendingPathComponent("Library/data")
let kpathOfdownloadEngineDic = NSHomeDirectory().stringByAppendingPathComponent("Library/dic")


let ksettingfilePath = NSHomeDirectory().stringByAppendingPathComponent("Library/handsfree.ini")
let kengineFilePath = NSHomeDirectory().stringByAppendingPathComponent("Library/sr.ini")
let kengineBackUpFilePath = NSHomeDirectory().stringByAppendingPathComponent("Library/srbk.ini")



let kStatusLogFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Documents/statusLog/")
let kcrashLogFolder = NSHomeDirectory().stringByAppendingPathComponent("Documents/result/CrashLogs/")
let kAccessLogFolderPath = NSHomeDirectory().stringByAppendingPathComponent("Documents/accessLog/")


var kReportFileDownloadURL:String!   //レポートファイルダウンロードURL

var kSpearkFileDownloadURL:String!   //話者ファイルダウンロードURL


var kresultUploadURL:String!       //レポート結果アップロードURL

var kinitFileDownloadURL:String!    //初期ファイルダウンロードURL

var kworksharefileUploadURL:String! //引き継ぎファイルアップロードURL

var kworksharefileDownURL:String!  //引き継ぎファイルダウンロード

var kupdateResultURL:String!       //結果アップデート

var ktokenCheckURL:String!



//var gchoosedSpeakerfilePath:String!
//var gchooseSpeaker:String!


//var gworkPlanid:String?

var gSiriSpeechRate:Float! = AVSpeechUtteranceDefaultSpeechRate
var gresultTimeStampFormat:DateFormatter!
var gworkshareTimeStampFormat:DateFormatter!
var gDebugTimeStampFormat:DateFormatter!
var gDicForSpeach:NSMutableArray!
var gsettingModel:PVDSettingModel!
var gInternetAvaiable:Bool!
var alamofireManager:SessionManager!
var gcontrolBinds:PVDControlCommandModel!
var gStartInspectionFlag:PVDStartInspectionCBAciton!
var gInspectInitResult:Int32!
var gReportAndUserSetReuslt:Int32!
var gSavingFileFlag:Bool! = false

var gHomeJumpToServerSettingFlag:Bool = false //サーバー設定されてない場合ホーム画面から連続的に遷移するためのフラグ、PVDExtraIPControllerで止まる
var gHomeJumpToExtraSettigFlag:Bool = false   //初期ファイルダウンロード完了してない場合ホーム画面から連続的に遷移するためのフラグ、PVDExtraSettingControllerで止まる




var kiosVersion:Float = (UIDevice.current.systemVersion as NSString).floatValue


enum PVDWorkShareRecordType:String{
    case kFinishedWorkShareData     = "完了の引き継ぎデータを更新する"
    case kUnfinishedWorkShareData   = "未完了の引き継ぎデータを更新する"
    case kBackUpWorkShareData       = "バックアップの引き継ぎデータを更新する"
}



enum PVDInputcommandType:String{
//    case kCameraCmd     = "カメラモード"
    case kGoBackCmd         = "____前に戻る____"
    case kRepeatCmd         = "____もう一度____"
    case kSkipCmd           = "____ジャンプ____"
    case kStopCmd           = "____中断する____"
    case kStartNextCmd      = "____次の作業開始____"
    case kFinishedCmd       = "____ホームに戻る____"
    case kWorkShareCmd      = "____交代する____"
    case kFinisheCmd        = "____入力完了____"
    case kMoveCmd           = "____移動____"
    case kMoveToUnfinished  = "____未入力移動____"
    case kMoveToRequired    = "____必須移動____"
}


enum PVDPassInputCtrlMode:String{
    case kSetPass           = "パス初回設定"
    case kSetPassConfirm    = "パス確認"
    case kModify            = "パス変更"
    case kModifyConfirm     = "パス変更確認"
    case kGotoSys           = "パスチェック"
    case kUnlockPass        = "パスワード解除"
    case kNotSet            = "未設定"
}



enum PVDInputType:String{
    case kSelection     = "選択式"
    case kValue         = "数値"
    case kQRCode        = "コード読み取り"
    case kFreeInput     = "自由文"
    case kCustom        = "カスタム"
    case kDirectInput   = "直接入力"
    case kDirectInputG  = "直接入力_自動遷移"
}


enum SiriLangKey:String{
    case kJapanese  = "ja-JP"
    case kEnglish   = "en-US"
    case kChinese   = "zh-CN"
}

enum SiriLangDisPlay:String{
    case kJapanese  = "日本語"
    case kEnglish   = "English"
    case kChinese   = "中文"
}



enum UploadServerAction:String {
    case kWorkShareUpload = "引き継ぎアップード"
    case kFinishedUpload  = "自動結果アップロード"
    case kResultUpdate    = "完了アップデート"
    case kWriteFileOnly   = "ローカルで保存するのみ"
}

enum RetryActionType:String {
    case kGoHome        = "ホームに戻る"
    case kStartNext     = "新しいレポートの再開"
    case kNone          = "何もしない"
}

enum PVDStartInspectionCBAciton:String{
    case kChangingUser          = "ユーザ変更中"
    case kDoNothing             = "特に何もしない"
}



extension UIView {
    class func loadFromNibNamed(_ nibNamed: String, bundle : Bundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiate(withOwner: nil, options: nil)[0] as? UIView
    }
}

class PVDGlobalConfig: NSObject {
    
    
    
    enum PSRChannelType {
        case psrChannelTypeUnknown
        case psrOneChannelType          //1ch
        case psrTwoChannelType          //2ch
    }
    
    var channelType:PSRChannelType?

    
    
    init?(channelType: AnyObject?) {
        
    }
    
    
    
}
