//
//  PVDDatabaseAccess.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/09/02.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import SVProgressHUD
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func >= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l >= r
  default:
    return !(lhs < rhs)
  }
}

let gdbfileURL = try! FileManager.default
    .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
    .appendingPathComponent(kVoicedoDataBase)
class PVDDatabaseAccess: NSObject {
    
//    FMDatabaseQueue *queue = [FMDatabaseQueue databaseQueueWithPath:aPath];
    
    var shareFMQueue:FMDatabaseQueue!
    
    
    class var sharedInstance: PVDDatabaseAccess {
        struct Static {
            static let instance: PVDDatabaseAccess = PVDDatabaseAccess()

        }
        return Static.instance
    }

    
   func  trycreateVoiceDoDB(){
        shareFMQueue = FMDatabaseQueue(path: gdbfileURL.path)
    
        shareFMQueue.inTransaction { db, rollback in
            do {
                try db?.executeUpdate(kCreateTmpDumpTableSQL, values: nil)
                try db?.executeUpdate(kCreateAudioDumpTableSQL, values: nil)
                try db?.executeUpdate(kCreateUploadedTableSQL, values: nil)
            
            
            } catch {
                SVProgressHUD.showError(withStatus: "データベースエラ:create table error")
                print("failed: \(error)")
            }
        }
    }
    
    
    
    
    
    
    
    
    

    
    
    /**
     Dumpファイルの新しいRecordを追加
     
     - parameter name:         dumpファイル名
     - parameter starttime:    開始時間
     - parameter currentRule:  適応ルール
     - parameter userfilePath: ユーザファイル
     - parameter dicfilePath:  辞書ファイル
     - parameter tmptableFlag: true:一時保存のダンプファイル false:正式保存のダンプファイル
     */
    func addnewTmpDumpRecord(_ name:String,starttime:TimeInterval,currentRule:String,userfilePath:String,dicfilePath:String,tmptableFlag:Bool){
        shareFMQueue.inTransaction { db, rollback in
            do {
                let createTableSql:String!
                let countSQL:String
                var addRecordSql:String!
                var rowcount:Int32? = 0
                
                if(tmptableFlag == true){
                    createTableSql  = kCreateTmpDumpTableSQL
                    countSQL = kCountTmpDumpTableRecordSQL
                    
                }else{
                    createTableSql  = kCreateAudioDumpTableSQL
                    countSQL = kCountAudioDumpTableRecordSQL
                }
                try db?.executeUpdate(createTableSql, values: nil)
                
                let rsc = try db?.executeQuery(countSQL, values: nil)
                while (rsc?.next())! {
                    rowcount = rsc?.int(forColumn: "COUNT(*)")
                }
                if((tmptableFlag == true)&&((rowcount == nil)||(rowcount == 0))){//臨時ダンプ、最初の行
                    addRecordSql = kAddFirstTmpDumpTableRecordSQL
                }else if((tmptableFlag == true)&&(rowcount > 0)){//臨時ダンプ、最初以外の行
                    addRecordSql = kAddNewTmpDumpTableRecordSQL
                }else if((tmptableFlag == false)&&((rowcount == nil)||(rowcount == 0))){//通常ダンプ、最初の行
                    addRecordSql = kAddFirstAudioDumpTableRecordSQL
                }else if((tmptableFlag == false)&&(rowcount > 0)){//通常ダンプ、最初以外の行
                    addRecordSql = kAddNewAudioDumpTableRecordSQL
                }else{//例外
                    SVProgressHUD.showError(withStatus: "データベースエラ:SQL string failed,rowcount:" + String(describing: rowcount))
                    addRecordSql = ""
                    
                    return
                }
                
                if(rowcount > 0){
                    try db?.executeUpdate(addRecordSql, values: [name,currentRule,userfilePath,dicfilePath, starttime,false])
                }else{
                    try db?.executeUpdate(addRecordSql, values: [name,currentRule,userfilePath,dicfilePath, starttime,false])
                }
                
                
            } catch {
                SVProgressHUD.showError(withStatus: "データベースエラ:add record failed")
                print("failed: \(error)")
            }
        }

    }
    
    

    
    
    
    
    
    
    
    
    /**
     ダンプのレコードを更新する
     
     - parameter tmpFlag: true:一時ダンプ   false:通常ダンプ
     */
    func updateAudioDumpRecord(_ tmpFlag:Bool){
        var tableName:String!
        var selectSQL:String!
        var storeFolder:String!
        
        if(tmpFlag == true){
            tableName = kTmpDumpTableName
            selectSQL = kSelectTmpDumpTableNewRecordSQL
            storeFolder = kInspectionDumpTmpPath
            
        }else{
            tableName = kAudioDumpTableName
            selectSQL = kSelectAudioDumpTableNewRecordSQL
            storeFolder = kInspectionDumpPath
        }
        
        
        if(FileManager.default.fileExists(atPath: NSHomeDirectory().stringByAppendingPathComponent(storeFolder)) == false){
            try! FileManager.default.createDirectory(atPath: NSHomeDirectory().stringByAppendingPathComponent(storeFolder), withIntermediateDirectories: true, attributes: nil)
        }
        
        
        var oldName:String!
        let fullresult:String? = UserDefaults.standard.object(forKey: kResultKey) as? String
        UserDefaults.standard.set("", forKey: kResultKey)
        UserDefaults.standard.synchronize()
        if((fullresult == nil)||(fullresult == "")){
            return
        }

        
        let fullresultParts:[String]? = fullresult?.components(separatedBy: ",")
        var result:String? = nil
        if((fullresultParts != nil) && (fullresultParts!.count > 0)){
            result = fullresultParts![0]
        }
        
        shareFMQueue.inTransaction { (db, rollback) in
            do {
                if(db?.tableExists(tableName) == false){
                    PSRManager.sendLogTextAsync([kLogViewKey:"audio dump table not found"])
                    return
                }
                let rs = try db?.executeQuery(selectSQL, values: nil)
                while (rs?.next())! {
                    oldName = rs?.string(forColumn: "filename")
                    if(oldName == nil){
                        PSRManager.sendLogTextAsync([kLogViewKey:"audio filename not found"])
                        return
                    }
                }
            } catch let error as NSError {
                print("failed: \(error.localizedDescription)")
            }
            if(oldName == nil){
                PSRManager.sendLogTextAsync([kLogViewKey:"audio filename not found"])
                return
            }
            //get new name
            let oldNameParts:[String] = oldName.components(separatedBy: "_")
            
            var newName:String = ""
            if(oldNameParts.count > 3){
                var i = 0
                for namele in oldNameParts{
                    if(i == 2){
                        newName = newName + "_" + result!
                    }else if(i == 0){
                        newName = namele
                    }else{
                        newName = newName + "_" +  namele
                    }
                    i = i + 1
                }
            }
            let oldPath:String = NSHomeDirectory().stringByAppendingPathComponent(storeFolder + oldName)
            let newPath:String = NSHomeDirectory().stringByAppendingPathComponent(storeFolder + newName)
            
            if(FileManager.default.fileExists(atPath: oldPath) == true){
                do{
                    try FileManager.default.moveItem(atPath: oldPath, toPath: newPath)
                }catch let error as NSError{
                    PSRManager.writeInspectionLog("Fatal:Audio Dump rename failed:" + String(format:"%@",error ))
                }
                
            }
            
            do {
                if(db?.tableExists(tableName) == false){
                    SVProgressHUD.showError(withStatus: "データベースエラ:audio dump table not found")
                    return
                }
                var updateSQL = "update " + tableName + " set filename = '" + newName
                updateSQL = updateSQL + "' , audioEndtime = " + String(Date().timeIntervalSince1970)
                updateSQL = updateSQL  + " where filename = '" + oldName + "';"
                try db?.executeUpdate(updateSQL, values: nil)
                
            } catch let error as NSError {
                PSRManager.sendLogTextAsync([kLogViewKey:"\(error.localizedDescription)"])
            }
        }
        
        
    }
    
    
    func updateDumpDuration(){
        shareFMQueue.inTransaction { db, rollback in
            var durationTobeUpdate:Int = 0
            do {
                if(db?.tableExists(kAudioDumpTableName) == false){
                    return
                }
                
                let rs = try db?.executeQuery(kSelectUpdateAudioDumpTableDurationSQL, values: nil)
                while (rs?.next())! {
                    let oldName = rs?.string(forColumn: "filename")
                    if(oldName == nil){
                        SVProgressHUD.showError(withStatus: "データベースエラ:audio filename not found")
                        return
                    }
                    let path:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath + oldName!)
                    //update duration
                    var audioPlayer:AVAudioPlayer!
                    if(FileManager.default.fileExists(atPath: path) == true){
                        let audioPath = URL(fileURLWithPath: path)
                        try audioPlayer = AVAudioPlayer(contentsOf: audioPath)
                        durationTobeUpdate = Int(audioPlayer.duration)
                    }else{
                        durationTobeUpdate = 0
                    }
                    var updateSQL = "update " + kAudioDumpTableName + " set duration = " + String(durationTobeUpdate)
                    updateSQL = updateSQL + " where filename = '" + oldName! + "';"
                    
                    try db?.executeUpdate(updateSQL, values: nil)
                }
            } catch let error as NSError {
                PSRManager.sendLogTextAsync([kLogViewKey:"updateDumpDuration:\(error.localizedDescription)"])
            }
        }
    }
    
    
    func clearTmpDumpTable(){
        shareFMQueue.inTransaction { db, rollback in
            
            do {
                //try clear tmp table
                try db?.executeUpdate(kDeleteAllFromtmpDumpTableSQL, values: nil)
            } catch let error as NSError {
                PSRManager.sendLogTextAsync([kLogViewKey:"clearTmpDumpTable:\(error.localizedDescription)"])
            }
        }

    }
    
    
    
    
    func updateTmpDumpToAudioDump(_ completion: (_ result: Bool) -> Void){
        shareFMQueue.inTransaction { db, rollback in
            
            do {
                if(db?.tableExists(kAudioDumpTableName) == false){
                    return
                }
                var rowcount:Int32? = 0
                var addRecordSql:String!
                //count audio dump talbe
                let rsc = try db?.executeQuery(kCountAudioDumpTableRecordSQL, values: nil)
                while (rsc?.next())! {
                    rowcount = rsc?.int(forColumn: "COUNT(*)")
                }
                
                if((rowcount == nil)||(rowcount == 0)){//通常ダンプ、最初の行
                    addRecordSql = kAddFirstAudioDumpTableRecordSQL_2
                }else{//通常ダンプ、最初以外の行
                    addRecordSql = kAddNewAudioDumpTableRecordSQL_2
                }
//(ID INTEGER PRIMARY KEY AUTOINCREMENT,filename text,currentRule text,userfilePath text,dicfilePath text,duration Int,audioStarttime double, audioEndtime double, flag BOOL)
                let rs = try db?.executeQuery(kSelectTmptableFlagOnSQL, values: nil)

                while (rs?.next())! {
                    let name            = rs?.string(forColumn: "filename")
                    let currentRule     = rs?.string(forColumn: "currentRule")
                    let userfilePath    = rs?.string(forColumn: "userfilePath")
                    let dicfilePath     = rs?.string(forColumn: "dicfilePath")
                    let audioStarttime  = rs?.double(forColumn: "audioStarttime")
                    let audioEndtime    = rs?.double(forColumn: "audioEndtime")
                    
                    //try move data
                    if(name == nil){
                        SVProgressHUD.showError(withStatus: "データベースエラ:audio filename not found")
                        continue
                    }
                    let fromPath:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpTmpPath + name!)
                    let toPath:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath + name!)
                    if(FileManager.default.fileExists(atPath: fromPath) == true){
                        try FileManager.default.moveItem(atPath: fromPath, toPath: toPath)
                    }else{
                        PSRManager.sendLogTextAsync([kLogViewKey:"file lost"])
                        continue
                    }
                    
                    //try update database
                    try db?.executeUpdate(addRecordSql, values: [name ?? "",currentRule ?? "",userfilePath ?? "",dicfilePath ?? "", audioStarttime ?? "",audioEndtime ?? ""])
                    addRecordSql = kAddNewAudioDumpTableRecordSQL_2

                }
                let audioTmpFolder = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpTmpPath)
                if(FileManager.default.fileExists(atPath: audioTmpFolder)){
                    try! FileManager.default.removeItem(atPath: NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpTmpPath))
                }
                //try clear tmp table
                try db?.executeUpdate(kDeleteAllFromtmpDumpTableSQL, values: nil)
                if((PSRManager.shareInstance() as AnyObject).voicedoGetLogLevel() > 0){
                    PSRManager.sendLogTextAsync([kLogViewKey:"ダンプファイル更新しました(s)"])
                }
                
            } catch let error as NSError {
                if((PSRManager.shareInstance() as AnyObject).voicedoGetLogLevel() > 0){
                    PSRManager.sendLogTextAsync([kLogViewKey:"updateTmpDumpToAudioDump:ダンプファイル更新しました(f):\(error.localizedDescription)"])
                }
                
            }
        }
    }
    
    
    
    
    /**
     指定時間より前に開始したダンプを残すflagを
     
     - parameter time: 指定の時間
     */
    func updateRecordSaveFlag(){
        shareFMQueue.inTransaction { db, rollback in

            do {
                SVProgressHUD.show(withStatus: "保存フラグ更新...")
                if(db?.tableExists(kTmpDumpTableName) == false){
                    return
                }
                
                let rs = try db?.executeQuery(kSelectUpdateSaveFlagSQL, values: nil)
                while (rs?.next())! {
                    let oldName = rs?.string(forColumn: "filename")
                    if(oldName == nil){
                        SVProgressHUD.showError(withStatus: "データベースエラ:audio filename not found")
                        continue
                    }
                    //update save flag

                    let updateSQL = "update " + kTmpDumpTableName + " set flag = 1 where filename = '" + oldName! + "';"
                    
                    try db?.executeUpdate(updateSQL, values: nil)
                    
                    
                    
                }
                SVProgressHUD.showSuccess(withStatus: "音声ダンプを保存")
            } catch let error as NSError {
                print("failed: \(error.localizedDescription)")
                SVProgressHUD.showSuccess(withStatus: "updateRecordSaveFlag:保存フラグ更新しましたf")
            }
        }
    }

    
    
    class func getAudioDumpDic()->NSMutableArray?{
        var retDictionary:NSDictionary? = nil
        var retArray:NSMutableArray? = nil
        
        let database = FMDatabase(path: gdbfileURL.path)
        
        if !(database?.open())! {
            SVProgressHUD.showError(withStatus: "データベースエラ:DB open failed")
            print("Unable to open database")
            return nil
        }
        
        do {
            if(database?.tableExists(kAudioDumpTableName) == false){
                database?.close()
                return nil
            }
            
            let rs = try database?.executeQuery(kSelectAudioDumpListSQL, values: nil)
            while (rs?.next())! {
                retDictionary = rs?.resultDictionary() as! NSDictionary
                if(retDictionary == nil){
                    return nil
                }
                if(retArray == nil){
                    retArray = NSMutableArray()
                }
                retArray?.add(retDictionary!)
            }
            database?.close()
            return retArray
            
        } catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        
        return nil
    }
    
    
    
    class func deleteAudioDumpByName(_ filename:String?){
        if(filename == nil){
            return
        }
        
        let database = FMDatabase(path: gdbfileURL.path)
        
        if !(database?.open())! {
            SVProgressHUD.showError(withStatus: "データベースエラ:DB open failed")
            print("Unable to open database")
            return
        }
        
        do {
            if(database?.tableExists(kAudioDumpTableName) == false){
                database?.close()
                return
            }
            
            let updateSQL = "delete from  " + kAudioDumpTableName + " where filename = '" + filename! + "'"
            
            try database?.executeUpdate(updateSQL, values: nil)
            
        } catch let error as NSError {
            SVProgressHUD.showError(withStatus: "データベースエラ:delete recored from  audiotable error")
            print("failed: \(error.localizedDescription)")
        }
        
        database?.close()
    
    
    }
    
    
    
    class func deleteAllRecordFromAudioDump(){
        
        let database = FMDatabase(path: gdbfileURL.path)
        
        if !(database?.open())! {
            SVProgressHUD.showError(withStatus: "データベースエラ:DB open failed")
            print("Unable to open database")
            return
        }
        
        do {
            if(database?.tableExists(kAudioDumpTableName) == false){
                database?.close()
                return
            }
            
            try database?.executeUpdate(kDeleteAllFromaudioDumpTableSQL, values: nil)
            
        } catch let error as NSError {
            SVProgressHUD.showError(withStatus: "データベースエラ:delete recored from  audiotable error")
            print("failed: \(error.localizedDescription)")
        }
        
        database?.close()
        
        
    }
    
//    "update uploadRecordTable set filename = ? , name = ? , work_plan_id = ? ,last_edit_time = ? ,work_primary_id = ?  where original_result_id = ?"
    
    func addNewUploadedRecord(_ filename:String,name:String,
                              work_plan_id:String,
                              last_edit_time:String,
                              original_result_id:String,
                              report_form_id:String,
                              work_primary_id:String?){
        shareFMQueue.inTransaction { db, rollback in
            
            do {
                var rowcount:Int32? = 0
                var addSQL:String = ""
                SVProgressHUD.show(withStatus: "アップロード済みの記録...")
                if(db?.tableExists(kuploadRecordTableName) == false){
                    return
                }
                
                
                let rsc_cnt = try db?.executeQuery(kCountuploadRecordTableSQL, values: nil)
                while (rsc_cnt?.next())! {
                    rowcount = rsc_cnt?.int(forColumn: "COUNT(*)")
                }
                
                if((rowcount == nil)||(rowcount == 0)){//+1 first row
                    addSQL = kAddFisrtUploadedRecordSQL
                }else{//+1
                    let rsc_update = try db?.executeQuery(kSelectUploadedTableByIdSQL, values: [original_result_id])
                    //check update or add new
                    while (rsc_update?.next())! {
                        if(work_primary_id == nil){
                            try db?.executeUpdate(kUpdateUploadedTableSQL, values: [filename,name,work_plan_id,last_edit_time,"",original_result_id])
                        }else{
                            try db?.executeUpdate(kUpdateUploadedTableSQL, values: [filename,name,work_plan_id,last_edit_time,work_primary_id!,original_result_id])
                        }
                        
                        
                        SVProgressHUD.dismiss()
                        return
                    }
                    
                    addSQL = kAddNewUploadeRecordSQL
                    if(rowcount >= kMaxbackupUploadRecord){//count > 10 => -1 +1
                        try db?.executeUpdate(kDeleteOldRecordSQL, values: nil)
                    }
                }
                if(work_primary_id == nil){
                    try db?.executeUpdate(addSQL, values: [filename,name,work_plan_id,last_edit_time,original_result_id, report_form_id,""])
                }else{
                    try db?.executeUpdate(addSQL, values: [filename,name,work_plan_id,last_edit_time,original_result_id, report_form_id,work_primary_id!])
                }
                
                
                

                
                
            } catch let error as NSError {
                print("failed: \(error.localizedDescription)")
                SVProgressHUD.dismiss()
            }
        }
    
    }
    
    class func getUploadRecord()->NSMutableArray?{
        let database = FMDatabase(path: gdbfileURL.path)
        var retDictionary:NSDictionary? = nil
        var retArray:NSMutableArray? = nil

        if !(database?.open())! {
            SVProgressHUD.showError(withStatus: "データベースエラ:DB open failed")
            print("Unable to open database")
            return nil
        }
        
        do {
            if(database?.tableExists(kuploadRecordTableName) == false){
                database?.close()
                return nil
            }
            
            let rsc = try database?.executeQuery(kSelectUploadedTableSQL, values: nil)
           
            while (rsc?.next())! {
                retDictionary = rsc?.resultDictionary() as! NSDictionary
                if(retDictionary == nil){
                    continue
                }
                if(retArray == nil){
                    retArray = NSMutableArray()
                }
                retArray?.add(retDictionary!)
            }
        } catch let error as NSError {
            SVProgressHUD.showError(withStatus: "データベースエラ:delete recored from  audiotable error")
            print("failed: \(error.localizedDescription)")
        }
        
        database?.close()
        return retArray
    }
    
    
    class func removeUploadTableAllData(){
        let database = FMDatabase(path: gdbfileURL.path)
//        var retDictionary:NSDictionary? = nil
//        var retArray:NSMutableArray? = nil
        
        if !(database?.open())! {
            SVProgressHUD.showError(withStatus: "データベースエラ:DB open failed")
            print("Unable to open database")
            return
        }
        
        do {
            if(database?.tableExists(kuploadRecordTableName) == false){
                database?.close()
                return
            }
            
            try database?.executeUpdate(kDeleteAllFromUploadedTableSQL, values: nil)
            

        } catch let error as NSError {
            SVProgressHUD.showError(withStatus: "データベースエラ:delete recored from  uploadRecordTable error")
            print("failed: \(error.localizedDescription)")
        }
        
        database?.close()
    }
    
    
}
