//
//  PVDQRReader.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/28.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import AVFoundation
import SVProgressHUD

protocol PVDQRCodeReaderDelegate {
    func didDetectQRCode(_ metaObject:AVMetadataMachineReadableCodeObject)
}
class PVDQRReader: NSObject,AVCaptureMetadataOutputObjectsDelegate {
    var captureMetadataOutput:AVCaptureMetadataOutput!
    var captureSession:AVCaptureSession!
    var captureVideoPreviewLayer:AVCaptureVideoPreviewLayer!
    
    var delegate:PVDQRCodeReaderDelegate! = nil
    override init(){
        super.init()
        
        

    }
    
    class var sharedInstance : PVDQRReader {
        struct Static {
            static let instance : PVDQRReader = PVDQRReader()
            
        }
        return Static.instance
    }

    //MARK:AVCaptureMetadataOutputObjectsDelegate
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!){
        for metadataObject in metadataObjects{
            if metadataObject is AVMetadataMachineReadableCodeObject{
                let machineReadableCode:AVMetadataMachineReadableCodeObject = metadataObject as! AVMetadataMachineReadableCodeObject
                if(self.delegate != nil){
                    self.delegate?.didDetectQRCode(machineReadableCode)
                }
            }
        }
    }
    
    

    func startReaderOnView(_ view:UIView,pannel:UIView,camera:AVCaptureDevicePosition,firstIn:Bool){
        
        var captureDevice:AVCaptureDevice? = nil
        for aCaputureDevice in AVCaptureDevice.devices(){
            if let tmpDevice =  aCaputureDevice as? AVCaptureDevice{
                if(tmpDevice.position == camera){
                    captureDevice = tmpDevice
                }
            }
        }
        if(captureDevice == nil){
            NSLog("Couldn't find rear camera.")
            return
        }
        var captureDeviceInput:AVCaptureDeviceInput!
        do{
            try captureDeviceInput =  AVCaptureDeviceInput(device: captureDevice)
        }catch{
            SVProgressHUD.showError(withStatus: String(describing: error))
            print(error)
            
        }
        
        self.captureSession = AVCaptureSession()
        self.captureSession.sessionPreset = AVCaptureSessionPresetHigh
        if(self.captureSession.canAddInput(captureDeviceInput)){
            self.captureSession.addInput(captureDeviceInput)
        }
        // Create capture metadata output and add to the session
        self.captureMetadataOutput = AVCaptureMetadataOutput()
        self.captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        if(self.captureSession.canAddOutput(self.captureMetadataOutput)){
            self.captureSession.addOutput(self.captureMetadataOutput)
        }
        self.captureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode,AVMetadataObjectTypeDataMatrixCode,AVMetadataObjectTypeUPCECode,AVMetadataObjectTypeCode39Code,AVMetadataObjectTypeCode39Mod43Code,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeCode93Code,AVMetadataObjectTypeCode128Code,AVMetadataObjectTypePDF417Code,AVMetadataObjectTypeAztecCode,AVMetadataObjectTypeInterleaved2of5Code,AVMetadataObjectTypeITF14Code]
        captureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)

        
        var tpsize:CGSize  = UIScreen.main.bounds.size
        tpsize.height = tpsize.height - pannel.frame.height - 20
        captureVideoPreviewLayer.frame = CGRect(x: 0, y: 0, width: tpsize.width, height: tpsize.height)

        captureVideoPreviewLayer.connection.videoOrientation = transformOrientation(UIInterfaceOrientation(rawValue: UIApplication.shared.statusBarOrientation.rawValue)!)
        captureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        view.layer.addSublayer(captureVideoPreviewLayer)
        self.captureSession.startRunning()
        
        
    }
    
    func stopReader(){
        self.captureSession.stopRunning()
        captureVideoPreviewLayer.removeFromSuperlayer()

    }
    
    func transformOrientation(_ orientation: UIInterfaceOrientation) -> AVCaptureVideoOrientation {
        switch orientation {
        case .landscapeLeft:
            return .landscapeLeft
        case .landscapeRight:
            return .landscapeRight
        case .portraitUpsideDown:
            return .portraitUpsideDown
        default:
            return .portrait
        }
    }
    
  

}
