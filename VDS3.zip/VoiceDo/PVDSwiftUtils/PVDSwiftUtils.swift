//
//  PVDSwiftUtils.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/14.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import KeychainAccess
import ObjectMapper
import SVProgressHUD
import SystemConfiguration
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func >= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l >= r
  default:
    return !(lhs < rhs)
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}



extension String {
    
    subscript (i: Int) -> Character {
        return self[self.characters.index(self.startIndex, offsetBy: i)]
    }
    
    subscript (i: Int) -> String {
        return String(self[i] as Character)
    }
    
    subscript (r: Range<Int>) -> String {
  
        let rangex = characters.index(startIndex, offsetBy: r.lowerBound) ..< characters.index(startIndex, offsetBy: r.upperBound)
        return self.substring(with: rangex)
    }
}


open class PVDSwiftUtils: NSObject {
//    var cm:CBCentralManager! =  CBCentralManager(delegate: self, queue: nil)
    public struct PVDRegonisationOption : OptionSet {
        public let rawValue: Int
        public init(rawValue:Int){ self.rawValue = rawValue}
        //default イレギュラーの出力
        public static let unregonisedType          = PVDRegonisationOption(rawValue: 0)
        
        //普通の出力
        public static let naturalWordType          = PVDRegonisationOption(rawValue: 1)
        
        //コントロールコマンド
        public static let commandType              = PVDRegonisationOption(rawValue: 1 << 2)
        
        //作業者
        public static let userType                 = PVDRegonisationOption(rawValue: 1 << 3)
        
        //作業名
        public static let workType                 = PVDRegonisationOption(rawValue: 1 << 4)
        
    }
    class var sharedInstance: PVDSwiftUtils {
        struct Static {
            static let instance: PVDSwiftUtils = PVDSwiftUtils()
        }
        return Static.instance
    }
    

    
    func getSettingStatus()->PVDSettingStatusListModel{
        let list:PVDSettingStatusListModel = PVDSettingStatusListModel()
//
////        let connecteds = EAAccessoryManager.sharedAccessoryManager().connectedAccessories
//        
//        // Initialize a private variable with the heart rate service UUID
//        let heartRate = CBUUID(string: "180D")
//        // Create a dictionary for passing down to the scan with service method
//        
//        let scanOptions = NSDictionary(object: NSNumber(bool: false), forKey: CBCentralManagerScanOptionAllowDuplicatesKey)
//        NSDictionary *scanOptions = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:CBCentralManagerScanOptionAllowDuplicatesKey];
        
        // Tell the central manager (cm) to scan for the heart rate service
//        cm.scanForPeripheralsWithServices([heartRate], options: scanOptions as! [String : AnyObject])
        
        
        
        
        let headset:PVDSettingStatusModel = PVDSettingStatusModel()
        //ヘッドセット チェック
        headset.title = "ヘッドセット"
        headset.result = (PSRSoundRec.shareInstance() as AnyObject).connecttypeString()
        headset.detail = "▶︎「接続なし」でないか確認"
        list.items = [headset]
        //話者チェック
        let speaker:PVDSettingStatusModel = PVDSettingStatusModel()
        speaker.title = "作業者(話者)"
        speaker.result = gsettingModel.choosedSpeaker
        speaker.detail = "▶︎女性発話時に「男性」になってないか？"
        list.items?.append(speaker)
        //騒音チェック
        let noise:PVDSettingStatusModel = PVDSettingStatusModel()
        noise.title = "騒音最適化"
        noise.result = gsettingModel.envDetail
        noise.detail = "▶︎周囲の騒音に合った設定か"
        list.items?.append(noise)
        //入力待ちモード
        let waitmode:PVDSettingStatusModel = PVDSettingStatusModel()
        waitmode.title = "入力待ちモード"
        let onWait:String? = UserDefaults.standard.object(forKey: kHVDWaitModeOnFlagKey) as? String
        if(onWait == "true"){
            waitmode.result = "オン"
        }else{
            waitmode.result = "オフ"
        }
        waitmode.detail = "▶︎オンの時は、最初に「入力」と発話する"
        list.items?.append(waitmode)
        let twochInput:PVDSettingStatusModel = PVDSettingStatusModel()
        twochInput.title = "２音声入力"
        if(gsettingModel.voiceDoChannel == "1ch"){
            twochInput.result = "オフ"
        }else{
            twochInput.result = "オン"
        }
        twochInput.detail = "▶︎VoiceDo専用ヘッドセット利用時以外は「オフ」"
        list.items?.append(twochInput)
        //rule
        let ruleDetail:PVDSettingStatusModel = PVDSettingStatusModel()
        ruleDetail.title = "音声認識ルール"
        ruleDetail.detail = (PSRManager.shareInstance() as AnyObject).lastRule + "(" + (PSRManager.shareInstance() as AnyObject).currentDetail + ")"
        list.items?.append(ruleDetail)
        
        
        
        
        
        return list
    }
    
    
    
    /**
       現在のレポートを指定のjsonfileに登録(ホーム画面の表示用のもの)、落ちる時とアプリ切るする時も結果を保存するために一結果ごとにファイル保存をしている
     
     - parameter finishedflag:  true:完了へ登録   false未完了へ保存
     - parameter resultModel:         ホームの作業結果
     */
//    class func appendlistJsonFile(_ finishedflag:Bool,
//        resultModel:PVDReportResultModel){
//            //create or general unfinished json list
//        
//        var dataDic:[String:Any]!
//        var tmplist:PVDWaitingListModel!
//        if(finishedflag == false ){
//            dataDic = PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)
//        }else{
//            dataDic = PVDSwiftUtils.getDictionarybyFullPathS(kfinishedJsonPath)
//        }
//        var neworiginal_result_id = ""
//        if(resultModel.original_result_id == nil){
//            neworiginal_result_id  = gsettingModel.deviceid! + "_" + resultModel.work_plan_id!
//        }else{
//            neworiginal_result_id = resultModel.original_result_id!
//        }
//        var tmpDic:[String:Any]!
//        //work primary id とwork plan idの辞書を分けて使う
//        if(resultModel.work_primary_id == nil){
//            tmpDic = ["name":resultModel.report_form_name!,
//                "report_form_id":resultModel.report_form_id!,
//                "work_plan_id":resultModel.work_plan_id!,
//                "original_result_id":neworiginal_result_id,
//                "last_edit_time":PVDSwiftUtils.getoutputTimeStamp(Date())]
//            
//            
//        }else{
//            tmpDic = ["name":resultModel.report_form_name!,
//                "report_form_id":resultModel.report_form_id!,
//                "work_plan_id":resultModel.work_plan_id!,
//                "original_result_id":neworiginal_result_id,
//                "last_edit_time":PVDSwiftUtils.getoutputTimeStamp(Date()),
//                "work_primary_id":resultModel.work_primary_id!]
//        }
//        let newItem = Mapper<PVDWaitingModel>().map(JSON: tmpDic)
////        let newItem = Mapper<PVDWaitingModel>().map(newItemDic)
//        if(dataDic == nil){
//            dataDic = ["list":[tmpDic]]
//            tmplist = Mapper<PVDWaitingListModel>().map(JSON: dataDic)
//        }else{
//            tmplist = Mapper<PVDWaitingListModel>().map(JSON: dataDic)
//            if(resultModel.original_result_id != nil){
//                var deleIndex = -1
//
//                for (index,item) in tmplist.waitingItems!.enumerated(){
//                    if(item.original_result_id == resultModel.original_result_id){
//                        deleIndex = index
//                        break
//                    }
//                }
//                if(deleIndex != -1){
//                    tmplist.waitingItems?.remove(at: deleIndex)
//                }
//            }
//            
//            
//            
//            tmplist?.waitingItems?.append(newItem!)
//            
//        }
//        
//        let tJSONString = Mapper().toJSONString(tmplist, prettyPrint: true)
//        if(finishedflag == false ){
//            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
//        }else{
//            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kfinishedJsonPath)
//        }
//        
//    }
//    
    
    class func getDebugOutputTimeStamp(_ date:Date)->String {
        if(gDebugTimeStampFormat == nil){
            gDebugTimeStampFormat = DateFormatter()
            gDebugTimeStampFormat.dateFormat = "yyyy/MM/dd HH:mm:ss.SSS"
        }
        return gDebugTimeStampFormat.string(from: date)
    }
    
    class func getoutputTimeStamp(_ date:Date)->String {
        if(gresultTimeStampFormat == nil){
            gresultTimeStampFormat = DateFormatter()
            gresultTimeStampFormat.dateFormat = "yyyy/MM/dd HH:mm:ss"
        }
        return gresultTimeStampFormat.string(from: date)
    }
    
    class func getTimeIntervalFromTimeString(_ dateString:String)->TimeInterval{
        if(gresultTimeStampFormat == nil){
            gresultTimeStampFormat = DateFormatter()
            gresultTimeStampFormat.dateFormat = "yyyy/MM/dd HH:mm:ss"
        }
        let ret = gresultTimeStampFormat.date(from: dateString)?.timeIntervalSince1970
        if(ret != nil){
            return ret!
        }else{
            return 0
        }
        
    }
    
    class func getworkshareTimeStamp(_ date:Date)->String {
        if(gworkshareTimeStampFormat == nil){
            gworkshareTimeStampFormat = DateFormatter()
            gworkshareTimeStampFormat.dateFormat = "yyyyMMddHHmmss"
        }
        return gworkshareTimeStampFormat.string(from: date)
    }

    
    
    /**
     特定のフォスダのファイルを全部をバックアップフォルダーに移す
     
     - parameter fullPath: 移すフォルダー
     */
    class func moveuploadedFileToBackup(_ fullPath:String){
        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            try! FileManager.default.createDirectory(at: URL(fileURLWithPath: kbackupFolder), withIntermediateDirectories: true, attributes: nil)
        }
        
        if(FileManager.default.fileExists(atPath: fullPath) == true){
            let dirEnum:FileManager.DirectoryEnumerator = FileManager.default.enumerator(atPath: fullPath)!
            var tmppath:String? = dirEnum.nextObject() as? String
            while( tmppath != nil){
                if(tmppath![0] == "."){
                    continue
                }
                
                let fromPath:String = fullPath + "/" + tmppath!
                let toPath:String = kbackupFolder  + "/" + tmppath!
                if(FileManager.default.fileExists(atPath: toPath) == true){
                    //元のファイルを削除して、新しいファイルを適用
                    try! FileManager.default.removeItem(atPath: toPath)
                }
                
                
                do{
                    try FileManager.default.moveItem(atPath: fromPath, toPath: toPath)
                }catch{
                    print(error)
                    NSLog("移動失敗")
                    return
                }
                tmppath = dirEnum.nextObject() as? String
                
            }
            
        }else{
            NSLog("downloadpath not found:%@",fullPath)
        }
        
        
        
    }
    
    
    class func showInfoWithColor(_ color:UIColor,message:String){
        SVProgressHUD.setDefaultStyle(.custom)
        SVProgressHUD.appearance().backgroundColor = color
        SVProgressHUD.appearance().foregroundColor = UIColor.white
        SVProgressHUD.setMinimumSize(CGSize(width: kScreenWidth - 100, height: 40))
        SVProgressHUD.show(UIImage(named: ""), status: message)
//        SVProgressHUD.showInfoWithStatus(message)
        self.dispatchAfterMain(1.5) { (Void) in
            SVProgressHUD.setDefaultStyle(.light)
            SVProgressHUD.appearance().foregroundColor = UIColor.black
            SVProgressHUD.setMinimumSize(CGSize.zero)
            SVProgressHUD.dismiss()
        }
        
        

    }
    

    /**
     インタネットの繋ぎをチェック
     
     - returns: 繋ぎ状態 true:つないてる false:つないてない
     */
    class func isConnectedToNetwork() -> Bool {
        var zeroAddress = sockaddr_in()


        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                zeroSockAddress in SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)}
        } ) else {
            return false
        }
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
    
    /**
        gsettingModelのシステム変数をconfigファイルに保存
    */
    class func saveSettingFile(){

        saveGroupSettingFile()
    }
    class func shareContainerURLPath()->URL?{
        return FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: kAppGroupId)
    }
    

    
    class func saveGroupSettingFile(){
        // Save to sharedContainer
        if(gSavingFileFlag == true){
            return
        }
        gSavingFileFlag = true
        if(shareContainerURLPath() == nil){
            print("share contrain url get failed")
            return
        }
        let srfileURL = shareContainerURLPath()!.appendingPathComponent(kSrFileNameInShareContainer)
        let srfilePath = srfileURL.path
        
        let rJSONString = Mapper().toJSONString(gsettingModel, prettyPrint: true)
        
        let data:Data = rJSONString!.data(using: String.Encoding.utf8)!
        if(FileManager.default.fileExists(atPath: srfilePath) == true ){
            try! FileManager.default.removeItem(at: srfileURL)
        }
        FileManager.default.createFile(atPath: srfilePath, contents: data, attributes: nil)
        gSavingFileFlag = false

    }
    
    
    class func getGroupSettingFileURL()->URL?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kSrFileNameInShareContainer)
    }
    
    
    class func getEngineSettingFilePath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineSettingFileNameInShareContainer).path
    }
    
    
    
    
    class  func getEngineSettingBKFilePath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineSettingBKFileNameInShareContainer).path
    }
    
    class func getEngineDataFilePath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineDataFolderNameInShareContainer).path
//        kengineDicFolderNameInShareContainer
    }
    
    class func getEngineDicFilePath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineDicFolderNameInShareContainer).path
    
    }
    
    class func getShareContainerDomainPath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.path
    }
    
    class func getDefaultUserPathInShareContainerDomainPath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineDefaultUserFolderNameInShareContainer).path
    }
    
    
    
    
    class func getSynthPathInShareContainerDomainPath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineSynthFolderNameInShareContainer).path
    }
    
    class func getTTSEnginePathInShareContainerDomainPath()->String?{
        if(shareContainerURLPath() == nil){
            print("share container url get failed")
            return nil
        }
        return shareContainerURLPath()?.appendingPathComponent(kengineTTSEngineFileNameInShareContainer).path
    }
    
    
    /**
     share containerから再度設定ファイルを読み込む
     */
    class func reloadSettingFile() {
        let settingfileUrl = PVDSwiftUtils.getGroupSettingFileURL()
        var settingDic :[String:Any]? = nil
        if(settingfileUrl?.path != nil){
            settingDic = PVDSwiftUtils.getDictionarybyFullPathS((settingfileUrl?.path)!)
        }
        
        if(settingDic != nil){
            gsettingModel = Mapper<PVDSettingModel>().map(JSON: settingDic!)
        }else{
            dispatch_async_main({ 
                SVProgressHUD.showError(withStatus: "設定ファイルリーロド失敗")
            })
        }
    }
    
    /**
     ホーム画面のjsonリストをから特定のidのレポート記録を削除
     
     - parameter finishedflag: true:完成レポートのjsonlistから削除 false:未完成レポートのjsonlistから削除
     - parameter tWorkPlanId:  work plan id
     */
    class func removejsonFromList(_ finishedflag:Bool,tWorkPlanId:String){
        
        let dataDic:[String:Any]!
        if(finishedflag == false ){
            dataDic =   PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)
        }else{
            dataDic =   PVDSwiftUtils.getDictionarybyFullPathS(kfinishedJsonPath)
        }
        if(dataDic == nil){
            NSLog("nil unfinished json file remove failed")
            return
        }
        let tmplist:PVDWaitingListModel! = Mapper<PVDWaitingListModel>().map(JSON: dataDic)
        var index = 0
        for tmpWaitModel in tmplist.waitingItems!{
            if(tmpWaitModel.workplanid == tWorkPlanId){
                tmplist.waitingItems?.remove(at: index)
                break
            }
            index += 1
        }
        let tJSONString = Mapper().toJSONString(tmplist, prettyPrint: true)
        if(finishedflag == false ){
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
        }else{
            PVDSwiftUtils.overwriteJsonStringTofile( tJSONString!, filePath: kfinishedJsonPath)
        }
    }
  
    
    

    
    
    class func overwriteJsonStringTofile(_ jsonString:String,filePath:String){
        
        let data:Data = jsonString.data(using: String.Encoding.utf8)!
        if(FileManager.default.fileExists(atPath: filePath) == true){
            try! FileManager.default.removeItem(atPath: filePath)
        }
        let writeReuslt:Bool = FileManager.default.createFile(atPath: filePath, contents: data, attributes: nil)
        if(writeReuslt == true){
            print("write file success at:%s",filePath)
        }else{
            print("write file failed at:%s",filePath)
        }
    }
    
    /**
     result json fileを更新
     
     - parameter inputType: kPVDInputTypeUploaded:アップロードずみの結果　　他:未完了に保存->move 
     - parameter jsonString: report resultのjson string
     - parameter workplanid: work plan id
     */
    class func saveReulstfile(_ inputType:String?,jsonString:String?,workplanid:String?){
        if(jsonString == nil){
            NSLog("unable to save file:nil jsonString")
            return
        }
        let tmpResultFileName:String! =  "/result_" + gsettingModel.deviceid! + "_" + workplanid! + ".json"
        let tmpResultFilePath:String!
        
        if(inputType == kPVDInputTypeUploaded){
            if(FileManager.default.fileExists(atPath: kUnfinishedFolderPath) == false){
                //アップロード済みの結果
                try! FileManager.default.createDirectory(atPath: kUnfinishedFolderPath, withIntermediateDirectories: true, attributes: nil)
            }
            
            tmpResultFilePath = kbackupFolder + tmpResultFileName
            //remove old finished
            let oldResultFilePath = kFinishedFolderPath + tmpResultFileName
            if(FileManager.default.fileExists(atPath: oldResultFilePath) == true){
                try! FileManager.default.removeItem(atPath: oldResultFilePath)
            }
        }else{
            if(FileManager.default.fileExists(atPath: kUnfinishedFolderPath) == false){
                //未完成レポート結果
                try! FileManager.default.createDirectory(atPath: kUnfinishedFolderPath, withIntermediateDirectories: true, attributes: nil)
            }
            
            tmpResultFilePath = kUnfinishedFolderPath + tmpResultFileName
        }
        print(tmpResultFilePath)
        overwriteJsonStringTofile(jsonString!, filePath: tmpResultFilePath)
    }
    
    class func getDictionarybyFullPath(_ fullPath:String)->NSDictionary?{
        
        let checkValidation = FileManager.default
        if (checkValidation.fileExists(atPath: fullPath) == false)
        {
            NSLog("ファイル存在しません:%@",fullPath)
            return nil
        }
        var resourceDic: NSDictionary?
        autoreleasepool{
            let resourceData = try! Data(contentsOf: URL(fileURLWithPath: fullPath as String))

            do{
                try resourceDic = JSONSerialization.jsonObject(with: resourceData, options: JSONSerialization.ReadingOptions.allowFragments) as? NSDictionary
            }catch let error as NSError {
                print("JSON変換失敗")
                print(error)
                let nsString = NSString(data: resourceData, encoding: String.Encoding.shiftJIS.rawValue)
                dump(nsString)
                resourceDic = nil
            }
            
            
            if(resourceDic == nil){
                let parseString = NSString(data: resourceData, encoding: String.Encoding.shiftJIS.rawValue)
                let meOfficeData = parseString?.data(using: String.Encoding.utf8.rawValue)
                do{
                    if(meOfficeData != nil){
                        try resourceDic = JSONSerialization.jsonObject(with: meOfficeData!, options: JSONSerialization.ReadingOptions.allowFragments) as? NSDictionary
                    }
                }catch let error as NSError{
                    print(error)
                }
            
            }
        }
        
        
        return resourceDic
    }
    
    
    class func getDictionarybyFullPathS(_ fullPath:String)->[String:Any]?{
        
        let checkValidation = FileManager.default
        if (checkValidation.fileExists(atPath: fullPath) == false)
        {
            NSLog("ファイル存在しません:%@",fullPath)
            return nil
        }
        var resourceDic: [String:Any]?
        autoreleasepool{
            let resourceData = try! Data(contentsOf: URL(fileURLWithPath: fullPath as String))
            
            do{
                try resourceDic = JSONSerialization.jsonObject(with: resourceData, options: JSONSerialization.ReadingOptions.allowFragments) as?  [String:Any]
            }catch let error as NSError {
                print("JSON変換失敗")
                print(error)
                _ = NSString(data: resourceData, encoding: String.Encoding.shiftJIS.rawValue)

                resourceDic = nil
            }
            
            
            if(resourceDic == nil){
                let parseString = NSString(data: resourceData, encoding: String.Encoding.shiftJIS.rawValue)
                let meOfficeData = parseString?.data(using: String.Encoding.utf8.rawValue)
                do{
                    if(meOfficeData != nil){
                        try resourceDic = JSONSerialization.jsonObject(with: meOfficeData!, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:Any]
                    }
                }catch let error as NSError{
                    print(error)
                }
                
            }
        }
        
        
        return resourceDic
    }
    

    class func getDictionaryResourceFromPath(_ pathFromDocument:String)->NSDictionary?{
        
        return getDictionarybyFullPath(kLibDomainPath + "/" + pathFromDocument)
        

    }
    
    class func getDictionaryResourceFromPathS(_ pathFromDocument:String)->[String:Any]?{
        
        return getDictionarybyFullPathS(kLibDomainPath + "/" + pathFromDocument)
        
        
    }
    
    
    class func getSafeStringFromAnyObject(_ input:AnyObject?)->String{
        if(input == nil){
            NSLog("nilの入力値")
            return ""
            
        }else if input is NSNull{
            NSLog("<Null>の入力値")
            return ""
        }else{
            return (input as? String)!
        }
    }
    
    
    class func getSafeStringFromDictionary(_ userdic:AnyObject?,key:String)->String? {
        if(userdic == nil){
            print("userdicがnilです")
            return nil
        }
        if(key.isEmpty == true){
            print("key is empty")
            return nil
        }
        if userdic is NSDictionary{
            print("userdic is NSDictionary ")
        }else{
            print("userdic is not NSDictionary")
        }
        
        let ret:String? = userdic?.object(forKey: key) as? String

        
        return ret
    }
    

    
    
    class func dispatch_async_main(_ block: @escaping () -> ()) {
        DispatchQueue.main.async(execute: block)
    }
    

    
    /**
    分析結果の型をきめる
    
    - parameter srcList: 認識結果の全ての可能性を格納するNSArray、中身は各種のdataのNSArray
    (複数のNSArrayを格納するNSArray)
    - parameter result:  認識結果
    
    - returns: (特定の型(作業者か、作業内容か),extraデータ)
    */
    class func getResultType(_ srcList:NSArray?,vresult:NSString?)->(type:PVDRegonisationOption,extra:AnyObject?){
        
        if((srcList == nil)||(vresult == nil)){
            print("イレギュラーのタイプ認識です")
            return (.unregonisedType,nil)
        }
        let result = String(vresult! as String)
        for tmp in srcList!{
            if let tmpArray = tmp as? NSArray{
                for data in tmpArray {
                    if let usertmp = data as? PVDUserModel{
                        if(usertmp.name == result){
                            return (.userType,nil)
                        }
                    } else if let worktmp = data as? PVDWaitingModel{
                        if(worktmp.waitingTitle == result){
                            return (.workType,nil)
                        }
                    } else if let ctrltmp = data as? PVDControlModel{
                        if(ctrltmp.name == result){

                            return (PVDRegonisationOption.commandType,ctrltmp.ctype.rawValue as AnyObject)
                        }
                        
                    }
                    else {
                        
                        NSLog("%s:srcList引数フォーマット不正",#function)
                    }
                    
                }
                
            }else{
                print("解析列に比較するためのソースarrayがないです")
            }
            
        }
        
        
        return (.naturalWordType,nil)
    }
    
    class func dispatchAfterMain(_ after:TimeInterval,
        afterBlock: ((Void) -> Void)?){
            let time  = DispatchTime.now() + Double(Int64(after * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: time, execute: {
                if(afterBlock != nil){
                    afterBlock!()
                }
            })
    }
    
   
    class func isNumeric(_ a: String) -> Bool {
        return Double(a) != nil
    }
    
    
    class func getIndexByWord(_ indexWord:String)->Int? {
        switch(indexWord){
        case "ひとつめさいかい":
            return 1
        case "ふたつめさいかい":
            return 2
        case "みっつめさいかい":
            return 3
        case "よっつめさいかい":
            return 4
        case "いつつめさいかい":
            return 5
        case "むっつめさいかい":
            return 6
        case "ななつめさいかい":
            return 7
        case "やっつめさいかい":
            return 8
        case "ここのつめさいかい":
            return 9
        default:
            return nil
        }
        
        
        
    }
    

    
    class func timerCountStringToTimeInterval(_ counterString:String)->TimeInterval {
        let eleArray:[String]? = counterString.components(separatedBy: ":")
        if((eleArray == nil)||(eleArray!.count != 3)){
            return 0
        }
        let resultSecond:TimeInterval = (eleArray![2] as AnyObject).doubleValue + (eleArray![1] as AnyObject).doubleValue * 60 + (eleArray![0] as AnyObject).doubleValue * 3600
        
        return resultSecond
    }
    
    class func timerIntervalToFormatString(_ second:TimeInterval,withdecimal:Bool)->String {
        let hourStr = Int(second/3600)
        let miniStr = Int((second.truncatingRemainder(dividingBy: 3600))/60)
        
        let secondStr = Double((second.truncatingRemainder(dividingBy: 3600)).truncatingRemainder(dividingBy: 60) + (second - floor(second)))
        
        let resultString:String
        if(withdecimal == true){
            resultString = String(format: "%02d:%02d:%.03f", hourStr , miniStr ,secondStr)
        }else{
            resultString = String(format: "%02d:%02d:%02d", hourStr , miniStr ,Int(floor(secondStr)))
        }
        
    
        return resultString
    }
    
    class func setKeyChainValueForKey(_ value:String,key:String) {
        let keychain = Keychain(service: kKeyChainKey)
        do {
            try keychain
                .synchronizable(true)
                .set(value, key: key)
        } catch let error {
            print("error: \(error)")
        }
    }
    
    
    class func getKeyChainValueForKey(_ key:String)->String?{
        let keychain = Keychain(service: kKeyChainKey)
        let tmpValue = try! keychain.getString(key)
        return tmpValue
    }
    
    /**
     新しいworkplan id 取得
     - returns: 新しい work plan id
     */
    class func getNextWorkPlanId()->String{

        if((gsettingModel.workPlanId == nil)||(Int(gsettingModel.workPlanId!) == nil)){
            gsettingModel.workPlanId = String("000001")
            
        }else{
            
            gsettingModel.workPlanId = String(format: "%06d", (Int(gsettingModel.workPlanId!)! + 1))
        }
        return gsettingModel.workPlanId!
    
    }
    
    /**
     サーバー更新する際、既存のレポートや帳票を削除する
     */
    class func removeOldfiles(){
        forceremoveFile(kUnfinishedFolderPath)
        forceremoveFile(kFinishedFolderPath)
        forceremoveFile(kUnfinishedJsonPath)
        forceremoveFile(kfinishedJsonPath)
        forceremoveFile(kShareDownloadListJson)//add 2016.09.06
        PVDDatabaseAccess.removeUploadTableAllData()
        //男性女性のユーザーファイルを回避する
        try! FileManager.default.createDirectory(atPath: kSpeakerfileBackupPath, withIntermediateDirectories: true, attributes: nil)
        let malePath:String = kHomeSpeakerFolderPath + "/999999_000000.usr"
        let femalePath:String = kHomeSpeakerFolderPath + "/999999_000001.usr"
        let malePathBK:String = kSpeakerfileBackupPath + "/999999_000000.usr"
        let femalePathBK:String = kSpeakerfileBackupPath + "/999999_000001.usr"
        if((FileManager.default.fileExists(atPath: malePath) == true) && (FileManager.default.fileExists(atPath: femalePath) == true)){
            try! FileManager.default.moveItem(atPath: malePath, toPath: malePathBK)
            try! FileManager.default.moveItem(atPath: femalePath, toPath: femalePathBK)
        }
        //削除
        forceremoveFile(khomejsonFolder)
        //男性女性ユーザー(初期ユーザー)の用意
        if((FileManager.default.fileExists(atPath: malePathBK) == true) && (FileManager.default.fileExists(atPath: femalePathBK) == true)){
            try! FileManager.default.createDirectory(atPath: kHomeSpeakerFolderPath, withIntermediateDirectories: true, attributes: nil)
            try! FileManager.default.moveItem(atPath: malePathBK, toPath: malePath)
            try! FileManager.default.moveItem(atPath: femalePathBK, toPath: femalePath)

            let userDic:[String:Any] = ["user":[["file": "999999_000000.usr","name": "男性","id": "999999_000000"],["file": "999999_000001.usr","name": "女性","id": "999999_000001"]]]
            let defaultUserlist:PVDUserListModel = Mapper<PVDUserListModel>().map(JSON: userDic)!
            let rJSONString = Mapper().toJSONString(defaultUserlist, prettyPrint: true)
            let data:Data = rJSONString!.data(using: String.Encoding.utf8)!

            FileManager.default.createFile(atPath: kHomeSpeakerJsonFilePath, contents: data, attributes: nil)
            
        }
        try! FileManager.default.removeItem(atPath: kSpeakerfileBackupPath)
        //初期話者を男性に戻す
        
        gsettingModel.choosedSpeaker = "男性"
        gsettingModel.choosedSpeakerfilePath = kDefaultMalePath
        PVDSwiftUtils.saveSettingFile()
    }
    
    class func forceremoveFile(_ path:String){
        if(FileManager.default.fileExists(atPath: path)){
            try! FileManager.default.removeItem(atPath: path)
        }
    }
    
    
    
    /**
     アナログを表示、数秒後で消す
     
     - parameter alertTitle:  タイトル
     - parameter alertString: 内容
     - parameter dismissTime: delay時間,単位秒
     */
    class func showAlertAfterDismiss(_ alertTitle:String,alertString:String,dismissTime:TimeInterval){
        DispatchQueue.main.async { () -> Void in
            SVProgressHUD.showInfo(withStatus: alertString)
        }
    }
    
    
    /**
     アナログを表示、数秒後で消す
     
     - parameter alertTitle:  タイトル
     - parameter alertString: 内容
     - parameter dismissTime: delay時間,単位秒
     */
    func showAlertAfterDismiss2(_ alertTitle:String,alertString:String,dismissTime:TimeInterval){
        let noti:UIAlertView = UIAlertView(title: alertTitle, message: alertString, delegate: nil, cancelButtonTitle: nil)
        DispatchQueue.main.async { () -> Void in
            noti.backgroundColor = UIColor.blue
            noti.show()
        }
        print(dismissTime)
        let time  = DispatchTime.now() + Double(Int64(dismissTime * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: time) { () -> Void in
            noti.dismiss(withClickedButtonIndex: 0, animated: false)
        }
        
    }

    
    class func parentTabelFor(_ any:UIView)->UITableView {

        if(any.isKind(of: UITableView.self)){
            return any as! UITableView
        }else{
            return parentTabelFor(any.superview!)
        }
    }
    
    class func parentCellFor(_ view :UIView)->UITableViewCell?{

        if(view.isKind(of: UITableViewCell.self)){
            return view as? UITableViewCell
        }else{
            if(view.superview == nil){
                return nil
            }else{
                return parentCellFor(view.superview!)
            }
            
        }
    }
    
    
    class func backupCrashReport(_ name:String,reason:String,callStackSymbols:String){
        if(FileManager.default.fileExists(atPath: kcrashLogFolder) == false){
            try! FileManager.default.createDirectory(atPath: kcrashLogFolder, withIntermediateDirectories: true, attributes: nil)
        }
        
        let timeStamp =  Date().timeIntervalSince1970
        let crashLogFilePath = String(format: "%@/%f.txt", kcrashLogFolder,timeStamp)
        
        
        let crashString =  String(format: "%@\n%@\n%@\n", name,reason,callStackSymbols)
        let crashData:Data = crashString.data(using: String.Encoding.utf8)!
        FileManager.default.createFile(atPath: crashLogFilePath, contents: crashData, attributes: nil)
        
        
    
    }
    /**
     特定の引き継ぎ元デバイスの前回引き継ぎ時間を取得、存在しない場合はnilを返す
     
     - parameter deviceid: デバイスID
     
     - returns:前回引き継ぎ時間
     */
    class func getLastWorkSharingDownloadTimeByDeviceId(_ deviceid:String)->String?{
        
        if(gsettingModel.workSharingTimeList != nil){
            for tmp in (gsettingModel.workSharingTimeList?.items)!{
                if(tmp.deviceid == deviceid){
                    return tmp.lastUpdatetimestamp
                }
            }
        }
        return nil
    }
    
    
    class func updateLastWorkSharingDownloadTimeByDeviceId(_ deviceid:String,lastWorkSharingDownloadTime:String) {
        if(gsettingModel.workSharingTimeList != nil){
            for tmp in (gsettingModel.workSharingTimeList?.items)!{
                if((tmp.deviceid == deviceid)&&(Double(lastWorkSharingDownloadTime) != nil)&&(Double(tmp.lastUpdatetimestamp!) < Double(lastWorkSharingDownloadTime))){
                    tmp.lastUpdatetimestamp = lastWorkSharingDownloadTime
                    return
                }
            }
        }
        let newDic:[String:Any] = ["deviceid":deviceid,"lastUpdatetimestamp":lastWorkSharingDownloadTime]
        let newModel:PVDworkSharingLastDownloadTimeItemModel = Mapper<PVDworkSharingLastDownloadTimeItemModel>().map(JSON: newDic)!
        newModel.deviceid = deviceid
        newModel.lastUpdatetimestamp = lastWorkSharingDownloadTime
        if(gsettingModel.workSharingTimeList == nil){
            let listDict:[String:Any] = ["items":[["deviceid":deviceid,"lastUpdatetimestamp":lastWorkSharingDownloadTime]]]
            gsettingModel.workSharingTimeList = Mapper<PVDworkSharingLastDownloadTimeModel>().map(JSON: listDict)!
        }else{
            gsettingModel.workSharingTimeList?.items?.append(newModel)
        }
    }

    /**
     数字がsiriに棒読みで読むため数字の前にアンダースコアを追加する
     
     - parameter target: 変換元の文字列
     
     - returns: 変換後の文字列
     */
    class func numberTransForm(_ target:String)->String{

        var result:String = ""
        for c in target.characters
        {
            let s = String(c).unicodeScalars
            let uni = s[s.startIndex]
            
            let digits = CharacterSet.decimalDigits
            if(digits.contains(UnicodeScalar(uni.value)!) == true){
                result = result + "_" + String(c)
            }else{
                result = result + String(c)
            }
        }
        return result

    }
    
    /**
     音声認識コマンドをファイルから読み出し
     
     - returns: 必要なコマンドが全部入っている:true   コマンドがない:false
     */
    class func checkCommandListBind(){
        let commandDic = PVDSwiftUtils.getDictionarybyFullPathS(kbindJsonPath)
        let defaultDic:[String:Any] =  [
        "control_bind":[
        "exit":"中断する",
        "prev":"前に戻る",
        "repeat":"もう一度",
        "next":"ジャンプ",
        "change":"交代する",
        "backhome":"ホームに戻る",
        "again":"次の作業開",
        "continue":"未完了再開",
        "recog_start":"認識再開",
        "recog_stop":"認識一時停止",
        "reload":"リロード",
        "wwait":"入力",
        "finish":"入力完了",
        "move":"移動",
        "wmoveToUnfinished":"未入力移動",
        "wmoveToRequired":"必須移動"]]
        
        
        
        //デフォルト設定
        gcontrolBinds = Mapper<PVDControlCommandModel>().map(JSON: defaultDic[kControlBindKey] as! [String : Any])
        if(commandDic == nil){
            return 
        }
        let controlBindsFromFile = Mapper<PVDControlCommandModel>().map(JSON: commandDic?[kControlBindKey] as! [String : Any])

        if(((controlBindsFromFile?.wexit) != nil)&&((controlBindsFromFile?.wexit) != "")){
            gcontrolBinds.wexit = controlBindsFromFile?.wexit
            
        }
        if(((controlBindsFromFile?.wload) != nil)&&((controlBindsFromFile?.wload) != "")){
            gcontrolBinds.wload = controlBindsFromFile?.wload
            
        }
        if(((controlBindsFromFile?.wprev) != nil)&&(controlBindsFromFile?.wprev) != "" ){
            gcontrolBinds.wprev = controlBindsFromFile?.wprev
            
        }
        if(((controlBindsFromFile?.wnext) != nil)&&(controlBindsFromFile?.wnext != "")) {
            gcontrolBinds.wnext = controlBindsFromFile?.wnext
            
        }
        if((controlBindsFromFile?.wchange != nil)&&(controlBindsFromFile?.wchange != "")){
            gcontrolBinds.wchange = controlBindsFromFile?.wchange
            
        }
        if((controlBindsFromFile?.wbackhome != nil)&&(controlBindsFromFile?.wbackhome != "")){
            gcontrolBinds.wbackhome = controlBindsFromFile?.wbackhome
            
        }
        if((controlBindsFromFile?.wrepeat != nil)&&(controlBindsFromFile?.wrepeat != "")){
            gcontrolBinds.wrepeat = controlBindsFromFile?.wrepeat
            
        }
        if((controlBindsFromFile?.wagain != nil)&&(controlBindsFromFile?.wagain != "")){
            gcontrolBinds.wagain = controlBindsFromFile?.wagain
            
        }
        if((controlBindsFromFile?.wcontinue != nil)&&(controlBindsFromFile?.wcontinue != "")){
            gcontrolBinds.wcontinue = controlBindsFromFile?.wcontinue
            
        }
        if((controlBindsFromFile?.wwait != nil)&&(controlBindsFromFile?.wwait != "")){
            gcontrolBinds.wwait = controlBindsFromFile?.wwait
        }
        if((controlBindsFromFile?.wfinish != nil)&&(controlBindsFromFile?.wfinish != "")){
            gcontrolBinds.wfinish = controlBindsFromFile?.wfinish
        }
        if((controlBindsFromFile?.wmove != nil)&&(controlBindsFromFile?.wmove != "")){
            gcontrolBinds.wmove = controlBindsFromFile?.wmove
        }
        if((controlBindsFromFile?.wmoveToUnfinished != nil)&&(controlBindsFromFile?.wmoveToUnfinished != "")){
            gcontrolBinds.wmoveToUnfinished = controlBindsFromFile?.wmoveToUnfinished
        }
        if((controlBindsFromFile?.wmoveToRequired != nil)&&(controlBindsFromFile?.wmoveToRequired != "")){
            gcontrolBinds.wmoveToRequired = controlBindsFromFile?.wmoveToRequired
        }
        UserDefaults.standard.set(gcontrolBinds.wwait, forKey: kHVDWaitBindKey)
        UserDefaults.standard.synchronize()

    }
    
    class func writeAccessLog(_ logString:String){
        if(FileManager.default.fileExists(atPath: kAccessLogFolderPath) == false){
            try! FileManager.default.createDirectory(atPath: kAccessLogFolderPath, withIntermediateDirectories: true, attributes: nil)
        }
        
        let accessLogPath:String = kAccessLogFolderPath.stringByAppendingPathComponent(gsettingModel.accessLogFileName!)
        PSRManager.writeLog(toFile: (logString + "\n"), filePath: accessLogPath)
    }
    
    
    
    
    
    
    
    
    /**
     行毎にエンジンファイルを処理する、入力のKeyと一致する項目を更新する
     
     - parameter filePath: 入力jsonフィアル
     
     - returns: 更新結果
     */
    class func modifySRinibySettingFile(_ filePath:String)->Bool{
        let l011002 = NSLocalizedString("L011-002", comment: "")
        let uxxx065 = NSLocalizedString("UXXX-065", comment: "")

        let dataDic:NSDictionary? = PVDSwiftUtils.getDictionarybyFullPath(filePath)
        let engineFilePath = PVDSwiftUtils.getEngineSettingFilePath()
        if(engineFilePath == nil){
            PVDSwiftUtils.dispatch_async_main({ 
                SVProgressHUD.showError(withStatus: "エンジンファイル取得失敗")
            })
            return false
        }
        if(dataDic == nil){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: l011002)
            })
            return false
        }
        var fileContents:String! = ""
        do{
            // read everything from text
            fileContents = try String(contentsOfFile: engineFilePath!, encoding: String.Encoding.shiftJIS)
        }catch let error as NSError{
            print(error)
            DispatchQueue.main.async(execute: { 
                SVProgressHUD.showError(withStatus: uxxx065)
            })
        }
        let noiseLevel:Float? = Float((dataDic?.object(forKey: kWhiteNoiseLevel))! as! String)
        if(noiseLevel != nil){
            PSRManager.setNoiseLevel(noiseLevel!)
        }
        let resultString:NSMutableString = ""
        // first, separate by new line
        let allLinedStrings = fileContents.components(separatedBy: CharacterSet.newlines)
        for str in allLinedStrings{
            let rangeOfSp = str.range(of: ";")
            if(rangeOfSp?.lowerBound == str.startIndex){
            
                resultString.append(str + "\n")
                continue
            }
            if(dataDic?.allKeys == nil){
                //更新しない
                return false
            }
            var appendFlag:Bool = true
            for key in (dataDic?.allKeys)!{
                let keyString:String? = key as? String
                if(keyString == nil){
                    continue
                }
                let objectString:String? = dataDic?.object(forKey: keyString!) as? String
                if(objectString == nil){
                    continue
                }
                let rangeOfChange = str.range(of: keyString!)
                //key対象の行
                if(rangeOfChange != nil){
                    resultString.append("\t" + keyString! +  " = " + objectString!  + "\n")
                    appendFlag = false
                    break
                }
            }
            //Key対象以外の行
            if(appendFlag == true){
                resultString.append(str  + "\n")
            }
            
        }
        
        let data:Data = resultString.data(using: String.Encoding.shiftJIS.rawValue)!
        let testPath = NSHomeDirectory().stringByAppendingPathComponent(ksrChangeTmpFile)

        let writeReuslt:Bool = FileManager.default.createFile(atPath: testPath, contents: data, attributes: nil)
        if(writeReuslt == false){

            return false
        }
        if(FileManager.default.fileExists(atPath: filePath) == true){
            try! FileManager.default.removeItem(atPath: engineFilePath!)
        }
        try! FileManager.default.moveItem(atPath: testPath, toPath: engineFilePath!)
        
        return true
    }

    
    
    class func buildInSpeekerLimit()->Bool{
        let uxxx067 = NSLocalizedString("UXXX-067", comment: "")
        if((gsettingModel.audioFourceToUseBuildInSpeakerFlag == true)&&(SpeechTalkManager.sharedInstance.isSpeaking() == true)){
            DispatchQueue.main.async(execute: { 
                SVProgressHUD.showError(withStatus: uxxx067)
            })
            PVDSwiftUtils.dispatchAfterMain(1.5, afterBlock: { (Void) in
                SVProgressHUD.dismiss()
            })
            return true
        }else{
            return false
        }
        
    }
    
    
//    class  func replaceJsonValueByRegex(target:String,value:String) {
//        let pattern:String = String(format: "\"%s\"")
//        do{
//            self.internalRegexp = try NSRegularExpression( pattern: pattern, options: NSRegularExpressionOptions.CaseInsensitive)
//        }catch let error {
//            print("\(error)")
//            self.internalRegexp = nil
//        }
//    }

    
    class func evaluateCondition(_ item_name:String,target_val:String,expression:String)->(Bool?,String){
        var strCnd = "条件:"
        var strTmp:String
        if(item_name.characters.count > 17){
            strTmp = item_name.substring(0, length: 16)
        }else{
            strTmp = item_name
        }
        
        strCnd = strCnd + strTmp
        if(strTmp == item_name){
            strCnd = strCnd + "..."
        }
        strCnd = strCnd + "が"
        var condition_type = "OR"
        var aryExpression = expression.components(separatedBy: "/")
        if (aryExpression.count < 2){
            aryExpression = expression.components(separatedBy: "&");
            if (aryExpression.count > 1){
                condition_type = "AND";
            }
        }


        let pattern = "(>=)|(<=)|(<>)|(=)|(>)|(<)"
//        let pattern = "((=)|(>)|(<)|(>=)|(<=)|(<>))\\d+(\\.\\d+)*"
        var i:Int32 = 0
        var ret:Bool? = nil
        var x = false
        let ftarget:Float? = Float(target_val)
        
        
        for iExpression in  aryExpression {
            let itemExpression = iExpression.replacingOccurrences(of: "\n", with: "")
            var words = ["OR":"か ","AND":"かつ "]
           
            let mactches:[String]? = Regexp(pattern).matches(itemExpression)
            var operators:String = ""
            var comparer:String = ""
            if(i > 0){
                strCnd = strCnd + words[condition_type]!
            }
            if(mactches == nil){//数式ではない
                operators = "="
                comparer = itemExpression
                x = (String(target_val) == String(itemExpression))
                strCnd = strCnd + itemExpression
            }else{
                operators = mactches![0]
                comparer = itemExpression.substring(operators.characters.count, length: itemExpression.characters.count - operators.characters.count)
                
                let fcomaper:Float? = Float(comparer)
                
                
                switch operators {
                case ">=":
                    x = (ftarget >= fcomaper)
                    strCnd = strCnd + ">="
                    break
                case "<=":
                    x = (ftarget <= fcomaper)
                    strCnd = strCnd + "<="
                    break
                case "=":
                    x = (ftarget == fcomaper)
                    strCnd = strCnd + "="
                    break
                case ">":
                    x = (ftarget > fcomaper)
                    strCnd = strCnd + ">"
                    break
                case "<":
                    x = (ftarget < fcomaper)
                    strCnd = strCnd + "<"
                    break
                case "<>":
                    x = (ftarget != fcomaper)
                    strCnd = strCnd + "!="
                    break
                default:
                    print("evaluateCondition未処理")
                    x = false
                    break
                }
            }
            



            i = i + 1
            if((x == true)&&(ret == nil)){
                if(condition_type == "OR"){
                    ret = true
                }
            }else{
                if(condition_type == "AND"){
                    ret = false
                }
            }
            
        }
        
        if(ret == nil){
            if(condition_type == "OR"){
                ret = false
            }else{
                ret = true
            }
        }
        
        
        return (ret,strCnd)
    }
    
    
    class func removeFinishedJson(){
        
        
        let dataDic =   PVDSwiftUtils.getDictionarybyFullPathS(kfinishedJsonPath)
        if(dataDic == nil){
            NSLog("nil unfinished json file remove failed")
            return
        }
        let tmplist:PVDWaitingListModel! = Mapper<PVDWaitingListModel>().map(JSON: dataDic!)
        
        for tmpWaitModel in tmplist.waitingItems!{
            if(tmpWaitModel.original_result_id == nil){
                continue
            }
            let tpfileName = "/result_" + tmpWaitModel.original_result_id! + ".json"
            let tpfinishedfilePath:String =  kFinishedFolderPath + tpfileName
            print(tpfileName)
            print(tpfinishedfilePath)
            if(FileManager.default.fileExists(atPath: tpfinishedfilePath) == false){
                continue
            }
            
            PVDDatabaseAccess.sharedInstance.addNewUploadedRecord(tpfileName, name: tmpWaitModel.waitingTitle!, work_plan_id: tmpWaitModel.workplanid!, last_edit_time: tmpWaitModel.lasteditDate!, original_result_id: tmpWaitModel.original_result_id!, report_form_id: tmpWaitModel.reportId!, work_primary_id: tmpWaitModel.work_primary_id)
            
        }
        
        if(FileManager.default.fileExists(atPath: kfinishedJsonPath) == true){
            try! FileManager.default.removeItem(at: URL(fileURLWithPath: kfinishedJsonPath))
        }
        
        
        
    }
    
    
    
    class func updateWorkShareState(byWorkPlanId:String){
        var dataDic:[String:Any]!
        var tmplist:PVDWaitingListModel!
        dataDic =   PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)
        if(dataDic == nil){
            return
        }
        tmplist = Mapper<PVDWaitingListModel>().map(JSON: dataDic!)
        if let upindex = tmplist.waitingItems?.index(where: {$0.workplanid == byWorkPlanId}) {
            
            let item = tmplist.waitingItems?[upindex]
            item?.work_sharing_uploaded = true
        }
        
        let tJSONString = Mapper().toJSONString(tmplist, prettyPrint: true)
        PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
    
    }

    

}
