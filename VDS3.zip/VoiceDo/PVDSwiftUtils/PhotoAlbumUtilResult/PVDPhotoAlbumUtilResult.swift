//
//  PVDPhotoAlbumUtilResult.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/05.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import AssetsLibrary
import Photos

enum PhotoAlbumWriteUtilResult {
    case success, error, denied
}


enum PhotoAlbumReadUtilResult {
    case success, error, denied
}


class PVDPhotoAlbumUtil: NSObject {
    
    class func isAuthorized() -> Bool {
        if (UIDevice.current.systemVersion as NSString).floatValue < 8 {
            return ALAssetsLibrary.authorizationStatus() == ALAuthorizationStatus.authorized || ALAssetsLibrary.authorizationStatus() == ALAuthorizationStatus.notDetermined
        } else {
            return PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized || PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.notDetermined
        }
    }
    
    class func saveImageInAlbum(_ image: UIImage, albumName: String, completion: ((_ result: PhotoAlbumWriteUtilResult) -> ())?) {
        
        if albumName.isEmpty {
            completion?(.error)
            return
        }
//SWIFT3_MIGRATION:未実装昨日につきSWIFT2.3->3.0移行対象外
//        if (UIDevice.current.systemVersion as NSString).floatValue < 8 {
            if  !isAuthorized() {
                completion?(.denied)
                return
            }
            var found = false
            let library = ALAssetsLibrary()
            library.enumerateGroupsWithTypes(ALAssetsGroupAlbum, usingBlock: { (group: ALAssetsGroup!, stop: UnsafeMutablePointer<ObjCBool>) in
                if group != nil {
                    if albumName == group.value(forProperty: ALAssetsGroupPropertyName) as! String {
                        found = true
                        library.writeImage(toSavedPhotosAlbum: image.cgImage, orientation: ALAssetOrientation(rawValue: image.imageOrientation.rawValue)!, completionBlock: { (assetUrl: URL!, error: NSError!) in
                            library.asset(for: assetUrl, resultBlock: { (asset: ALAsset!) in
                                group.add(asset)
                                completion?(.success)
                                }, failureBlock: { (error: NSError!) in
                                    print(error.localizedDescription)
                                    completion?(.error)
                            } as! ALAssetsLibraryAccessFailureBlock)
                        } as! ALAssetsLibraryWriteImageCompletionBlock)
                    }
                } else {
                    if !found {
                        library.writeImage(toSavedPhotosAlbum: image.cgImage, orientation: ALAssetOrientation(rawValue: image.imageOrientation.rawValue)!, completionBlock: { (assetUrl: URL!, error: NSError!) in
                            library.addAssetsGroupAlbum(withName: albumName, resultBlock: { (group: ALAssetsGroup!) in
                                library.asset(for: assetUrl, resultBlock: { (asset: ALAsset!) in
                                    group.add(asset)
                                    completion?(.success)
                                    }, failureBlock: { (error: NSError!) in
                                        print(error.localizedDescription)
                                        completion?(.error)
                                } as! ALAssetsLibraryAccessFailureBlock)
                                }, failureBlock:  { (error: NSError!) in
                                    print(error.localizedDescription)
                                    completion?(.error)
                            } as! ALAssetsLibraryAccessFailureBlock)
                        } as! ALAssetsLibraryWriteImageCompletionBlock)
                    }
                }
                } as! ALAssetsLibraryGroupsEnumerationResultsBlock, failureBlock:  { (error: NSError!) in
                    print(error.localizedDescription)
                    completion?(.error)
            } as! ALAssetsLibraryAccessFailureBlock)
//SWIFT3_MIGRATION:未実装昨日につきSWIFT2.3->3.0移行対象外
//        } else {
//            if  !isAuthorized() {
//                completion?(.denied)
//                return
//            }
//            var assetAlbum: PHAssetCollection?
//            let list = PHAssetCollection.fetchAssetCollections(with: PHAssetCollectionType.album, subtype: PHAssetCollectionSubtype.any, options: nil)
//            list.enumerateObjects{ (album, index, isStop) in
//                let assetCollection = album as! PHAssetCollection
//                if albumName == assetCollection.localizedTitle {
//                    assetAlbum = assetCollection
//                    isStop.pointee = true
//                }
//            }
//            if let album = assetAlbum {
//
//                PHPhotoLibrary.shared().performChanges({
//                    let result = PHAssetChangeRequest.creationRequestForAsset(from: image)
//                    let assetPlaceholder = result.placeholderForCreatedAsset
//                    let albumChangeRequset = PHAssetCollectionChangeRequest(for: album)
//                    let enumeration: NSArray = [assetPlaceholder!]
//                    albumChangeRequset!.addAssets(enumeration)
//                    }, completionHandler: { (isSuccess: Bool, error: NSError?) in
//                        if isSuccess {
//                            completion?(.success)
//                        } else{
//                            print(error!.localizedDescription)
//                            completion?(.error)
//                        }
//                        
//                } as! (Bool, Error?) -> Void)
//            } else {
//                PHPhotoLibrary.shared().performChanges({
//                    PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle: albumName)
//                    }, completionHandler: { (isSuccess, error) in
//                        self.saveImageInAlbum(image, albumName: albumName, completion: completion)
//                })
//            }
//        }
    }
    
    
    class func loadPhotoByAlbumName(_ albumName:String ,completion: ((_ result: PhotoAlbumReadUtilResult,_ assetsArray:NSArray?) -> ())?){
        if albumName.isEmpty {
            completion?(.error,nil)
            return
        }
        
//        if (UIDevice.current.systemVersion as NSString).floatValue < 8 {
            if  !isAuthorized() {
                completion?(.denied,nil)
                return
            }
            var found = false
            let library = ALAssetsLibrary()
            library.enumerateGroupsWithTypes(ALAssetsGroupAlbum, usingBlock: { (group: ALAssetsGroup!, stop: UnsafeMutablePointer<ObjCBool>) in
                if group != nil {
                    if albumName == group.value(forProperty: ALAssetsGroupPropertyName) as! String {
                        found = true
                        //not support ios under 8 load images
                        assert(true)
                    }
                } else {
                    if !found {
                        //not support ios 8 load images
                        assert(true)
                    }
                }
                } as! ALAssetsLibraryGroupsEnumerationResultsBlock, failureBlock:  { (error: NSError!) in
                    print(error.localizedDescription)
                    completion?(.error,nil)
                    return ;
            } as! ALAssetsLibraryAccessFailureBlock)
//        } else {
//            if  !isAuthorized() {
//                completion?(.denied,nil)
//                return
//            }
//            var assetAlbum: PHAssetCollection?
//            let list = PHAssetCollection.fetchAssetCollections(with: PHAssetCollectionType.album, subtype: PHAssetCollectionSubtype.any, options: nil)
//            list.enumerateObjects{ (album, index, isStop) in
//                let assetCollection = album as! PHAssetCollection
//                if albumName == assetCollection.localizedTitle {
//                    
//                    assetAlbum = assetCollection
//                    isStop.pointee = true
//                    
//                    
//                    // PHAsset をフェッチします
//                    let albumFetchResult:PHFetchResult = PHAsset.fetchAssets(in: assetAlbum!, options: nil)
//                    
//                    let tpassetsArray = NSMutableArray()
//                    
//                    albumFetchResult.enumerateObjects({ (asset, idx, ttstop) -> Void in
//                        
//                        
//                        if let assettp:PHAsset? = asset as? PHAsset{
//                            let vOptions = PHVideoRequestOptions()
//
//                            PHImageManager.default().requestAVAsset(forVideo: assettp!, options: vOptions, resultHandler: { (avsset, aa, bb) -> Void in
//                                
//                            })
//                            
//                            
//
//                            let options:PHImageRequestOptions = PHImageRequestOptions()
//                            options.version = PHImageRequestOptionsVersion.current
//                            options.deliveryMode =  PHImageRequestOptionsDeliveryMode.highQualityFormat
//                            options.resizeMode = PHImageRequestOptionsResizeMode.fast
//                            options.isSynchronous = true
//                            PHImageManager.default().requestImage(for: assettp!, targetSize: CGSize(width: kScreenWidth,height: kScreenHeight), contentMode: PHImageContentMode.aspectFill, options: options, resultHandler: { (image, info) -> Void in
//                                if(image != nil){
//                                    tpassetsArray.add(image!)
//                                }else{
//                                    print("image is null")
//                                }
//                            })
//
//                           
//                        }
//
//                    })
//                    completion?(result: .success,assetsArray:tpassetsArray)
//                    return
//                    
//                    
//                    
//                }
//            }
//
//        }
        
    }
    
    


}
