//
//  SpeachTalkManager.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/02.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import AVFoundation
import SVProgressHUD

typealias DobeforeSpeechBlock = ( _ synthesizer: AVSpeechSynthesizer, _ utterance: AVSpeechUtterance) -> ()
typealias DoafterSpeechBlock = ( _ synthesizer: AVSpeechSynthesizer,  _ utterance: AVSpeechUtterance) -> ()
typealias DoInSpeechBlock = (_ synthesizer: AVSpeechSynthesizer, _ characterRange: NSRange, _ utterance: AVSpeechUtterance)->()

class SpeechTalkManager: NSObject,AVSpeechSynthesizerDelegate {
    var _beforeSpeechBlock:DobeforeSpeechBlock?
    var _afterSpeechBlock:DoafterSpeechBlock?
    var _runLoop:CFRunLoop!
    var _triggerLocation:Int!  //inSpeech block trigger at the index of of the speech words
    var _speechSynthesizer:AVSpeechSynthesizer!
    var _SiriVoice:AVSpeechSynthesisVoice!
    var _ZVoice:AVSpeechSynthesisVoice!
    var _EVoice:AVSpeechSynthesisVoice!
    var stopActionFlag:Bool = false
    var mskipCnt:Int! = 0                   //発話を強制スキップさせる(注意:読み上げ認識をoffにするときのみ有効)
    //MARK:life cycle
    override init(){
        super.init()
        _speechSynthesizer = AVSpeechSynthesizer()
        _speechSynthesizer.delegate = self
        _beforeSpeechBlock = nil
        _afterSpeechBlock = nil
        if(gsettingModel.siriLangurage == nil){
            _SiriVoice = AVSpeechSynthesisVoice(language: "ja-JP")!
        }else{
            _SiriVoice =  AVSpeechSynthesisVoice(language: gsettingModel.siriLangurage)!
        }
        
        
        
        _triggerLocation = Int(kMAXWordInput)

    }
    
    class var sharedInstance : SpeechTalkManager {
        struct Static {
            static let instance : SpeechTalkManager = SpeechTalkManager()
        }
        return Static.instance
    }
    
    func setSiriVoice(_ lang:String){

        if((lang == SiriLangKey.kJapanese.rawValue)||(lang == SiriLangKey.kEnglish.rawValue)||(lang == SiriLangKey.kChinese.rawValue)){
            self._SiriVoice = AVSpeechSynthesisVoice(language: lang)
        }else{
            self._SiriVoice = AVSpeechSynthesisVoice(language: "ja-JP")!
        }
    
    }
    
    
    func stopTalk(_ immediateFlag:Bool){
        NSLog("SPEECH TALK STOP")
        stopActionFlag = true
        if(immediateFlag == true){
            _speechSynthesizer.stopSpeaking(at: .immediate)
        }else{
            _speechSynthesizer.stopSpeaking(at: .word)
        }
        
    }
    func isSpeaking()->Bool{
        return _speechSynthesizer.isSpeaking
    }

    func speechTalk(_ xvalue:String?,forceCancelFlag:Bool){
        if(gsettingModel.audioFourceToUseBuildInSpeakerFlag == true){
            (PSRManager.shareInstance() as AnyObject).audioUseBuildInSpeaker()
        }
        var speechValue:String?
        if(mskipCnt > 0){
            mskipCnt = 0
            speechValue = ""
        }else{
            speechValue = xvalue
        }
        
        stopActionFlag = false
        if(xvalue == nil){
            speechValue = ""
            print("発話内容はnilです:%s,%s",#file,#function)
        }
        
        
        PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
            var transValue:String! = speechValue
            for tmp in gDicForSpeach{
                if let tmpDic = tmp as? PVDDicForSpeachModel{
                    if(transValue.range(of: tmpDic.word) != nil){
                        transValue = transValue?.replacingOccurrences(of: tmpDic.word, with: tmpDic.yomi)
                    }
                }
            }
//            NSLog("置き換えた後の文字:%s", transValue)
            if let selfWeak = self {
                if(selfWeak._speechSynthesizer.isSpeaking){
                    if(forceCancelFlag == true){
                        selfWeak._speechSynthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
                    }else{
//                            selfWeak._speechSynthesizer.stopSpeakingAtBoundary(AVSpeechBoundary.Word)
                    }
                    
                }
                let utterance = AVSpeechUtterance(string: transValue as String)
                
                utterance.voice = selfWeak._SiriVoice
                utterance.pitchMultiplier = 1.0
                utterance.volume = 1.0
                
                utterance.rate = gSiriSpeechRate
                
                
                selfWeak._speechSynthesizer.speak(utterance)
            }
        })

    }
    
    
    
    
    func speechTalkAndDoAction(_ value:String?,forceCancelFlag:Bool,startBlock:DobeforeSpeechBlock?,finishedBlock:DoafterSpeechBlock?){

        _beforeSpeechBlock = startBlock
        _afterSpeechBlock = finishedBlock
        self.speechTalk(value,forceCancelFlag: forceCancelFlag)
    }
    

    
    
    //MARK: speech delegate
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        NSLog("starting speech:%@",utterance.speechString)
        if((_beforeSpeechBlock) != nil){
            _beforeSpeechBlock!(synthesizer,utterance)
            _beforeSpeechBlock = nil
        }
    }
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        NSLog("finished Speech:%@",utterance.speechString)
        if((_afterSpeechBlock != nil)&&(stopActionFlag == false)){
            _afterSpeechBlock!(synthesizer,utterance)
            _afterSpeechBlock = nil
        }
    }
    
    
//    func speechSynthesizer(synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
////        NSLog("range:%@",characterRange)
//        if(characterRange.location >= _triggerLocation){
//            NSLog("trigger action start")
//            if(_duringSpeechBlock != nil){
//                _duringSpeechBlock!(synthesizer: synthesizer,  characterRange: characterRange, utterance: utterance)
//                _triggerLocation = Int(kMAXWordInput)
//                _duringSpeechBlock = nil
//            }
//        }
//    }
    


    

}
