//
//  Regexp.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/07/12.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import Foundation

class Regexp {
    var internalRegexp: NSRegularExpression?
    let pattern: String
    
    init(_ pattern: String) {
        self.pattern = pattern
        do{
            self.internalRegexp = try NSRegularExpression( pattern: pattern, options: NSRegularExpression.Options.caseInsensitive)
        }catch let error {
            print("\(error)")
            self.internalRegexp = nil
        }
        
    }
    
    func isMatch(_ input: String) -> Bool {
        if(self.internalRegexp == nil){
            print("error self.internalRegexp init failed")
            return false
        }
        let matches = self.internalRegexp!.matches( in: input, options: [], range:NSMakeRange(0, input.characters.count) )
        return matches.count > 0
    }
    
    func matches(_ input: String) -> [String]? {
        if(self.internalRegexp == nil){
            print("error self.internalRegexp init failed")
            return nil
        }
        if self.isMatch(input) {
            let matches = self.internalRegexp!.matches( in: input, options: [], range:NSMakeRange(0, input.characters.count) )
            var results: [String] = []
            for i in 0 ..< matches.count {
                
                print((input as NSString).substring(with: matches[i].range))
                print("\n")
                print("matches.count:%d",matches.count)
                results.append( (input as NSString).substring(with: matches[i].range) )
            }
            return results
        }
        return nil
    }
    
}
