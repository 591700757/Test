//
//  PVDAudioFileCell.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/03/01.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDAudioFileCell: UITableViewCell {

    
    @IBOutlet weak var durationLbl: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
