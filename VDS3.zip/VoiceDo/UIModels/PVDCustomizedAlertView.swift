//
//  PVDCustomizedAlertView.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/08/16.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDCustomizedAlertView: UIView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    class func instance() -> PVDCustomizedAlertView {
        
        return UINib(nibName: "PVDCustomizedAlertView", bundle: nil).instantiate(withOwner: self, options: nil)[0] as! PVDCustomizedAlertView
    }

}
