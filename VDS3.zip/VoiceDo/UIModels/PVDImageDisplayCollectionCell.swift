//
//  ImageDisplayCollectionCell.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/08.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDImageDisplayCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var contentImage: UIImageView!
    
    override func layoutSubviews() {
        super.layoutSubviews()
//        contentImage.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight - 40)
        
    }
}
