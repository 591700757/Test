//
//  PVDNoiseAdjustCell.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/06/07.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit


class PVDNoiseAdjustCell: UITableViewCell {
    @IBOutlet weak var cellTitle: UILabel!
    @IBOutlet weak var checkBtn: UIButton!

    @IBOutlet weak var whitebgView: UIView!
    override init(style: UITableViewCellStyle, reuseIdentifier: String!) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        whitebgView.layer.cornerRadius = 5
        whitebgView.clipsToBounds = true
    }
}
