//
//  PVDProcessingCell.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/24.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

protocol PVDProcessingCellDelegate {
    func inputDidBeginEditing(_ textField: UITextField)
    func inputDidEndEditing(_ textField: UITextField)
    func inputDidChangedValue(_ textField: UITextField)
}
class PVDProcessingCell: UITableViewCell,UITextFieldDelegate {

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var inputFld: UITextField!
    @IBOutlet weak var photoBtn: UIButton!
    @IBOutlet weak var titleBImage: UIView!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var descriptionImg: UIImageView!
    
    @IBOutlet weak var heightOfmaxminlbl: NSLayoutConstraint!
    @IBOutlet weak var maxminlbl: UILabel!
    @IBOutlet weak var widthOfUnitlbl: NSLayoutConstraint!
    @IBOutlet weak var unitLbl: UILabel!
    var validateFlag:Bool = false //数値のみチェック false:数値以外を許す  true:数値のみ
    var delegate:PVDProcessingCellDelegate! = nil
    override init(style: UITableViewCellStyle, reuseIdentifier: String!) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        //customize
        inputCellCustomize()

    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        inputFld.delegate = self
        inputFld.placeholder = ""
        inputFld.isEnabled = false
        descriptionImg.contentMode = .scaleAspectFit
    }

    
    func inputCellCustomize(){
        if(gsettingModel.cameraOff == "true"){
            self.photoBtn.isHidden = true
        }else if(gsettingModel.cameraOff == "false"){
            self.photoBtn.isHidden = false
        }else{
            NSLog("wrong key word set to gsettingModel")
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    

    //MARK:textfield delegate
    func textFieldDidBeginEditing(_ textField: UITextField){
        if(delegate != nil){
            self.delegate?.inputDidBeginEditing(textField)

        }
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if(delegate != nil){
            self.delegate?.inputDidEndEditing(textField)
        }
    }
    
    
    
    
    // MARK: UITextFieldDelegate events and related methods
    
    func textField(_ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String)
        -> Bool
    {
        if(string == ""){
            self.delegate.inputDidChangedValue(textField)
            return true
        }
        
        //数値のみチェック
        if(validateFlag == true){
            if string.characters.count == 0 {
                return true
            }
            
            if(delegate != nil){
                self.delegate.inputDidChangedValue(textField)
            }
            
            let currentText = textField.text ?? ""
            let prospectiveText = (currentText as NSString).replacingCharacters(in: range, with: string)
            
            
            return prospectiveText.isNumeric() &&
                prospectiveText.characters.count <= 7
            
        }
        if(delegate != nil){
            self.delegate.inputDidChangedValue(textField)
        }
        return true
        
  
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
}
