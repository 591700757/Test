//
//  PVDProcesssingFreeInputCell.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/01/05.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

protocol PVDProcessingFreeInputCellDelegate {
    func inputViewDidBeginEditing(_ textField: UITextView)
    func inputViewDidEndEditing(_ textField: UITextView)
    func inputViewDidChangedValue(_ textField: UITextView)
    func inputViewShouldBeginEditing(_ textView: UITextView) -> Bool
}

class PVDProcesssingFreeInputCell: UITableViewCell,UITextViewDelegate {
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var inputFld: UITextView!
    @IBOutlet weak var photoBtn: UIButton!
    @IBOutlet weak var titleBImage: UIView!
    @IBOutlet weak var descriptionLbl: UILabel!
    var delegate:PVDProcessingFreeInputCellDelegate! = nil
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        inputFld.delegate = self
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        //customize
        inputCellCustomize()
        
    }
    
    func inputCellCustomize(){
        if(gsettingModel.cameraOff == "true"){
            self.photoBtn.isHidden = true
        }else if(gsettingModel.cameraOff == "false"){
            self.photoBtn.isHidden = false
        }else{
            NSLog("wrong key word set to gsettingModel")
        }
    }
    
    //MARK:textfield delegate
    func textViewDidBeginEditing(_ textView: UITextView) {
        if(delegate != nil){
            self.delegate?.inputViewDidBeginEditing(textView)
            
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if(delegate != nil){
            self.delegate?.inputViewDidEndEditing(textView)
        }
    }
    
    
    func textViewDidChange(_ textView: UITextView) {
        if(delegate != nil){
            self.delegate?.inputViewDidChangedValue(textView)
        }
    }
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        if(delegate != nil){
            return self.delegate.inputViewShouldBeginEditing(textView)
        }else{
            return true
        }
    }
    
   
    

}
