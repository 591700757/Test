//
//  PVDSettingStatusModel.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/08/15.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDSettingStatusModel: NSObject {
    var title:String?
    var result:String?
    var detail:String?
}


class PVDSettingStatusListModel:NSObject{
    var items:[PVDSettingStatusModel]?
}