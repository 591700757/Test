//
//  PVDSettingStatusView.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/08/15.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDSettingStatusView: UIView,UITableViewDelegate,UITableViewDataSource {
    
    /*
     // Only override drawRect: if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func drawRect(rect: CGRect) {
     // Drawing code
     }
     */
    @IBOutlet weak var closeBtn: UIButton!
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var settingStatusTbl: UITableView!
    
    var statuslist:PVDSettingStatusListModel!
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
    
    
    
    
    func prepareSettingView(){
        settingStatusTbl.delegate = self
        settingStatusTbl.dataSource = self
        settingStatusTbl.tableFooterView = UIView()
        settingStatusTbl.separatorInset = UIEdgeInsets.zero
        settingStatusTbl.layoutMargins = UIEdgeInsets.zero
        
        
    }
    
    func reloadSettingStatusTbl(){
        DispatchQueue.main.async {
            self.settingStatusTbl.reloadData()
        }
        
    }
    
    class func instance() -> PVDSettingStatusView {
        
        return UINib(nibName: "PVDSettingStatusView", bundle: nil).instantiate(withOwner: self, options: nil)[0] as! PVDSettingStatusView
    }
    
    // MARK: - tableview delegate and datasource
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath){

        cell.layoutMargins = UIEdgeInsets.zero
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if((statuslist == nil)||(statuslist.items == nil)){
            return 0
        }else{
            return (statuslist.items?.count)!
        }
        
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let statusModel:PVDSettingStatusModel? = statuslist.items![indexPath.row] as? PVDSettingStatusModel
        if(statusModel?.detail == nil){
            return 60
        }
        let labelRect:CGRect = ((statusModel?.detail)! as NSString).boundingRect(with: CGSize(width: kScreenWidth*22/24, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 15)], context: nil)
        if(labelRect.height > 20){
            return 40 + labelRect.height
        }
        return 60
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        tableView.deselectRow(at: indexPath, animated: false)
        
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: kPVDSettingStatusCell)
        var titleLbl:UILabel!
        var resultLbl:UILabel!
        var detailLbl:UILabel!
        if (cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.default,
                                   reuseIdentifier: kPVDSettingStatusCell)
            
            titleLbl = UILabel(frame: CGRect(x: kScreenWidth/24, y: 5, width: kScreenWidth*6/12, height: 20))
            resultLbl = UILabel(frame:CGRect(x: kScreenWidth*15/24, y: 5, width: kScreenWidth*4/12, height: 20))
            detailLbl = UILabel(frame:CGRect(x: kScreenWidth/24,y: 30,width: kScreenWidth*22/24,height: 20))
//            titleLbl.backgroundColor = UIColor.redColor()
//            resultLbl.backgroundColor = UIColor.greenColor()
//            detailLbl.backgroundColor = UIColor.blueColor()
            titleLbl.tag = 10
            resultLbl.tag = 11
            detailLbl.tag = 12
            titleLbl.font = UIFont.systemFont(ofSize: 20)
            resultLbl.font = UIFont.systemFont(ofSize: 20)
            resultLbl.textAlignment = .right
            detailLbl.font = UIFont.systemFont(ofSize: 15)
            detailLbl.numberOfLines = 0
            detailLbl.lineBreakMode = .byWordWrapping
            cell?.addSubview(titleLbl)
            cell?.addSubview(resultLbl)
            cell?.addSubview(detailLbl)
            cell?.backgroundColor = UIColor(red: 122, green: 122, blue: 122, alpha: 0.0)
            
        }
        titleLbl = cell?.viewWithTag(10) as! UILabel
        resultLbl = cell?.viewWithTag(11) as! UILabel
        detailLbl = cell?.viewWithTag(12) as! UILabel
        
        let statusModel:PVDSettingStatusModel? = statuslist.items![indexPath.row] as? PVDSettingStatusModel
        
        
        
        if(statusModel != nil){
            titleLbl.text = statusModel?.title
            resultLbl.text = statusModel?.result
            detailLbl.text = statusModel?.detail
            if(statusModel?.detail != nil){
                let labelRect:CGRect = ((statusModel?.detail)! as NSString).boundingRect(with: CGSize(width: kScreenWidth*22/24, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 15)], context: nil)
                if(labelRect.height > 20){
                    detailLbl.frame = CGRect(x: kScreenWidth/24,y: 30,width: kScreenWidth*22/24,height: labelRect.height)
                }
            }
        }
        
        
        return cell!
        
        
    }
    
    
    
}
