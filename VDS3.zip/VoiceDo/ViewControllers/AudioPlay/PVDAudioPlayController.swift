//
//  AudioPlayController.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/02/29.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import SVProgressHUD
import Alamofire
import ObjectMapper

class PVDAudioPlayController: UIViewController,UITableViewDelegate,UITableViewDataSource,AVAudioPlayerDelegate,MCAudioFileStreamDelegate {
    @IBOutlet weak var dumpTbl: UITableView!
    @IBOutlet weak var playBtn: UIButton!
//    @IBOutlet weak var stopBtn: UIButton!
    @IBOutlet weak var audioSlider: UISlider!
    @IBOutlet weak var sendAudioToEngine: UIButton!
    @IBOutlet weak var leftTimeLbl: UILabel!
    @IBOutlet weak var rightTimeLbl: UILabel!
    @IBOutlet weak var testTextView: UITextView!
    @IBOutlet weak var topSectionView: UIView!
    var heightOftopViewInView:CGFloat!

    var audioPlayer:AVAudioPlayer!
    var playTimer:Timer!
    var audioFilStream:MCAudioFileStream!
    var currentRuleSelected:String?
    var audioDumpList:PVDAudioDataInfoList?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        dumpTbl.delegate = self
        dumpTbl.dataSource = self
        let uxxx031 = String(format: NSLocalizedString("UXXX-031", comment: "Audioファイル一覧"))
        dumpTbl.register(UINib(nibName: "PVDAudioFileCell", bundle: nil), forCellReuseIdentifier: kAudioCellIdentifier)

        dumpTbl.tableFooterView = UIView()

        playTimer = Timer.scheduledTimer( timeInterval: 1.0, target: self, selector: #selector(PVDAudioPlayController.audioPlayTimer(_:)), userInfo: nil, repeats: true)
        
        UserDefaults.standard.set("on", forKey: kAudioDumpModeKey)
        self.title = uxxx031
        
            
        
        
        // Do any additional setup after loading the view.
        NotificationCenter.default.post(name: Notification.Name(rawValue: kReturnToNormalModeNotification), object: nil)
    }
    deinit{

    
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        heightOftopViewInView = topSectionView.frame.height - 30
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDAudioPlayController.showScoreLog(_:)), name: NSNotification.Name(rawValue: kSetLogTextNotification), object: nil)//show log
        NotificationCenter.default.addObserver(self, selector: #selector(PVDAudioPlayController.audioDumpResultAction(_:)), name: NSNotification.Name(rawValue: kAudioDumpResultNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDAudioPlayController.stopInspectionCBAction(_:)), name: NSNotification.Name(rawValue: kStopInspectionCallbackNotification), object: nil)
        gStartInspectionFlag = .kDoNothing
        let itemArray:NSArray? = PVDDatabaseAccess.getAudioDumpDic()
        if(itemArray == nil){
            audioDumpList = nil
        }else{
            let targetDic:[String:Any] = ["items":itemArray!]
            audioDumpList = Mapper<PVDAudioDataInfoList>().map(JSON: targetDic)
        }
        

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.dumpTbl.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self,name: NSNotification.Name(rawValue: kAudioDumpResultNotification),object: nil)
        NotificationCenter.default.removeObserver(self,name: NSNotification.Name(rawValue: kSetLogTextNotification),object: nil)
        NotificationCenter.default.removeObserver(self,name: NSNotification.Name(rawValue: kStopInspectionCallbackNotification),object: nil)
        
        _ = (PSRManager.shareInstance() as AnyObject).voicedoCloseDic()
        if(playTimer != nil){
            playTimer.invalidate()
            playTimer = nil
        }

        UserDefaults.standard.set("off", forKey: kAudioDumpModeKey)

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

    
    // MARK: - tableview delegate

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if((audioDumpList == nil)||(audioDumpList?.items == nil)){
            return 0
        }else{
            return (audioDumpList?.items!.count)!
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: PVDAudioFileCell? = tableView.dequeueReusableCell(withIdentifier: kPVDAudioFileCell, for: indexPath) as? PVDAudioFileCell
        let tempModel:PVDAudioDataModel? = audioDumpList?.items![indexPath.row]
        if(tempModel != nil){
            if(tempModel?.uploadedflag == false){
                cell?.titleLabel.text = tempModel?.name
            }else{
                cell?.titleLabel.text = (tempModel?.name)! + "(アップロード済み)"
            }
            if(tempModel?.audioFileDuration == nil){
                cell!.durationLbl.text  = "NotSet"
                return cell!
            }
            
            let second:TimeInterval? = TimeInterval((tempModel?.audioFileDuration)!)
            if(second == nil){
                cell!.durationLbl.text  = "NotSet"
                return cell!
            }
            cell!.durationLbl.text = String(format: "%02d:%02d",Int(second!/60),Int(second!.truncatingRemainder(dividingBy: 60)))
            
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let tempModel:PVDAudioDataModel? = audioDumpList?.items![indexPath.row]
        let l008012 = String(format: NSLocalizedString("L008-012", comment: "file not found"))
        let l008014 = String(format: NSLocalizedString("L008-014", comment: "file not found"))
        let l008015 = String(format: NSLocalizedString("L008-015", comment: "file not found"))
        let l008001 = String(format: NSLocalizedString("L008-001", comment: "audioplay init failed"))
        
        
        if((tempModel != nil) && (tempModel?.name != nil)){
            let path:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath + (tempModel?.name)!)
            
            let audioPath = URL(fileURLWithPath: path)
            
            // auido を再生するプレイヤーを作成する
            do{
                try audioPlayer = AVAudioPlayer(contentsOf: audioPath)
                print(audioPlayer.numberOfChannels)
            }catch let error as NSError{
                print(error)
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l008001)
                })
                return
            }
            audioPlayer.delegate = self
            audioPlayer.prepareToPlay()
            
            if((tempModel?.userFilePath == nil)||(tempModel?.dictFilePath == nil)||(tempModel?.rule == nil)){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l008012)
                })
            }
            currentRuleSelected = tempModel?.rule
            
            
            let audioSpeakerpath:String = NSHomeDirectory().stringByAppendingPathComponent(kHomeSpeakerFolder + (tempModel?.userFilePath!)!)
            
            let audioDictpath:String = NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + (tempModel?.dictFilePath)!)
            if(FileManager.default.fileExists(atPath: audioSpeakerpath) == false){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l008015)
                })
                return
            }
            if(FileManager.default.fileExists(atPath: audioDictpath) == false){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l008014)
                })
                return
            }
            
            
            //辞書とユーザをAudioDumpの設定に応じて変更する
            let ret = (PSRManager.shareInstance() as AnyObject).voicedoChangeUserAndDic(true, speakerPath: audioSpeakerpath, dicPath: audioDictpath, showMessage: true)
            print(ret)
            
        }
        
    }
    

    
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool{
        return true
        
    }
    
    func tableView( _ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?  {

        let uxxx032 = String(format: NSLocalizedString("UXXX-032", comment: "upload"))
        let uxxx033 = String(format: NSLocalizedString("UXXX-033", comment: "delete"))

        
        let tempModel:PVDAudioDataModel? = audioDumpList?.items![indexPath.row]
        
        // add the action button you want to show when swiping on tableView's cell , in this case add the delete button.
        let uploadAction = UITableViewRowAction(style: .default, title: uxxx032, handler: { (action , indexPath) -> Void in
            if((tempModel == nil) || (tempModel?.name == nil) || ( tempModel?.dictFilePath == nil)){
                return
            }
            
            let dicfileArray:Array? = (tempModel!.dictFilePath?.components(separatedBy: "."))
            let reportId:String = dicfileArray![0]
            let path:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath + (tempModel?.name)!)
            
            var zipName:String = "/" + gsettingModel.userid! + "_" + gsettingModel.deviceid! + "_" + reportId
            zipName = zipName + "_" + (tempModel?.rule)! + "_" + PVDSwiftUtils.getworkshareTimeStamp(Date()) + ".zip"
            let zipPath:String = kDocDomainPath + zipName
            
           
            self.dumpuploadAction(path,index: indexPath.row,zipPath: zipPath)
            
        })
        
        let deleteAction = UITableViewRowAction(style: .default, title: uxxx033, handler: { (action , indexPath) -> Void in
            if(tempModel?.name == nil){
                return
            }
            let path:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath + (tempModel?.name)!)
            if(FileManager.default.fileExists(atPath: path) == true){
                try! FileManager.default.removeItem(atPath: path)

            }
            self.audioDumpList?.items?.remove(at: indexPath.row)
            PVDDatabaseAccess.deleteAudioDumpByName(tempModel?.name)
            self.dumpTbl.reloadData()
            
        })
        
        // You can set its properties like normal button
        deleteAction.backgroundColor = UIColor.red
        uploadAction.backgroundColor = UIColor.green
        return [uploadAction,deleteAction]
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
        
    }
    
    
    //MARK : - private method
    func audioFileStreamReady(toProducePackets audioFileStream: MCAudioFileStream!) {

        
    }
    
    func audioFileStreamx(_ packets: UnsafeRawPointer, numberOfBytes: UInt32, numberOfPackets: UInt32, packetDescriptions packetDescriptioins: UnsafeMutablePointer<AudioStreamPacketDescription>) {

        PSRSoundRec.testAudioData(packets, numberOfBytes: numberOfBytes, numberOfPackets: numberOfPackets, packetDescriptions: packetDescriptioins)
        
    }
    

    

    
    @IBAction func audioFileToEngineAction(_ sender: UIButton) {
        let l008002 = String(format: NSLocalizedString("L008-002", comment: "Audio Fileが選ばれていません"))
        let l008003 = String(format: NSLocalizedString("L008-003", comment: ""))
        let l008004 = String(format: NSLocalizedString("L008-004", comment: ""))
        let l008016 = String(format: NSLocalizedString("L008-016", comment: ""))
        
        if(dumpTbl.indexPathForSelectedRow == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008002)
            })
            
            return
        }
        if(currentRuleSelected == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008016)
            })
            return
        }
        
        let ret = (PSRManager.shareInstance() as AnyObject).voicedoStartInspection(withOutRecordStart: currentRuleSelected)
        print(ret)
        let tempModel:PVDAudioDataModel? = audioDumpList?.items![(dumpTbl.indexPathForSelectedRow?.row)!]
        
        if(tempModel?.name == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008003)
            })
            
            return
        }
        let path:String = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath + (tempModel?.name)!)
        if(FileManager.default.fileExists(atPath: path) == false){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008004)
            })
        }
        let file:FileHandle = FileHandle(forReadingAtPath: path)!
        let attr:NSDictionary = try! FileManager.default.attributesOfItem(atPath: path) as NSDictionary
        var fileSize : UInt64 = 0
        
        fileSize = attr.fileSize();
        do {
            audioFilStream = try MCAudioFileStream(fileType: kAudioFileCAFType, fileSize: fileSize)
            audioFilStream.delegate = self
            
            let lengthPerRead = 10000;
            while(fileSize > 0){
                let data:Data = file.readData(ofLength: lengthPerRead)
                fileSize = fileSize - UInt64(data.count)
                try audioFilStream.parseData(data)
                
            }
            audioFilStream.close()
            file.closeFile()
        }
        catch let error as NSError {
            print(error)

            return
        }
    }
    
    func dismissAction(){
        self.dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func audioPlayAction(_ sender: UIButton) {
        let l008002 = String(format: NSLocalizedString("L008-002", comment: "Audio Fileが選ばれていません"))
        if(dumpTbl.indexPathForSelectedRow == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008002)
            })
            
            return
        }
        if(audioPlayer.isPlaying == false){
            DispatchQueue.main.async(execute: {
                self.playBtn.setBackgroundImage(UIImage(named:"icon_pause"), for: UIControlState())
            })
            audioPlayer.play()
        }else{
            DispatchQueue.main.async(execute: {
                self.playBtn.setBackgroundImage(UIImage(named:"icon_play2"), for: UIControlState())
            })
            audioPlayer.stop()
        }
        
    }
    
    
    
    @IBAction func audioStopAction(_ sender: AnyObject) {
        let l008002 = String(format: NSLocalizedString("L008-002", comment: "Audio Fileが選ばれていません"))
        if(dumpTbl.indexPathForSelectedRow == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008002)
            })
            
            return
        }
        if(audioPlayer.isPlaying == true){
            audioPlayer.stop()
        }
        
    }
    
    func audioPlayTimer(_ timer:Timer){
//        print("audioPlayerTimer")
        if(audioPlayer != nil){
//            print(audioPlayer.currentTime)
            leftTimeLbl.text = String(format: "%.02f", audioPlayer.currentTime)
            rightTimeLbl.text = String(format: "-%.02f", audioPlayer.duration -  audioPlayer.currentTime)
            audioSlider.value = Float(audioPlayer.currentTime / audioPlayer.duration)
            if(audioPlayer.isPlaying == false){
                DispatchQueue.main.async(execute: {
                    self.playBtn.setBackgroundImage(UIImage(named:"icon_play2"), for: UIControlState())
                })
            }
        }
    }
    
    //MARK: - Notification methods
    func stopInspectionCBAction(_ info:Notification){
        switch gStartInspectionFlag!  {
        case .kChangingUser:
            DispatchQueue.main.async(execute: { () -> Void in

                gStartInspectionFlag = .kDoNothing
            })
            break
        case .kDoNothing:
            
            break
            
        }
    }
    
    func audioDumpResultAction(_ noti:Notification){
        if(noti.userInfo == nil){
            return
        }
        let infodict:NSDictionary = noti.userInfo! as NSDictionary
        
        let result:String? = infodict.object(forKey: kResultKey) as? String
        if(result == nil){
            return
        }
        DispatchQueue.main.async { () -> Void in
            self.testTextView.text = self.testTextView.text + result! + "\n"
        }
    
    
    
    }
    
    
    //MARK: - private methods
    func showScoreLog(_ notification:Notification){
        let userInfo:NSDictionary = notification.userInfo! as NSDictionary
        let logString:NSString = PVDSwiftUtils.getSafeStringFromAnyObject(userInfo.object(forKey: kLogViewKey) as AnyObject) as NSString
        let option:NSString = PVDSwiftUtils.getSafeStringFromAnyObject(userInfo.object(forKey: kOptionKey) as AnyObject) as NSString
        if(option != "2"){
            return
        }
        DispatchQueue.main.async { () -> Void in
            self.testTextView.text = self.testTextView.text + (logString as String) + "\n"
        }
    }

    @IBAction func openPlayAudioAction(_ sender: UIButton) {
//        self.heightOfAudioPlayView.constant = heightOftopViewInView
//        self.heightOfInspection.constant = 30
//        self.updateViewConstraints()
        

    }
    
    @IBAction func openAudioInspectionAction(_ sender: UIButton) {
//        self.heightOfAudioPlayView.constant = 30
//        self.heightOfInspection.constant = heightOftopViewInView
//        self.updateViewConstraints()
    }
    

    @IBAction func clearTestViewAction(_ sender: UIButton) {
        DispatchQueue.main.async { () -> Void in
            self.testTextView.text = "認識内容:"
        }
        
    }
    
    
    func dumpuploadAction(_ dumpfilepath:String,index:Int,zipPath:String){
      
        let uxxx029 = String(format: NSLocalizedString("UXXX-029", comment: "異常なレスボンス"))
        let uxxx014 = String(format: NSLocalizedString("UXXX-014", comment: "レスボンスエラー"))
        let l008006 = String(format: NSLocalizedString("L008-006", comment: "upload中"))
        let l008007 = String(format: NSLocalizedString("L008-007", comment: "upload成功"))
        let l008008 = String(format: NSLocalizedString("L008-008", comment: "upload失敗"))
        
        let uploadUrl = "http://133.208.22.158/app_upload/upload.php"
        SVProgressHUD.show(withStatus: l008006)
        
        
        if(FileManager.default.fileExists(atPath: dumpfilepath) == false){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l008008)
            })
            
            return
        }
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>ダンプアップロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL=" + uploadUrl)
        
        let zipFlag:Bool = ZipArchiveManager.createZipFile(atPath: zipPath, withFilesAtPaths: [dumpfilepath])
        print(zipFlag)
        let fileURL = URL(fileURLWithPath: (zipPath))
        print(fileURL)
        
        alamofireManager.upload(multipartFormData: { multipartFormData in
//            multipartFormData.appendBodyPart(fileURL: fileURL, name: "upfile")
            multipartFormData.append(fileURL, withName: "upfile")
            }, to: uploadUrl) { encodingResult in
                
                
                switch encodingResult {
                case .success(let upload, _, _):
                    
                    upload.responseJSON { response in
                        PVDSwiftUtils.writeAccessLog("<<ダンプアップロード>>:リクエスト成功")
                        debugPrint(response)
                        if(response.result.value != nil){
                            let retDic = response.result.value as? Dictionary<String, AnyObject>


//                            print(retDic?["result"])
                            let retValue = retDic?["result"] as? String
//                            print(retValue?.classForCoder)
                            if(retValue == "0"){
                                DispatchQueue.main.async {
                                    PVDSwiftUtils.writeAccessLog("<<ダンプアップロード>>:" + l008007)
                                    
                                    SVProgressHUD.showSuccess(withStatus: l008007)
                                    let tmpAudioModel:PVDAudioDataModel =  (self.audioDumpList?.items![index])!
                                    tmpAudioModel.uploadedflag = true
                                    PVDSwiftUtils.saveSettingFile()
                                    self.dumpTbl.reloadData()
                                }
                            }else{
                                PVDSwiftUtils.writeAccessLog("<<ダンプアップロード>>:" + l008008)

                                DispatchQueue.main.async {
                                    SVProgressHUD.showError(withStatus: l008008)
                                }
                            }
                        }else{
                            PVDSwiftUtils.writeAccessLog("<<ダンプアップロード>>:" + uxxx014)
                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: uxxx014)
                            }
                        }
                        
                    }
                case .failure(let encodingError):
                    PVDSwiftUtils.writeAccessLog("<<ダンプアップロード>>:リクエスト失敗,error code:" + String(encodingError._code) + "\n" + uxxx029  + "\n")
                    print(encodingError)
                    DispatchQueue.main.async {
                        SVProgressHUD.showError(withStatus: uxxx029)
                    }
                }
                try! FileManager.default.removeItem(atPath: zipPath)
        }
            NSLog((UIDevice.current.identifierForVendor?.uuidString)!)
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
