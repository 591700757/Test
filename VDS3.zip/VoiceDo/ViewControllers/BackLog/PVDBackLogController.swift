//
//  BackLogController.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/04/14.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import SVProgressHUD
class PVDBackLogController: UIViewController {

    @IBOutlet weak var closeBtn: UIButton!
    @IBOutlet weak var backlogTextView: UITextView!
    
    //life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let l010001 = String(format: NSLocalizedString("L010-001", comment: "file not found"))
        let l009004 = String(format: NSLocalizedString("L010-004", comment: "encode failed"))
        let logfilePath = kbackupFolder + "/" + gsettingModel.statusLogFileName!
        if(FileManager.default.fileExists(atPath: logfilePath) == false){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l010001)
            })
            return
        }
        var logFileStr:String?
        
        do{
            logFileStr = try String(contentsOfFile: logfilePath,encoding: String.Encoding.utf8)
        }catch let error as NSError{
            print(error)
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l009004)
            })
        }
        backlogTextView.text = logFileStr
        
        
       
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        DispatchQueue.main.async(execute: { () -> Void in
            
            if(self.backlogTextView.text.characters.count > 0 ) {
                let range = NSMakeRange(self.backlogTextView.text.characters.count - 1, 1);
                self.backlogTextView.scrollRangeToVisible(range)
            }
        })
        
        
    }
    
    
    //private method
    @IBAction func closeAction(_ sender: UIButton) {
        
        self.dismiss(animated: true) { () -> Void in
          NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoInSpectionRestartToRootNotification), object: nil, userInfo: nil)
        }
        
    }
    
    
    
    @IBAction func clearBackLogAction(_ sender: UIButton) {
        let uxxx010 = String(format: NSLocalizedString("UXXX-010", comment: "message title"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let l010002 = String(format: NSLocalizedString("L010-002", comment: "ovriwrite warning"))
        
        let alert = UIAlertController(title: uxxx010, message: l010002, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            
        }))
        alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            let logfilePath = kbackupFolder + "/" + gsettingModel.statusLogFileName!
            try! FileManager.default.removeItem(atPath: logfilePath)
            DispatchQueue.main.async(execute: { () -> Void in
                self.dismiss(animated: true) { () -> Void in
                    NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoInSpectionRestartToRootNotification), object: nil, userInfo: nil)
                }
            })
        }))
        
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })
        
        
    }
    
    
}
