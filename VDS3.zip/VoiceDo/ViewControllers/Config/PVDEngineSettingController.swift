//
//  PVDEngineSettingController.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/04/11.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import SVProgressHUD

class PVDEngineSettingController: UIViewController,UIGestureRecognizerDelegate {

    @IBOutlet var singleTapGuesture: UITapGestureRecognizer!
    @IBOutlet weak var contentTxtView: UITextView!
    //life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let l009001 = String(format: NSLocalizedString("L009-001", comment: "保存"))
        let l009002 = String(format: NSLocalizedString("L009-002", comment: "エンジン設定ファイル編集"))
        let l009003 = String(format: NSLocalizedString("L009-003", comment: "エンジンファイル見つかりません"))
        let l009004 = String(format: NSLocalizedString("L009-004", comment: "encode failed"))
        let enginePath   = PVDSwiftUtils.getEngineSettingFilePath()

        self.title = l009002
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: l009001, style: UIBarButtonItemStyle.plain, target: self, action: #selector(PVDEngineSettingController.trySaveEngineFile))

        if((enginePath == nil)||(FileManager.default.fileExists(atPath: enginePath!) == false)){
            self.catchErrorAndPopBack(l009003)
        }
        var engineFileStr:String?
        
        do{
            engineFileStr = try String(contentsOfFile: enginePath!,encoding: String.Encoding.shiftJIS)
        }catch let error as NSError{
            print(error)
            self.catchErrorAndPopBack(l009004)
        }
        contentTxtView.text = engineFileStr
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        singleTapGuesture.delegate = self
//        self.navigationController?.navigationBar.addGestureRecognizer(singleTapGuesture)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        DispatchQueue.main.async { () -> Void in
            SVProgressHUD.dismiss()
        }
//        self.navigationController?.navigationBar.removeGestureRecognizer(singleTapGuesture)
    }
    
    
    //private methods
//    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
//        touch.view!.classForCoder
//        
//        if ((touch.view!.isKindOfClass(UIButton))||(touch.view!.isKindOfClass(UIBarButtonItem))){
//            return false
//        }else {
//            return true
//        }
//        
//        
//    }
    @IBAction func singleTapGestureAction(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
    }
    
    func trySaveEngineFile(){
        if(contentTxtView.text == nil){
            return
        }
        let uxxx010 = String(format: NSLocalizedString("UXXX-010", comment: "message title"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let l009005 = String(format: NSLocalizedString("L009-005", comment: "ovriwrite warning"))
        let enginePath   = PVDSwiftUtils.getEngineSettingFilePath()
        if(enginePath == nil){
            PVDSwiftUtils.dispatch_async_main({ 
                SVProgressHUD.showError(withStatus: "trySaveEngineFile failed")
            })
            return 
        }
        let alert = UIAlertController(title: uxxx010, message: l009005, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            
        }))
        alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            DispatchQueue.main.async(execute: { () -> Void in
                let data:Data = self.contentTxtView.text.data(using: String.Encoding.shiftJIS)!
                try! FileManager.default.removeItem(atPath: enginePath!)
                FileManager.default.createFile(atPath: enginePath!, contents: data, attributes: nil)
                self.navigationController?.popViewController(animated: true)
            })
        }))
        
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })

    
    }
    
    
    func catchErrorAndPopBack(_ message:String){
        let uxxx010 = String(format: NSLocalizedString("UXXX-010", comment: "message title"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        
        let alert = UIAlertController(title: uxxx010, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            DispatchQueue.main.async(execute: { () -> Void in
                self.navigationController?.popViewController(animated: true)
            })
        }))
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })
    }
}
