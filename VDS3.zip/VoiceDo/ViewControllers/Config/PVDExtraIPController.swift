//
//  PVDExtraIPController.swift
//  VoiceDo
//
//  Created by user2 on 2015/11/26.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import SVProgressHUD
import Alamofire

class PVDExtraIPController: UITableViewController,UITextFieldDelegate {

    @IBOutlet weak var iptextfield: UITextField!
    @IBOutlet weak var portfield: UITextField!
    @IBOutlet weak var userNameField: UITextField!
    @IBOutlet weak var tokenField: UITextField!
    @IBOutlet weak var serverPath: UITextField!
    @IBOutlet weak var delleteAllBtn: UIButton!
    
    @IBOutlet weak var tokenVerifyBtn: UIButton!
    @IBOutlet var singleTapGesture: UITapGestureRecognizer!
    
    @IBOutlet weak var deviceidField: UITextField!
//    @IBOutlet weak var uploadBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.tableView.tableFooterView = UIView()
        self.tableView.separatorInset = UIEdgeInsets.zero
        self.tableView.layoutMargins = UIEdgeInsets.zero
        
        let l004001 = String(format: NSLocalizedString("L004-001", comment: "サーバー設定"))
        let uxxx005 = String(format: NSLocalizedString("UXXX-005", comment: "く戻る"))
        self.tableView.tableFooterView = UIView()
        
        self.title = l004001
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: uxxx005, style: UIBarButtonItemStyle.plain, target: self, action: #selector(PVDExtraIPController.dismissAction(_:)))
        self.view.addGestureRecognizer(singleTapGesture)
        self.iptextfield.text = gsettingModel.ipAddress
        self.portfield.text = gsettingModel.port
        self.userNameField.text = gsettingModel.userid
        self.tokenField.text = gsettingModel.tokenString
        self.serverPath.text = gsettingModel.serverPath
        self.iptextfield.delegate = self
        self.portfield.delegate = self
        self.userNameField.delegate = self
        self.tokenField.delegate = self
        self.deviceidField.text = gsettingModel.deviceid
        self.deviceidField.delegate = self
        self.serverPath.delegate = self
        
        
        self.tokenVerifyBtn.layer.cornerRadius = 5
        self.tokenVerifyBtn.clipsToBounds = true
        self.delleteAllBtn.layer.cornerRadius = 5
        self.delleteAllBtn.clipsToBounds = true
        
        gHomeJumpToServerSettingFlag = false
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async { () -> Void in
            SVProgressHUD.dismiss()
        }
    }

    //MARK: tableview  delegate datasource
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath){
        //        super.tableView(tableView, willDisplayCell: cell, forRowAtIndexPath: indexPath)
        if((indexPath.row == 1)||(indexPath.row == 2)||(indexPath.row == 3)||(indexPath.row == 4)||(indexPath.row == 5)||(indexPath.row == 6)||(indexPath.row == 7)){//sperator not to the left margin
            return
        }
        cell.layoutMargins = UIEdgeInsets.zero
    }

    
    
    //MARK: - tap methods
    @IBAction func singleTapGestureAction(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)

    }
    
    //MARK: - private methods
    
    @IBAction func deleteAllAction(_ sender: UIButton) {
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let l004005 = String(format: NSLocalizedString("L004-005", comment: "既存のデータ削除"))
        let l004006 = String(format: NSLocalizedString("L004-006", comment: "既存のレーポート、結果ファイルをすべて削除します。よろしいですか？"))
        let l004020 = String(format: NSLocalizedString("L004-020", comment: "既存のレーポート、結果ファイルをすべて削除します。よろしいですか？"))
        let alert = UIAlertController(title: l004005, message: l004006, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            
        }))
        alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            PVDSwiftUtils.removeOldfiles()

            
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showSuccess(withStatus: l004020)
            })
        }))
       
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })
        
        
        
    }
    
    func dismissAction(_ sender: UIButton) {
        PVDSwiftUtils.dispatch_async_main { () -> () in
            self.navigationController?.popViewController(animated: true)
//            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    
    @IBAction func tokenVarifyAction(_ sender: UIButton) {
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let l004002 = String(format: NSLocalizedString("L004-002", comment: "認証トークン検証中です"))
        let l004003 = String(format: NSLocalizedString("L004-003", comment: "認証トークンは一致しています"))
        let l004004 = String(format: NSLocalizedString("L004-004", comment: "認証トークン不正です"))
        let uxxx014 = String(format: NSLocalizedString("UXXX-014", comment: "レスボンスエラー"))
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            let alert = UIAlertController(title: uxxx020, message: uxxx021, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.tokenVarifyAction(sender)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return
        }
        ktokenCheckURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! +  "/" + self.serverPath.text!
        ktokenCheckURL = ktokenCheckURL + "/checkAuth.php?id=" + gsettingModel.userid!
        if(self.tokenField.text == ""){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx006)
            })
            
            return
        }
        let tokenString =   self.tokenField.text
        let tokenCheckURL = ktokenCheckURL + "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString)
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>トークンチェック>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL=" + tokenCheckURL)
        
        
        SVProgressHUD.show(withStatus: l004002)
        
    
        
        
        

        alamofireManager.request(tokenCheckURL).responseJSON { response in
            if(response.result.value != nil){
                dump(response.result.value)
                let retDic:NSDictionary = response.result.value as! NSDictionary
                let retValue = retDic.object(forKey: "result") as? NSNumber
                DispatchQueue.main.async {
                    
                    if(retValue == 0){
                        SVProgressHUD.showSuccess(withStatus: l004003)
                        PVDSwiftUtils.writeAccessLog("<<トークンチェック>>:" + l004003)
                    }else{
                        SVProgressHUD.showError(withStatus: l004004)
                        PVDSwiftUtils.writeAccessLog("<<トークンチェック>>:" + l004004)
                    }
                }

                
            }else{
                DispatchQueue.main.async {
                    SVProgressHUD.showError(withStatus: uxxx014)
                }
                
                PVDSwiftUtils.writeAccessLog("<<トークンチェック>>:" + uxxx014)
                
            }
//

        }

        
        
    }


    



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //MARK:text field methods
    func textField(_ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String)
        -> Bool
    {

        if(string == ""){
            return true
        }
        
        if(string == " "){
            return false
        }
        let currentText = textField.text ?? ""
        let prospectiveText = (currentText as NSString).replacingCharacters(in: range, with: string)
        textField.text? = (textField.text?.replacingOccurrences(of: " ", with: ""))!
        if(textField == self.deviceidField){
            
            return prospectiveText.isNumeric() &&
                prospectiveText.characters.count <= 6
            
        }else if(textField == self.portfield){
            if(prospectiveText.isNumeric() && (prospectiveText.range(of: ".") == nil)){
                return true
            }else{
                return false
            }
        }
        return true;
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text?.replacingOccurrences(of: " ", with: "")
        gsettingModel.ipAddress = self.iptextfield.text
        gsettingModel.port = self.portfield.text
        gsettingModel.userid = self.userNameField.text
        gsettingModel.tokenString = self.tokenField.text
        gsettingModel.deviceid = self.deviceidField.text
        gsettingModel.serverPath = self.serverPath.text
        PVDSwiftUtils.saveSettingFile()
        
        if((self.deviceidField.text != nil)&&(self.deviceidField.text != "")&&(gsettingModel.deviceid?.characters.count != 6)){
            SVProgressHUD.showInfo(withStatus: "デバイスIDが6桁じゃない")
            PVDSwiftUtils.dispatchAfterMain(3, afterBlock: { (Void) in
                SVProgressHUD.dismiss()
            })
        }
        
        //reportURL　レポートダウンロード
        kReportFileDownloadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/"
        kReportFileDownloadURL = kReportFileDownloadURL + gsettingModel.serverPath! + "/downloadFile.php?type=report&id=" + gsettingModel.userid!
        
        //speakerURL　話者ファイルダウンロード
        kSpearkFileDownloadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/"
        kSpearkFileDownloadURL = kSpearkFileDownloadURL + gsettingModel.serverPath! + "/downloadFile.php?type=speaker&id=" + gsettingModel.userid!
        
        //kresultUploadURL　結果アップロード
        kresultUploadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kresultUploadURL = kresultUploadURL  + "/uploadResult.php?id=" + gsettingModel.userid! + "&deviceid=" + gsettingModel.deviceid!
        
        
        //kupdateResultURL  結果アップデート
        kupdateResultURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kupdateResultURL = kupdateResultURL  + "/updateResult.php?id=" + gsettingModel.userid! + "&deviceid=" + gsettingModel.deviceid!
        
        
        //kinitFileDownloadURL 初期ファイルダウンロード
        //http://133.208.22.158/handsfree_dev/downloadIni.php?id=DEV004
        kinitFileDownloadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kinitFileDownloadURL = kinitFileDownloadURL + "/downloadIni.php?id=" + gsettingModel.userid!
        
        //作業引き継ぎアップロード
        kworksharefileUploadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kworksharefileUploadURL = kworksharefileUploadURL + "/uploadWork.php?id=" + gsettingModel.userid! + "&deviceid=" + gsettingModel.deviceid!
        
        //作業引き継ぎダウンロード
        kworksharefileDownURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! +   "/" + gsettingModel.serverPath!
        kworksharefileDownURL = kworksharefileDownURL + "/downloadWork.php?id=" + gsettingModel.userid!
        
        //トークン検証
        ktokenCheckURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! +  "/" + gsettingModel.serverPath!
        ktokenCheckURL = ktokenCheckURL + "/checkAuth.php?id=" + gsettingModel.userid!
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }

}
