//
//  PVDExtraSettingController.swift
//  VoiceDo
//
//  Created by user2 on 2015/11/25.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD
import AVFoundation
import ObjectMapper
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}


class PVDExtraSettingController: UITableViewController,UITextFieldDelegate,UIGestureRecognizerDelegate,UIPickerViewDelegate,UIPickerViewDataSource{
    @IBOutlet weak var caremaOffSwitch: UISwitch!
    @IBOutlet weak var inifileDownloadBtn: UIButton!
//    @IBOutlet weak var dumpSwitch: UISwitch!
    @IBOutlet weak var dumpSwitchBtn: UIButton!
    
    @IBOutlet weak var inputGainLbl: UILabel!
    @IBOutlet weak var showDetailLogSwitch: UISwitch!
    
    
    @IBOutlet weak var forcetoUseBuildInSpeakerSwitch: UISwitch!
    @IBOutlet weak var inputGainSlider: UISlider!
    @IBOutlet weak var passcodeBtn: UIButton!
    @IBOutlet weak var engineLogOutPutSwitch: UISwitch!
    
    
    @IBOutlet weak var oshienSwitch: UISwitch!
    
    @IBOutlet weak var oshienFld: UITextField!
    @IBOutlet weak var oshienStartNextSwitch: UISwitch!
    @IBOutlet var singleTapGesture: UITapGestureRecognizer!
    
    @IBOutlet weak var inputScrollToTopSwitch: UISwitch!
    @IBOutlet weak var sharedFinishedMaxField: UITextField!
    
    
    let kPickerActualHeight:CGFloat = 162
//    var popflag:Bool = false
    var inputGainChangedFlag:Bool = false
    var langPicker:UIPickerView?
    
    //MARK:life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()
        self.tableView.separatorInset = UIEdgeInsets.zero
        self.tableView.layoutMargins = UIEdgeInsets.zero
        self.tableView.delegate = self
        self.oshienFld.delegate = self
        self.sharedFinishedMaxField.delegate = self
        var oshienFldTMP:String! = ""
        if(gsettingModel.workSharingArray != nil){
            for str in gsettingModel.workSharingArray!{
                if let tmp = str as? String{
                    if(oshienFldTMP == ""){
                        oshienFldTMP = tmp
                    }else{
                        oshienFldTMP = oshienFldTMP + "," + tmp
                    }
                }
            }
        }
        
        singleTapGesture.delegate = self
        self.view.addGestureRecognizer(singleTapGesture)
        oshienFld.text = oshienFldTMP

        if(gsettingModel.workSharingFlag == false){
            self.oshienFld.isEnabled = false
            self.oshienSwitch.isOn = false
        }else{
            self.oshienFld.isEnabled = true
            self.oshienSwitch.isOn = true
        }
        if(gsettingModel.workSharingGoOn == false){
            self.oshienStartNextSwitch.isOn = false
        }else{
            self.oshienStartNextSwitch.isOn = true
        }
        if(gsettingModel.inputScrolToTopFlag == false){
            self.inputScrollToTopSwitch.isOn = false
        }else{
            self.inputScrollToTopSwitch.isOn = true
        }
        
        if(Int(gsettingModel.logLevel!)! > 0){
            self.showDetailLogSwitch.isOn = true
        }else{
            self.showDetailLogSwitch.isOn = false
        }
        
        if(gsettingModel.workSharingBackUpMax != nil){
            self.sharedFinishedMaxField.text = String(gsettingModel.workSharingBackUpMax!)
        }
        
        
        let uxxx011 = String(format: NSLocalizedString("UXXX-011", comment: "システム設定"))
        let uxxx005 = String(format: NSLocalizedString("UXXX-005", comment: "く戻る"))

        
        self.title = uxxx011
//        if(popflag == false){
            self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: uxxx005, style: UIBarButtonItemStyle.plain, target: self, action: #selector(PVDExtraSettingController.dismissAction(_:)))
//        }
        
        inifileDownloadBtn.layer.cornerRadius = 5
        inifileDownloadBtn.clipsToBounds = true
        // Do any additional setup after loading the view.
        
        if let saveRecordKey = UserDefaults.standard.object(forKey: kSaveRecordDumpKey) as? String{
            dumpSwitchBtn.setTitle(saveRecordKey, for: UIControlState())
        }else{
            dumpSwitchBtn.setTitle("オフ", for: UIControlState())
        }
        
        
        self.inputGainLbl.text = String(format:"%.02f",AVAudioSession.sharedInstance().inputGain)
        self.inputGainSlider.value = AVAudioSession.sharedInstance().inputGain
        if(gsettingModel.engineLogEnable == false){
            self.engineLogOutPutSwitch.isOn = false
        }else{
            self.engineLogOutPutSwitch.isOn = true
        }
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if(gHomeJumpToServerSettingFlag == true){
            let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
            
            self.navigationController?.pushViewController(tpStoryBoard.instantiateViewController(withIdentifier: "PVDExtraIPController"), animated: false)
            //            presentViewController(tpStoryBoard.instantiateViewControllerWithIdentifier("PVDExtraSettingController"), animated: true, completion: nil)
        }
        gHomeJumpToExtraSettigFlag = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let l003001 = String(format: NSLocalizedString("L003-001", comment: "パスコードロック設定"))
        let l003002 = String(format: NSLocalizedString("L003-002", comment: "パスコードロック解除"))
        
        langPicker = UIPickerView(frame: CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: kPickerActualHeight))
        langPicker!.backgroundColor = UIColor(red: 244.0/255.0, green: 244.0/255.0, blue: 244.0/255.0, alpha: 1.0)
        langPicker!.delegate = self
        langPicker!.dataSource = self
        UIApplication.shared.isIdleTimerDisabled = false
        //        self.view.addSubview(langPicker!)
        let window = UIApplication.shared.keyWindow
        
        window!.addSubview(langPicker!)
        window!.bringSubview(toFront: langPicker!)
        if(gsettingModel.cameraOff == "true"){
            caremaOffSwitch.isOn = true
        }else if(gsettingModel.cameraOff == "false"){
            caremaOffSwitch.isOn = false
        }else{
            NSLog("wrong key word set to gsettingModel")
        }
        if(gsettingModel.audioFourceToUseBuildInSpeakerFlag == true){
            self.forcetoUseBuildInSpeakerSwitch.isOn = true
        }else{
            self.forcetoUseBuildInSpeakerSwitch.isOn = false
        }
        let tmpPass:String? = UserDefaults.standard.object(forKey: kSystemSettingPasswordKey) as? String
        DispatchQueue.main.async { () -> Void in
            if(tmpPass == nil){
                self.passcodeBtn.setTitle(l003001, for: UIControlState())
            }else{
                self.passcodeBtn.setTitle(l003002, for: UIControlState())
            }
            SVProgressHUD.dismiss()
        }
        
        
    }
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        langPicker?.removeFromSuperview()
    }
    @IBAction func cameraSwitchValueChangedAction(_ sender: UISwitch) {
        if(self.caremaOffSwitch.isOn == true){
            gsettingModel.cameraOff = "true"
        }else{
            gsettingModel.cameraOff = "false"
        }
        PVDSwiftUtils.saveSettingFile()
    }
    @IBAction func forceUseBuildInSpeakerSwitchValueChangedAction(_ sender: UISwitch) {
        if(self.forcetoUseBuildInSpeakerSwitch.isOn == true){
            UserDefaults.standard.set("true", forKey: kForceToUseBuildInSpeeakKey)
            gsettingModel.audioFourceToUseBuildInSpeakerFlag = true
            
        }else{
            UserDefaults.standard.set("false", forKey: kForceToUseBuildInSpeeakKey)
            gsettingModel.audioFourceToUseBuildInSpeakerFlag = false
        }
        UserDefaults.standard.synchronize()
        PVDSwiftUtils.saveSettingFile()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func dismissAction(_ sender: UIButton) {
        
      self.navigationController?.popViewController(animated: true)
    }
    //MARK: tableview  delegate datasource
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath){
        
        if((indexPath.row == 1)||(indexPath.row == 8)||(indexPath.row == 9)||(indexPath.row == 14)||(indexPath.row == 15)){//sperator not to the left margin
            return
        }
        cell.layoutMargins = UIEdgeInsets.zero
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 18
    }

    
    //MARK:text field methods
    func textField(_ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String)
        -> Bool
    {
        if((textField == oshienFld)&&((string == "")||(string == ",")||(string.isNumeric() == true)&&(string != ".")&&(string != "-"))){
            return true
        }else if((textField == sharedFinishedMaxField)&&((string == "")||(string.isNumeric() == true)&&(string != ".")&&(string != "-"))){
            return true
        }else{
            return false
        }
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if(textField == oshienFld){
            if(textField.text == ""){
                gsettingModel.workSharingArray = nil
            }else{
                // 2017.3.3 k.nagadomi iOS10 not working fix start
                // gsettingModel.workSharingArray = NSMutableArray(array: (textField.text?.componentsSeparatedByString(","))!)
                let txtField:String = textField.text!
                gsettingModel.workSharingArray = NSArray(array: txtField.components(separatedBy: ","))
                
                // 2017.3.3 k.nagadomi iOS10 not working fix end
            }
        }else if(textField == sharedFinishedMaxField){
            if(textField.text == ""){
                gsettingModel.workSharingBackUpMax = 5
            }else{
                let sharedvalue = Int(self.sharedFinishedMaxField.text!)
                if(sharedvalue > 1000){
                
                }else if(sharedvalue <= 0){
                
                }else{
                    gsettingModel.workSharingBackUpMax = Int(self.sharedFinishedMaxField.text!)
                }
                if(gsettingModel.workSharingBackUpMax != nil){
                    sharedFinishedMaxField.text = String(gsettingModel.workSharingBackUpMax!)
                }
                
            }
            
        }

        
        PVDSwiftUtils.saveSettingFile()
        
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
    //MARK:  xib methods
    
    @IBAction func removeLogAndRawAction(_ sender: UIButton) {
        
        
        let localString1 = String(format: NSLocalizedString("UXXX-001", comment: ""))
        let localString2 = String(format: NSLocalizedString("L003-010", comment: ""))
        let localString3 = String(format: NSLocalizedString("UXXX-002", comment: ""))
        let localString4 = String(format: NSLocalizedString("UXXX-003", comment: ""))
        let localString5 = String(format: NSLocalizedString("L003-011", comment: ""))
        if(FileManager.default.fileExists(atPath: kreportZipfilePath) == true){
            try! FileManager.default.removeItem(atPath: kreportZipfilePath)
        }
        
        let alert = UIAlertController(title: localString1, message: localString2, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: localString3, style: UIAlertActionStyle.cancel, handler:nil))
        alert.addAction(UIAlertAction(title: localString4, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            PSRManager.removeEngineLogAndRawFile()
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showSuccess(withStatus: localString5)
            })
        }))
        
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })
        
    }
    @IBAction func engineLogOutputSwitchValueChanged(_ sender: UISwitch) {
        if(sender.isOn == true){
            gsettingModel.engineLogEnable = true
            PSRManager.setEngineLogAndRaw(true)
        }else{
            gsettingModel.engineLogEnable = false
            PSRManager.setEngineLogAndRaw(false)
        }
        PVDSwiftUtils.saveSettingFile()
        
    }
    @IBAction func detailLogSwitchValueChanged(_ sender: UISwitch) {
        if(sender.isOn == true){
            gsettingModel.logLevel = "1"
        }else{
            gsettingModel.logLevel = "0"
        }
        PVDSwiftUtils.saveSettingFile()
    }
    
    
    @IBAction func passCodeAction(_ sender: UIButton) {
        let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
        let tmpPass:String? = UserDefaults.standard.object(forKey: kSystemSettingPasswordKey) as? String
        if(tmpPass == nil){//パスワード未設定状態で→パスワード設定
            
            UserDefaults.standard.set(PVDPassInputCtrlMode.kSetPass.rawValue, forKey: kPassInputCtrlKey)
            self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDPassInputController"), animated: true, completion: nil)
        }else{//パスワード設定状態で→パスワード解除
            UserDefaults.standard.set(PVDPassInputCtrlMode.kUnlockPass.rawValue, forKey: kPassInputCtrlKey)
            self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDPassInputController"), animated: true, completion: nil)
        }
        
        
    }
    
    
    
    
    @IBAction func InputCellScrollToTopSwitchValueChanged(_ sender: UISwitch) {
        if(sender.isOn == true){
            gsettingModel.inputScrolToTopFlag = true
        }else{
            gsettingModel.inputScrolToTopFlag = false
        }
        PVDSwiftUtils.saveSettingFile()
    }
    @IBAction func startNextSwitchValueChange(_ sender: UISwitch) {
        if(sender.isOn == true){
            gsettingModel.workSharingGoOn = true
        }else{
            gsettingModel.workSharingGoOn = false
        }
        PVDSwiftUtils.saveSettingFile()
    }
    @IBAction func oshienSwitchValueChange(_ sender: UISwitch) {
        if(sender.isOn == true){
            gsettingModel.workSharingFlag = true
            oshienFld.isEnabled = true
        }else{
            gsettingModel.workSharingFlag = false
            oshienFld.isEnabled = false
        }
        PVDSwiftUtils.saveSettingFile()
        
    }
    @IBAction func singleTapGestureAction(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
        
    }
    
    
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        self.view.endEditing(true)
        DispatchQueue.main.async { () -> Void in
            self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: self.kPickerActualHeight)
        }
        if (touch.view!.isKind(of: UIButton.self)){
            return false
        }else if(touch.view!.isDescendant(of: self.tableView) == true) {
            let cell:UITableViewCell? = PVDSwiftUtils.parentCellFor(touch.view!)
            if(cell == nil){
                return false
            }
            if(cell!.selectionStyle == .none){
                return true
            }
            return false
        } else {
            return true
        }
        
        
    }
    


    
    @IBAction func InputGainValueChanged(_ sender: UISlider) {
        let l003003 = String(format: NSLocalizedString("L003-003", comment: "input gain 設置不能"))
        
        if(AVAudioSession.sharedInstance().isInputGainSettable == false){
            NSLog(l003003);
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD .showInfo(withStatus: l003003)
            })
            
            
        }
        do{
            try AVAudioSession.sharedInstance().setInputGain(sender.value)
        }catch{
            print(error)
            NSLog("AVAudioSession input gain設置失敗")
        }
        
        
        self.inputGainLbl.text = String(format: "%.02f", sender.value)
        
    }
    
    @IBAction func deleteDumpAction(_ sender: AnyObject) {
        let l003004 = String(format: NSLocalizedString("L003-004", comment: "音声dumpファイルの削除"))
        let l003005 = String(format: NSLocalizedString("L003-005", comment: "音声dumpファイルを削除してよろしいですか"))
        let l003006 = String(format: NSLocalizedString("L003-006", comment: "dumpファイルを削除しました"))
        let l003007 = String(format: NSLocalizedString("L003-007", comment: "dumpファイルが見つかりません"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))

        let alert = UIAlertController(title: l003004, message: l003005, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: nil))
        alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            PVDDatabaseAccess.deleteAllRecordFromAudioDump()
            let dumpPath = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath)
            if(FileManager.default.fileExists(atPath: dumpPath) == true){
                try! FileManager.default.removeItem(atPath: dumpPath)
                PVDSwiftUtils.showAlertAfterDismiss("", alertString: l003006, dismissTime: 1)
            }else{
                PVDSwiftUtils.showAlertAfterDismiss("", alertString: l003007, dismissTime: 1)
            }
        }))
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })
    }
    
    /**
     ダンプの種類を選ぶピーカービューを出す
     
     - parameter sender: <#sender description#>
     */
    @IBAction func changeDumpSetting(_ sender: UIButton) {
        DispatchQueue.main.async { () -> Void in
            if(self.langPicker?.frame.origin.y > (kScreenHeight - self.kPickerActualHeight) ){
                self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight - self.kPickerActualHeight, width: kScreenWidth, height: self.kPickerActualHeight)
            }else{
                self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight,width: kScreenWidth, height: self.kPickerActualHeight)
            }
        }
    }
    
    
    
    
    
    

    
    
    
    @IBAction func inifileDownloadAction(_ sender: UIButton) {
        let l003006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let l003008 = String(format: NSLocalizedString("L003-008", comment: "初期データをダウンロードしています"))
        let uxxx007 = String(format: NSLocalizedString("UXXX-007", comment: "ダウンロードに失敗しました"))
        let uxxx027 = String(format: NSLocalizedString("UXXX-027", comment: "解凍中"))
        let uxxx028 = String(format: NSLocalizedString("UXXX-028", comment: "解凍成功"))
        let uxxx009 = String(format: NSLocalizedString("UXXX-009", comment: "解凍失敗"))
        let uxxx012 = String(format: NSLocalizedString("UXXX-012", comment: "解凍"))
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            let alert = UIAlertController(title: uxxx020, message: uxxx021, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.inifileDownloadAction(sender)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return
        }

        
        if((gsettingModel.tokenString == nil)||(gsettingModel.tokenString == "")){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD .showInfo(withStatus: l003006)
            })
            return
        }
        print(kinitFileDownloadURL)
        if(FileManager.default.fileExists(atPath: kinitfileZipfilePath) == true){
            try! FileManager.default.removeItem(atPath: kinitfileZipfilePath)
        }
        
        DispatchQueue.main.async {
            SVProgressHUD.showProgress(0, status: l003008)
            SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.none)
        }
        let tokenString =  gsettingModel.tokenString!
        let iniUrl = kinitFileDownloadURL + "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString)
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>初期ファイルダウンロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + iniUrl)
        

        
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .libraryDirectory, in: .userDomainMask)
        alamofireManager.download(iniUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, to: destination)
            .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
                
                if(progress.fractionCompleted == 1){
                    gsettingModel.lastupdate = PVDSwiftUtils.getoutputTimeStamp(Date())
                    PVDSwiftUtils.saveSettingFile()
                }
                
                
                DispatchQueue.main.async {
                    SVProgressHUD.showProgress(Float(progress.fractionCompleted), status: String(format: l003008 + "(%d%%)", Int(progress.fractionCompleted*100)))
                    
                }
            }
            .validate { request, response, temporaryURL, destinationURL in
                // Custom evaluation closure now includes file URLs (allows you to parse out error messages if necessary)
                return .success
            }
            
            .responseData{ response in
                
                debugPrint(response)
                if let error = response.error {
                    PVDSwiftUtils.writeAccessLog("<<トークンチェック>>、response error:\(error)\n" +  uxxx007)
                    print("Failed with error: \(error)")
                    DispatchQueue.main.async {
                        SVProgressHUD.showError( withStatus: uxxx007)
                    }
                    
                } else {
                    print("Downloaded file successfully")
                    DispatchQueue.main.async {
                        SVProgressHUD.showError( withStatus: uxxx027)
                        
                    }
                    let result:Bool =  ZipArchiveManager.unzipfilewithPassword((NSHomeDirectory() as NSString).appendingPathComponent(kDownloadInitFileName), destinationPath: kLibDomainPath, password: kIniFilePassword)
                    if(result == true){
                        self.readdownloadDictory()
                        PVDSwiftUtils.writeAccessLog("<<トークンチェック>>、download successfully\n" +  uxxx028)
                        DispatchQueue.main.async {
                            SVProgressHUD.showSuccess(withStatus: uxxx028)
                        }
                    }else{
                        
                        PVDSwiftUtils.showAlertAfterDismiss(uxxx012, alertString: uxxx009, dismissTime: 1)
                    }
                }
                
        }
        
       
    }
    
    
    
    
    
/**
     ダウロードしたファイルを展開する
*/
func readdownloadDictory(){
        let fm = FileManager.default
        let uxxx013 = String(format: NSLocalizedString("UXXX-013", comment: "ファイル適用失敗しました"))
 
        DispatchQueue.main.async(execute: { () -> Void in
            if(FileManager.default.fileExists(atPath: kinitFolderPath) == true){
                let dirEnum:FileManager.DirectoryEnumerator = fm.enumerator(atPath: kinitFolderPath)!
                var tmppath:String? = dirEnum.nextObject() as? String
                while( tmppath != nil){
                    if(tmppath![0] == "."){
                        tmppath = dirEnum.nextObject() as? String
                        continue
                    }
                    
                    let fromPath:String = kinitFolderPath + "/" + tmppath!
                    let toPath:String = kLibDomainPath + "/" + tmppath!

                    if(FileManager.default.fileExists(atPath: toPath) == true){
                        //元のファイルを削除して、新しいファイルを適用
                        try! FileManager.default.removeItem(atPath: toPath)
                    }
                    
                    
                    do{
                        try FileManager.default.copyItem(atPath: fromPath, toPath: toPath)
                    }catch{
                        print(error)
                        let tmpAlert = UIAlertView(title: uxxx013, message: nil, delegate: nil
                            , cancelButtonTitle: nil)
                        tmpAlert.show()
                        PVDSwiftUtils.dispatchAfterMain(1, afterBlock: { (Void) -> Void in
                            tmpAlert.dismiss(withClickedButtonIndex: 0, animated: true)
                        })
                        break
                    }
                    tmppath = dirEnum.nextObject() as? String
                    
                }
                
                if(FileManager.default.fileExists(atPath: kinitfileZipfilePath) == true){
                    //適用後にzipファイルを削除する
                    try! FileManager.default.removeItem(atPath: kinitfileZipfilePath)
                    
                }
                if(FileManager.default.fileExists(atPath: kinitFolderPath) == true){
                    try! FileManager.default.removeItem(atPath: kinitFolderPath)
                }
                
                
            }else{
                NSLog("downloadpath not found:%@",kinitFolderPath)
            }
            let engineBKfilepath = PVDSwiftUtils.getEngineSettingBKFilePath()
            let enginefilepath = PVDSwiftUtils.getEngineSettingFilePath()
            let engineDatapath = PVDSwiftUtils.getEngineDataFilePath()
            let engineDicpath = PVDSwiftUtils.getEngineDicFilePath()
            let defaultUserpath = PVDSwiftUtils.getDefaultUserPathInShareContainerDomainPath()
            
            let synthFolderpath = PVDSwiftUtils.getSynthPathInShareContainerDomainPath()
            let ttgenginepath = PVDSwiftUtils.getTTSEnginePathInShareContainerDomainPath()
            //sr.iniバックアップファイルを取る 初期ファイルを共通部分に移す
            if(FileManager.default.fileExists(atPath: engineBKfilepath!) == true){
                try! FileManager.default.removeItem(atPath: engineBKfilepath!)
            }
            if(FileManager.default.fileExists(atPath: enginefilepath!) == true){
                try! FileManager.default.removeItem(atPath: enginefilepath!)
            }
            if(FileManager.default.fileExists(atPath: kpathOfdownloadEngineSR) == true){
                try! FileManager.default.copyItem(atPath: kpathOfdownloadEngineSR, toPath: enginefilepath!)
                try! FileManager.default.copyItem(atPath: kpathOfdownloadEngineSR, toPath: engineBKfilepath!)
                try! FileManager.default.removeItem(atPath: kpathOfdownloadEngineSR)
                
            }
            if(FileManager.default.fileExists(atPath: engineDatapath!) == true){
                try! FileManager.default.removeItem(atPath: engineDatapath!)
            }
            if(FileManager.default.fileExists(atPath: kpathOfdownloadEngineData) == true){
                try! FileManager.default.copyItem(atPath: kpathOfdownloadEngineData, toPath: engineDatapath!)
                try! FileManager.default.removeItem(atPath: kpathOfdownloadEngineData)
            }
            if(FileManager.default.fileExists(atPath: engineDicpath!) == true){
                try! FileManager.default.removeItem(atPath: engineDicpath!)
            }
            if(FileManager.default.fileExists(atPath: kpathOfdownloadEngineDic) == true){
                try! FileManager.default.copyItem(atPath: kpathOfdownloadEngineDic, toPath: engineDicpath!)
                try! FileManager.default.removeItem(atPath: kpathOfdownloadEngineDic)
            }
            
            if(FileManager.default.fileExists(atPath: defaultUserpath!) == true){
                try! FileManager.default.removeItem(atPath: defaultUserpath!)
            }
            if(FileManager.default.fileExists(atPath: khomejsonFolder) == true){
                try! FileManager.default.copyItem(atPath: khomejsonFolder, toPath: defaultUserpath!)

            }
            if(FileManager.default.fileExists(atPath: synthFolderpath!) == true){
                try! FileManager.default.removeItem(atPath: synthFolderpath!)
            }
            if(FileManager.default.fileExists(atPath: ksynthfolderPath) == true){
                try! FileManager.default.copyItem(atPath: ksynthfolderPath, toPath: synthFolderpath!)
                try! FileManager.default.removeItem(atPath: ksynthfolderPath)
            }
            
            
            
            if(FileManager.default.fileExists(atPath: ttgenginepath!) == true){
                try! FileManager.default.removeItem(atPath: ttgenginepath!)
            }
            if(FileManager.default.fileExists(atPath: kttsenginePath) == true){
                try! FileManager.default.copyItem(atPath: kttsenginePath, toPath: ttgenginepath!)
                try! FileManager.default.removeItem(atPath: kttsenginePath)
            }
            
            
            
            //コマンドjsonをチェック:
            PVDSwiftUtils.checkCommandListBind()
           
           
        })
        
 
    }

    
    //MARK: pickerview delegate,datasource
    /**
     * ピッカーに表示する列数を返す
     */
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    /**
     * ピッカーに表示する行数を返す
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat{
        return 30
    }
    
    
    
    /**
     * 行のサイズを変更
     */
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat{
        return kScreenWidth
    }
    
    
    /**
     * ピッカーに表示する値を返す
     */
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(row == 0){
            return kDumpChoiceNoDump
        }else if(row == 1){
            return kDumpChoiceChoosedDump
        }else{
            return kDumpChoiceAllDump
        }
        
    }
    
    
    /**
     * ピッカーの選択行が決まったとき
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        if(row == 0){
            UserDefaults.standard.set(kDumpChoiceNoDump, forKey: kSaveRecordDumpKey)
            self.dumpSwitchBtn.setTitle(kDumpChoiceNoDump, for: UIControlState())
            
        }else if(row == 1){
            UserDefaults.standard.set(kDumpChoiceChoosedDump, forKey: kSaveRecordDumpKey)
            self.dumpSwitchBtn.setTitle(kDumpChoiceChoosedDump, for: UIControlState())
        }else{
            UserDefaults.standard.set(kDumpChoiceAllDump, forKey: kSaveRecordDumpKey)
            self.dumpSwitchBtn.setTitle(kDumpChoiceAllDump, for: UIControlState())
        }
        UserDefaults.standard.synchronize()
        DispatchQueue.main.async { () -> Void in
            self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight,width: kScreenWidth, height: self.kPickerActualHeight)
            
        }
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
