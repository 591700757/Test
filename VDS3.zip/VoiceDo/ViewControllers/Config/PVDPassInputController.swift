//
//  PVDPassInputController.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/02/03.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import SVProgressHUD

class PVDPassInputController: UIViewController ,UITextFieldDelegate{
    var hiddenFld:UITextField!
    var ctrlMode:String?
    var passLblArray:NSMutableArray!
    var tmpPassword:String? = ""
    var comfirPassword:String? = ""
    @IBOutlet weak var passLbl1: UILabel!
    @IBOutlet weak var passLbl2: UILabel!
    @IBOutlet weak var passLbl3: UILabel!
    @IBOutlet weak var passLbl4: UILabel!
    
    @IBOutlet weak var infoLbl: UILabel!
    @IBOutlet weak var passErrorAlertLbl: UILabel!
    
    
// MARK: - life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        passLblArray = NSMutableArray()
        passLblArray.add(passLbl1)
        passLblArray.add(passLbl2)
        passLblArray.add(passLbl3)
        passLblArray.add(passLbl4)
        ctrlMode = UserDefaults.standard.object(forKey: kPassInputCtrlKey) as? String
        hiddenFld = UITextField()
        hiddenFld.delegate = self
        
        hiddenFld.keyboardType = .numberPad
        self.view.addSubview(hiddenFld)
        reloadMode()
        
        let uxxx016 = String(format: NSLocalizedString("UXXX-016", comment: "キャンセル"))
        let btn:UIBarButtonItem = UIBarButtonItem(title: uxxx016, style: .done, target: self, action: #selector(PVDPassInputController.dismissAction))
        self.navigationItem.rightBarButtonItem = btn
        passErrorAlertLbl.layer.cornerRadius = 5
        passErrorAlertLbl.clipsToBounds = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.async { () -> Void in
            self.hiddenFld.becomeFirstResponder()
        }
        
    }
    
// MARK: - private method
    func dismissAction(){
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func reloadMode(){
        let uxxx017 = String(format: NSLocalizedString("UXXX-017", comment: "未設定"))
        let l004008 = String(format: NSLocalizedString("L004-008", comment: "パスワード確認"))
        let l004009 = String(format: NSLocalizedString("L004-009", comment: "パスワード設定"))
        let l004010 = String(format: NSLocalizedString("L004-010", comment: "パスワード変更"))
        let l004011 = String(format: NSLocalizedString("L004-011", comment: "パスワード変更確認"))
        let l004012 = String(format: NSLocalizedString("L004-012", comment: "パスワード解除"))
        let l004013 = String(format: NSLocalizedString("L004-013", comment: "システム設定パスワード入力"))
        let l004014 = String(format: NSLocalizedString("L004-014", comment: "システム設定パスワード再入力"))
        
        

        passErrorAlertLbl.isHidden = true
        if(ctrlMode == PVDPassInputCtrlMode.kSetPass.rawValue){
            self.title = l004009
            self.infoLbl.text = l004013
        }else if(ctrlMode == PVDPassInputCtrlMode.kSetPassConfirm.rawValue){
            self.title = l004008
            self.infoLbl.text = l004014
        }
        else if(ctrlMode == PVDPassInputCtrlMode.kModify.rawValue){
            self.title = l004010
            self.infoLbl.text = l004013
        }
        else if(ctrlMode == PVDPassInputCtrlMode.kModifyConfirm.rawValue){
            self.title = l004011
            self.infoLbl.text = l004014
        }else if(ctrlMode == PVDPassInputCtrlMode.kGotoSys.rawValue){
            self.title = l004013
        }else if(ctrlMode == PVDPassInputCtrlMode.kUnlockPass.rawValue){
            self.title = l004012
            self.infoLbl.text = l004013
        }
        else{
            self.title = uxxx017
        }
        
        DispatchQueue.main.async(execute: { () -> Void in
            self.hiddenFld.text = ""

            for i in 0 ..< 4 {
                weak var tmpLbl = self.passLblArray.object(at: i) as? UILabel
                tmpLbl?.text = "－";
                
            }
        })
        
    }
    
    func finishPassProcessing(_ pass:String){
        let l004015 = String(format: NSLocalizedString("L004-015", comment: "パスワードが一致しません、最初から入力してください"))
        let l004016 = String(format: NSLocalizedString("L004-016", comment: "パスワード設定成功"))
        let l004017 = String(format: NSLocalizedString("L004-017", comment: "パスワード入力失敗"))
        let l004018 = String(format: NSLocalizedString("L004-018", comment: "パスワード解除成功"))
        let l004019 = String(format: NSLocalizedString("L004-019", comment: "未設定"))
        

        let tmpPass:String? = UserDefaults.standard.object(forKey: kSystemSettingPasswordKey) as? String
        if((ctrlMode == PVDPassInputCtrlMode.kSetPass.rawValue)||(ctrlMode == PVDPassInputCtrlMode.kModify.rawValue)){//パスワード確認へ
            tmpPassword = pass
            ctrlMode = PVDPassInputCtrlMode.kSetPassConfirm.rawValue
            self.reloadMode()
        }else if((ctrlMode == PVDPassInputCtrlMode.kSetPassConfirm.rawValue)||(ctrlMode == PVDPassInputCtrlMode.kModifyConfirm.rawValue)){//パスワード比較して確認
            DispatchQueue.main.async(execute: { () -> Void in
                
                if(self.tmpPassword == pass){
                    SVProgressHUD.showSuccess(withStatus: l004016)
                    UserDefaults.standard.set(pass, forKey: kSystemSettingPasswordKey)
                    self.dismissAction()
                }else{
                    self.passErrorAlertLbl.text = l004015
                    self.ctrlMode = PVDPassInputCtrlMode.kSetPass.rawValue
                    self.reloadMode()
                    self.passErrorAlertLbl.isHidden = false
                }
            })
        }
        else if(ctrlMode == PVDPassInputCtrlMode.kGotoSys.rawValue){//パスワードが正しい、システム設定へ
            
            if(tmpPass == pass){
                
                DispatchQueue.main.async(execute: { () -> Void in
                    self.dismiss(animated: true, completion: { () -> Void in
                        
                        NotificationCenter.default.post(name: Notification.Name(rawValue: kShowSystemSettingActionNotification), object: nil)
                    })
                })
                
                
            }else{
                self.passErrorAlertLbl.text = l004017
                self.reloadMode()
                self.passErrorAlertLbl.isHidden = false
            }
            
        }else if(ctrlMode == PVDPassInputCtrlMode.kUnlockPass.rawValue){
            if(tmpPass == pass){
                UserDefaults.standard.removeObject(forKey: kSystemSettingPasswordKey)
                DispatchQueue.main.async(execute: { () -> Void in
                    self.dismiss(animated: true, completion: { () -> Void in
                        SVProgressHUD.showSuccess(withStatus: l004018)
                    })
                })
            }else{
                self.passErrorAlertLbl.text = l004017
                self.reloadMode()
                self.passErrorAlertLbl.isHidden = false
            }
        }
        else{
            self.title = l004019
        }
       
    }
    
//MARK:text field methods
    /**
    パスワード入力チェック
    
    - parameter textField: <#textField description#>
    - parameter range:     <#range description#>
    - parameter string:    <#string description#>
    
    - returns: <#return value description#>
    */
    func textField(_ textField: UITextField,
        shouldChangeCharactersIn range: NSRange,
        replacementString string: String)
        -> Bool
    {
        if((string == "")||(string.isNumeric() == true)){
            var tmpWordCnt = textField.text!.characters.count
            if(string == ""){
                tmpWordCnt = tmpWordCnt - 1
            }else{
                tmpWordCnt = tmpWordCnt + 1
            }
            
            if(tmpWordCnt <= 4){
                DispatchQueue.main.async(execute: { () -> Void in
                    for  i in 0 ..< 4 {
                        weak var tmpLbl = self.passLblArray.object(at: i) as? UILabel
                        tmpLbl?.text = "－";
                        if(i < tmpWordCnt){
                            tmpLbl?.text = "●";
                            
                        }
                        
                        
                    }
                })
                
                if((tmpWordCnt == 4)&&(string != "")){
                    finishPassProcessing(hiddenFld.text! + string)
                }
                return true
            }
            
            
            
        }
        
        return false
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool{
//        textField.resignFirstResponder()
        return false
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
//        textField.resignFirstResponder()
        return false
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
