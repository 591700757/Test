//
//  PVDSettingController.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/28.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD
import AVFoundation
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class PVDSettingController: UITableViewController,UIPickerViewDelegate,UIPickerViewDataSource{

    @IBOutlet weak var buildVersion: UILabel!
    @IBOutlet weak var noiseReductionSlider: UISlider!
    @IBOutlet weak var noiseReductionStepper: UIStepper!
    @IBOutlet weak var noiceReductionLbl: UILabel!
    @IBOutlet weak var inspectWithSpeech: UISwitch!//発話中認識
    @IBOutlet weak var nrSwitch: UISwitch!
    @IBOutlet weak var autoUploadSwitch: UISwitch!//自動アップロード
    

    
    @IBOutlet weak var fontSlider: UISlider!
    @IBOutlet weak var fontsizeLbl: UILabel!
    @IBOutlet weak var descriptionFontSlider: UISlider!
    @IBOutlet weak var descriptionFontsizeLbl: UILabel!
    @IBOutlet weak var siriRateSlider: UISlider!
    @IBOutlet weak var siriRateLbl: UILabel!
    @IBOutlet weak var singleTapGesture: UITapGestureRecognizer!
    @IBOutlet weak var reportdownloadBtn: UIButton!
    @IBOutlet weak var lastupdateLbl: UILabel!
    @IBOutlet weak var siriLangeChangeBtn: UIButton!

    @IBOutlet weak var speakerDownloadBtn: UIButton!
    
    var langPicker:UIPickerView?
    let kPickerActualHeight:CGFloat = 162

//    var downloadDatalist:NSMutableArray!
    var noiseModeChanged:Bool!
//    var speakerPicker:UIPickerView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.tableFooterView = UIView()
        self.tableView.separatorInset = UIEdgeInsets.zero
        self.tableView.layoutMargins = UIEdgeInsets.zero
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        self.noiseReductionStepper.stepValue = 0.1
        let localString1 = String(format: NSLocalizedString("UXXX-004", comment: ""))
        let localString2 = String(format: NSLocalizedString("UXXX-005", comment: ""))
        let localString3 = String(format: NSLocalizedString("L002-003", comment: ""), gsettingModel.lastupdate!)
        
//        ableView.layoutMargins = UIEdgeInsetsZero
        
        self.title = localString1
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: localString2, style: UIBarButtonItemStyle.plain, target: self, action: #selector(PVDSettingController.dismissConfigAction(_:)))
        self.singleTapGesture.cancelsTouchesInView = false
        self.view.addGestureRecognizer(singleTapGesture)
        // Do any additional setup after loading the view.
        let oldtts:String = gsettingModel.inspectionOnSpeech!
        let oldnr:String = UserDefaults.standard.object(forKey: kNrInUseKey) as! String
        //音声合成Default
        if(oldtts == "true"){
            inspectWithSpeech.isOn = true
        }else{
            inspectWithSpeech.isOn = false
        }
        //Noise reducation default
        let noiseLevel:Float = ((UserDefaults.standard.object(forKey: kNrLevelKey) as AnyObject).floatValue)!
        if(oldnr == "2ch"){
            nrSwitch.isOn = true
        }else{
            nrSwitch.isOn = false
        }
                
        
        noiseReductionSlider.value =  noiseLevel
        noiseReductionStepper.value =  Double(noiseLevel)
        noiceReductionLbl.text = String(format: "%.1f",noiseLevel)
        noiseModeChanged = false


        siriRateSlider.maximumValue = Float(kVoicedoMaximumSpeechRate)
        siriRateSlider.minimumValue = Float(kVoiceMinimumSpeechRate)
        siriRateSlider.value = gSiriSpeechRate
        
        siriRateLbl.text = String(String(format: "%.02f", gSiriSpeechRate))
        reportdownloadBtn.layer.cornerRadius = 5
        reportdownloadBtn.clipsToBounds = true
        speakerDownloadBtn.layer.cornerRadius = 5
        speakerDownloadBtn.clipsToBounds = true


        lastupdateLbl.text = localString3
        fontSlider.maximumValue = Float(kVoicedoMaximumGFontSize)
        fontSlider.minimumValue = Float(kVoicedoMinimumGFontSize)
        if(gsettingModel.globalFontSize != nil){
            fontsizeLbl.text = String(format:"%02d",Int(gsettingModel.globalFontSize!))
            fontSlider.value = Float(gsettingModel.globalFontSize!)
            
        }
        if(gsettingModel.globalDescriptionFontSize != nil){
            descriptionFontsizeLbl.text = String(format:"%02d",Int(gsettingModel.globalDescriptionFontSize!))
            descriptionFontSlider.value = Float(gsettingModel.globalDescriptionFontSize!)
            
        }
        if(gsettingModel.autoUpload == true){
            autoUploadSwitch.isOn = true
        }else{
            autoUploadSwitch.isOn = false
        }
        buildVersion.text = "Build Version:" + UIApplication.versionBuild()
        
        

        
        if(gsettingModel.siriLangurage == SiriLangKey.kJapanese.rawValue){
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kJapanese.rawValue, for: UIControlState())
        }else if(gsettingModel.siriLangurage == SiriLangKey.kEnglish.rawValue){
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kJapanese.rawValue, for: UIControlState())
        }else if(gsettingModel.siriLangurage == SiriLangKey.kChinese.rawValue){
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kChinese.rawValue, for: UIControlState())
        }
        
        

        
    }
    
    
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//        speakerPicker.frame = CGRectMake(0, CGRectGetMaxY(speakerPickerBtn.frame), kScreenWidth, kPickerHeight)
//    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        langPicker = UIPickerView(frame: CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: kPickerActualHeight))
        langPicker!.backgroundColor = UIColor(red: 244.0/255.0, green: 244.0/255.0, blue: 244.0/255.0, alpha: 1.0)
        langPicker!.delegate = self
        langPicker!.dataSource = self
        let window = UIApplication.shared.keyWindow
        window!.addSubview(langPicker!)
        window!.bringSubview(toFront: langPicker!)
        
        if(gsettingModel.siriLangurage == SiriLangKey.kJapanese.rawValue){
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kJapanese.rawValue, for: UIControlState())
        }else if(gsettingModel.siriLangurage == SiriLangKey.kEnglish.rawValue){
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kEnglish.rawValue, for: UIControlState())
        }else if(gsettingModel.siriLangurage == SiriLangKey.kChinese.rawValue){
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kChinese.rawValue, for: UIControlState())
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDSettingController.showSystemSettingAction), name: NSNotification.Name(rawValue: kShowSystemSettingActionNotification), object: nil)
        if((gHomeJumpToServerSettingFlag == true)||(gHomeJumpToExtraSettigFlag == true)){
            let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
            let tmpPass:String? = UserDefaults.standard.object(forKey: kSystemSettingPasswordKey) as? String
            if(tmpPass == nil){
                self.navigationController?.pushViewController(tpStoryBoard.instantiateViewController(withIdentifier: "PVDExtraSettingController"), animated: true)
            }else{
                gHomeJumpToServerSettingFlag = false
                gHomeJumpToExtraSettigFlag = false
            }
            
            
        }
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kShowSystemSettingActionNotification), object: nil)
        DispatchQueue.main.async { () -> Void in
            SVProgressHUD.dismiss()
        }
        
        langPicker?.removeFromSuperview()

        
    }
    
    deinit{
        
    }
    
    
    //MARK: Notification Method
    func showSystemSettingAction(){
        let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
        let control:PVDExtraSettingController = tpStoryBoard.instantiateViewController(withIdentifier: "PVDExtraSettingController") as! PVDExtraSettingController
//        control.popflag = true
        self.navigationController?.pushViewController(control, animated: true)
//        self.presentViewController(tpStoryBoard.instantiateViewControllerWithIdentifier("PVDExtraSettingController"), animated: true, completion: nil)
    
    }
    
    //MARK: xib actions
    
    @IBAction func autoUploadValueChanged(_ sender: UISwitch) {
        gsettingModel.autoUpload = sender.isOn
        PVDSwiftUtils.saveSettingFile()
        UserDefaults.standard.synchronize()
        
    }
    @IBAction func langPickerBtnAction(_ sender: UIButton) {
        DispatchQueue.main.async { () -> Void in
            if(self.langPicker?.frame.origin.y > (kScreenHeight - self.kPickerActualHeight) ){
                self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight - self.kPickerActualHeight, width: kScreenWidth, height: self.kPickerActualHeight)
                
                
            }else{
                self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight,width: kScreenWidth, height: self.kPickerActualHeight)
            }
        }
        
        
    }
    
    @IBAction func gotoSystemSettingAction(_ sender: UIButton) {
        
    }
    
      @IBAction func nrSwitchValueChanged(_ sender: UISwitch) {
        if(sender.isOn == true){
            UserDefaults.standard.set("2ch", forKey: kNrInUseKey)
            //2ch
            
            (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.twoChannelType)
            gsettingModel.voiceDoChannel = "2ch"
        }else{
            UserDefaults.standard.set("1ch", forKey: kNrInUseKey)
            //1ch
            (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.oneChannelType)
            gsettingModel.voiceDoChannel = "1ch"
        }

        
        
        PVDSwiftUtils.saveSettingFile()
        UserDefaults.standard.synchronize()
        
        
        
    }
    
    
    @IBAction func inspectWithSpeechSwitchValueChanged(_ sender: UISwitch) {
        if(sender.isOn == true){
            //VoiceDoの合成を使わない場合はこのswitchを発話の時に解析するswiftにつかう
            gsettingModel.inspectionOnSpeech = "true"
        }else{
            gsettingModel.inspectionOnSpeech = "false"
        }
        UserDefaults.standard.set(gsettingModel.inspectionOnSpeech, forKey: kInspectWithSpeechKey)
        
        PVDSwiftUtils.saveSettingFile()
        UserDefaults.standard.synchronize()
        
    }
    
    
    @IBAction func fontSizeValueChanged(_ sender: UISlider) {
        gsettingModel.globalFontSize = CGFloat(sender.value)
        fontsizeLbl.text = String(format:"%02d",Int(sender.value))
        PVDSwiftUtils.saveSettingFile()
    }
    
    @IBAction func descriptionFontSizeValueChanged(_ sender: UISlider) {
        gsettingModel.globalDescriptionFontSize = CGFloat(sender.value)
        descriptionFontsizeLbl.text = String(format:"%02d",Int(sender.value))
        PVDSwiftUtils.saveSettingFile()
    }

   
    
 
    
    /**
    キャンセル時の操作
    
    - parameter sender: キャンセルButton
    */
    func dismissConfigAction(_ sender: AnyObject) {
        self.dismiss(animated: true) { () -> Void in
//            NSNotificationCenter.defaultCenter().postNotificationName(UIApplicationWillEnterForegroundNotification, object: nil)
            NotificationCenter.default.post(name: Notification.Name(rawValue: kUpdateunishedWorkSharingStateNotification), object: nil)
//            self.updateunishedWorkSharingState()
        }
    }
    
    

    
    
    
    @IBAction func noiseReductionStepperValueChanged(_ sender: UIStepper) {
        noiceReductionLbl.text = String(format: "%.1f",sender.value)
        noiseReductionSlider.value = Float(sender.value)
        PSRManager.setNoiseLevel(noiseReductionSlider.value)
    }
    
    
    @IBAction func noiseSliderValueChanged(_ sender: UISlider) {
        
        noiceReductionLbl.text = String(format: "%.1f",sender.value)
        noiseReductionStepper.value = Double(sender.value)

        PSRManager.setNoiseLevel(noiseReductionSlider.value)


    }
    
    
    @IBAction func singleTapGestureAction(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
        DispatchQueue.main.async { () -> Void in
            self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: self.kPickerActualHeight)
        }
       
    }
    
    
    
    @IBAction func siriSpeechRateChangedeAction(_ sender: UISlider) {
        
        gSiriSpeechRate = sender.value
        siriRateLbl.text = String(format: "%.02f", gSiriSpeechRate)
        gsettingModel.siriSpeechRate = String(siriRateSlider.value)
        PVDSwiftUtils.saveSettingFile()
    }
    
    
    

    
    @IBAction func processfileDownload(_ sender: UIButton) {
  
        let localString1 = String(format: NSLocalizedString("L002-007", comment: ""))
        let localString2 = String(format: NSLocalizedString("L002-004", comment: ""))
        let localString3 = String(format: NSLocalizedString("UXXX-002", comment: ""))
        let localString4 = String(format: NSLocalizedString("UXXX-003", comment: ""))
        if(FileManager.default.fileExists(atPath: kreportZipfilePath) == true){
             try! FileManager.default.removeItem(atPath: kreportZipfilePath)
        }
       
        let alert = UIAlertController(title: localString1, message: localString2, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: localString3, style: UIAlertActionStyle.cancel, handler:nil))
        alert.addAction(UIAlertAction(title: localString4, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            self.processfileDownloadAction(kReportFileDownloadURL, folderPath: kreportsFolderPath, zipFilePath: kreportZipfilePath)
        }))
        
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })

    }
    
    @IBAction func processingSpeakerDownload(_ sender: UIButton) {
        if(FileManager.default.fileExists(atPath: kspeakerZipfilePath) == true){
            try! FileManager.default.removeItem(atPath: kspeakerZipfilePath)
        }
        let localString1 = String(format: NSLocalizedString("L002-008", comment: ""))
        let localString2 = String(format: NSLocalizedString("L002-005", comment: ""))
        let localString3 = String(format: NSLocalizedString("UXXX-002", comment: ""))
        let localString4 = String(format: NSLocalizedString("UXXX-003", comment: ""))
        
        let alert = UIAlertController(title: localString1, message: localString2, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: localString3, style: UIAlertActionStyle.cancel, handler:nil))
        alert.addAction(UIAlertAction(title: localString4, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            self.processfileDownloadAction(kSpearkFileDownloadURL, folderPath: kspeakerFolderPath, zipFilePath: kspeakerZipfilePath)
        }))
        
        
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true, completion: nil)
        })
    }
  
    
    func processfileDownloadAction(_ url:String,folderPath:String,zipFilePath:String){
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークン"))
        let l002006 = String(format: NSLocalizedString("L002-006", comment: "帳票データをダウンロードpercent"))
        let l002009 = String(format: NSLocalizedString("L002-009", comment: "帳票データをダウンロードpercent"))
        let uxxx007 = String(format: NSLocalizedString("UXXX-007", comment: "ダウンロードに失敗"))
        let uxxx008 = String(format: NSLocalizedString("UXXX-008", comment: "ファイルを解凍"))
        let uxxx009 = String(format: NSLocalizedString("UXXX-009", comment: "解凍失敗"))
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx034 = String(format: NSLocalizedString("UXXX-034", comment: "話者ファイルがありません"))
        var progresstext:String = ""
        if(url == kReportFileDownloadURL){
            progresstext = l002006
        }else{
            progresstext = l002009
        }
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            let alert = UIAlertController(title: uxxx020, message: uxxx021, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.processfileDownloadAction(url, folderPath: folderPath, zipFilePath: folderPath)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return
        }
        if(gsettingModel.tokenString == nil){
            DispatchQueue.main.async { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx006)
            }
            
            return
        }
        DispatchQueue.main.async {
            SVProgressHUD.showProgress(0, status: progresstext)
            
            SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.none)
        }
        
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .libraryDirectory, in: .userDomainMask)
        let tokenString =  gsettingModel.tokenString!
        let downloadUrl = url + "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString)
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>帳票/ユーザーダウンロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + downloadUrl)
        alamofireManager.download(downloadUrl, to: destination).downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
            
            if(progress.fractionCompleted == 1){
                gsettingModel.lastupdate = PVDSwiftUtils.getoutputTimeStamp(Date())
                PVDSwiftUtils.saveSettingFile()
            }
            
            
            DispatchQueue.main.async {
                SVProgressHUD.showProgress(Float(progress.fractionCompleted), status: String(format: "\(progresstext)(%d%%)", Int(progress.fractionCompleted*100)))
                
            }
            }
            .validate { request, response, temporaryURL, destinationURL in
                return .success
            }
            
            .responseData{ response in
                
                if let error = response.error {
                    PVDSwiftUtils.writeAccessLog("<<帳票/ユーザーダウンロード>>:失敗" + error.localizedDescription)

                    if let resOb = response.response{
                        if(resOb.allHeaderFields["ResultCode"] == nil){
                            PVDSwiftUtils.writeAccessLog("<<帳票/ユーザーダウンロード>>:" + uxxx007)
                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: uxxx007)
                            }
                            return
                        }
                        if(Int(resOb.allHeaderFields["ResultCode"] as! String) == 0){
                            PVDSwiftUtils.writeAccessLog("<<帳票/ユーザーダウンロード>>:" + uxxx034)
                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: uxxx034)
                            }
                            
                            return
                        }
                    }
                    PVDSwiftUtils.writeAccessLog("<<帳票/ユーザーダウンロード>>:" + uxxx007)
                    print("Failed with error: \(error)")
                    DispatchQueue.main.async {
                        SVProgressHUD.showError(withStatus: uxxx007)
                    }
                    
                } else {
                    print("Downloaded file successfully")
                    PVDSwiftUtils.writeAccessLog("<<帳票/ユーザーダウンロード>>:" + uxxx008)
                    DispatchQueue.main.async {
                        SVProgressHUD.showInfo(withStatus: uxxx008)
                    }
                    
                    if(FileManager.default.fileExists(atPath: folderPath) == false){
                        try! FileManager.default.createDirectory(atPath: folderPath, withIntermediateDirectories: true, attributes: nil)
                    }
                    let ret:Bool =  ZipArchiveManager.unzipFile(withZipArchive: zipFilePath, destinationPath: kLibDomainPath)
                    if(ret == false){
                        PVDSwiftUtils.writeAccessLog("<<帳票/ユーザーダウンロード>>:" + uxxx009)
                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: uxxx009)
                        }
                    }else{
                        self.readdownloadDictory(folderPath, zipPath: zipFilePath)
                    }
                }

                
        }

    }
    
    func readdownloadDictory(_ srcPath:String,zipPath:String){
        let fm = FileManager.default
        if(fm.fileExists(atPath: khomejsonFolder) == false){
            try! fm.createDirectory(atPath: khomejsonFolder, withIntermediateDirectories: true, attributes: nil)
        }
        let l002003 = String(format: NSLocalizedString("L002-003", comment: "最終更新時間:%@"), gsettingModel.lastupdate!)
        let uxxx013 = String(format: NSLocalizedString("UXXX-013", comment: "ファイル適用失敗"))

        let l002002 = String(format: NSLocalizedString("L002-002", comment: "適用が完了"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx010 = String(format: NSLocalizedString("UXXX-010", comment: "メッセージ"))
        

        DispatchQueue.main.async(execute: { () -> Void in
            if(FileManager.default.fileExists(atPath: srcPath) == true){
                let dirEnum:FileManager.DirectoryEnumerator = fm.enumerator(atPath: srcPath)!
                var tmppath:String? = dirEnum.nextObject() as? String
                while( tmppath != nil){
                    if(tmppath![0] == "."){
                        tmppath = dirEnum.nextObject() as? String
                        continue
                    }
                    
                    let fromPath:String = srcPath + "/" + tmppath!
                    let toPath:String = khomejsonFolder + "/" + tmppath!
                    if(FileManager.default.fileExists(atPath: toPath) == true){
                        //元のファイルを削除して、新しいファイルを適用
                        try! FileManager.default.removeItem(atPath: toPath)
                    }
                    
                    
                    do{
                        try FileManager.default.copyItem(atPath: fromPath, toPath: toPath)
                    }catch{
                        print(error)
                        let tmpAlert = UIAlertView(title: uxxx013, message: nil, delegate: nil
                            , cancelButtonTitle: nil)
                        tmpAlert.show()
                        PVDSwiftUtils.dispatchAfterMain(1, afterBlock: { (Void) -> Void in
                            tmpAlert.dismiss(withClickedButtonIndex: 0, animated: true)
                        })
                        break
                    }
                    tmppath = dirEnum.nextObject() as? String
                    
                }
                
                if(FileManager.default.fileExists(atPath: zipPath) == true){
                    //適用後にzipファイルを削除する
                    try! FileManager.default.removeItem(atPath: zipPath)
                    
                }
                if(FileManager.default.fileExists(atPath: srcPath) == true){
                    try! FileManager.default.removeItem(atPath: srcPath)
                }
                self.lastupdateLbl.text = l002003

            }else{
                NSLog("downloadpath not found:%@",srcPath)
            }
            SVProgressHUD.dismiss()
            UIAlertView(title: uxxx010, message: l002002, delegate: nil
                , cancelButtonTitle: uxxx003).show()
        })
        
        
        
    }

    
    
    //MARK: tableview  delegate datasource
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath){
//        super.tableView(tableView, willDisplayCell: cell, forRowAtIndexPath: indexPath)
        if((indexPath.row == 1)||(indexPath.row == 4)||(indexPath.row == 5)||(indexPath.row == 10)){//sperator not to the left margin
            return
        }
        cell.layoutMargins = UIEdgeInsets.zero
    }
    

    

    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        DispatchQueue.main.async { () -> Void in
            if(segue.identifier == kPushToAdvancedSetting){
                let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
                let tmpPass:String? = UserDefaults.standard.object(forKey: kSystemSettingPasswordKey) as? String
                if(tmpPass == nil){
                    NotificationCenter.default.post(name: Notification.Name(rawValue: kShowSystemSettingActionNotification), object: nil)
                }else{
                    UserDefaults.standard.set(PVDPassInputCtrlMode.kGotoSys.rawValue, forKey: kPassInputCtrlKey)
                      self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDPassInputController"), animated: true, completion: nil)
                    
                }
            }
        }
        
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }

    //MARK: pickerview delegate,datasource
    /**
    * ピッカーに表示する列数を返す
    */
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    /**
     * ピッカーに表示する行数を返す
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat{
        return 30
    }
    
    
    
    /**
     * 行のサイズを変更
     */
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat{
        return kScreenWidth
    }
    
    
    /**
     * ピッカーに表示する値を返す
     */
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(row == 0){
            return SiriLangDisPlay.kJapanese.rawValue
        }else if(row == 1){
            return SiriLangDisPlay.kEnglish.rawValue
        }else if(row == 2){
            return SiriLangDisPlay.kChinese.rawValue
        }
        return SiriLangDisPlay.kJapanese.rawValue

    }
    
    
    /**
     * ピッカーの選択行が決まったとき
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        if(row == 0){
            gsettingModel.siriLangurage = SiriLangKey.kJapanese.rawValue
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kJapanese.rawValue, for: UIControlState())
            
        }else if(row == 1){
            gsettingModel.siriLangurage = SiriLangKey.kEnglish.rawValue
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kEnglish.rawValue, for: UIControlState())
        
        }else{
            gsettingModel.siriLangurage = SiriLangKey.kChinese.rawValue
            self.siriLangeChangeBtn.setTitle(SiriLangDisPlay.kChinese.rawValue, for: UIControlState())
        }
        SpeechTalkManager.sharedInstance.setSiriVoice(gsettingModel.siriLangurage!)

        DispatchQueue.main.async { () -> Void in
            self.langPicker?.layer.frame = CGRect(x: 0, y: kScreenHeight,width: kScreenWidth, height: self.kPickerActualHeight)

        }
        PVDSwiftUtils.saveSettingFile()
        
    }


    
    
    
    
    
    
 

}
