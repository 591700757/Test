//
//  PVDHomeController.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/11.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper
import Alamofire
import KeychainAccess
import SVProgressHUD
import MJRefresh
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}



var g_firstRunFlag:Bool = true
class PVDHomeController: UIViewController,UITableViewDelegate,UITableViewDataSource,UIPickerViewDataSource,UIPickerViewDelegate,UIGestureRecognizerDelegate{
    typealias PVDUnfinishedSortBlock = (_ index:NSInteger,_ worksharingCnt:NSInteger) -> (NSInteger)
    
    let kPickerHeight:CGFloat = 184
    let psrManager: AnyObject! = PSRManager.shareInstance() as AnyObject
    var finishedList:PVDWaitingListModel!
    var munfinishedList:PVDWaitingListModel!
    var munfinishedDisplayList:PVDWaitingListModel!
//    var unfinishedListOrder:Bool!     //true:新しい順->古い順  false:古い順->新しい順
    var guploadedList:PVDWaitingListModel!
    var calculateLbl:UILabel!
    
    var reportList:PVDWaitingListModel!
    var heightOfInViewTbl:CGFloat! = 0

    var cellfont:UIFont = UIFont.systemFont(ofSize: 40)
    var heightOfDate:CGFloat! = 0
    var widthOfDate:CGFloat! = 0
    var tapToSelect:UITapGestureRecognizer!
    var speakerPicker:UIPickerView!
    var gdownloadRecordList:PVDShareDownloadListModel!
    var gsettingStatusView:PVDSettingStatusView!
    var speakerList:NSMutableArray!
    
    @IBOutlet weak var uploadResultBtn: UIButton!
    
    @IBOutlet var singleTapgesture: UITapGestureRecognizer!
    @IBOutlet weak var waitingTbl: UITableView!
    @IBOutlet weak var speakerPickerBtn: UIButton!

    @IBOutlet weak var unfinishedTbl: UITableView!
    @IBOutlet weak var unfinishedCntLbl: UILabel!
    @IBOutlet weak var finishedTbl: UITableView!
    @IBOutlet weak var uploadedTbl: UITableView!
    
    
    @IBOutlet weak var workerField: UITextField!
    @IBOutlet weak var settingBtn: UIButton!

    @IBOutlet  var finishedTblHeight: NSLayoutConstraint!
    @IBOutlet  var unfinishedTblHeight: NSLayoutConstraint!
    @IBOutlet  var waitingTblHeight: NSLayoutConstraint!
    @IBOutlet  var uploadedTblHeight: NSLayoutConstraint!
    
    @IBOutlet weak var showFomartBtn: UIButton!
    @IBOutlet weak var showUnfinishedBtn: UIButton!
    @IBOutlet weak var showFinishedBtn: UIButton!
//    @IBOutlet weak var showUploadedBtn: UIButton!
    @IBOutlet weak var showUploadedBtn: UIButton!
    @IBOutlet weak var unfinishedOrderbtn: UIButton!
    
    
    @IBOutlet weak var finishedCountLbl: UILabel!
   
    

    
    
    //MARK: CrittercismDelegate Method
    func crittercismDidCrashOnLastLoad() {
        print("App crashed the last time it was loaded")
    }
    
    
    // MARK: - life cycle
    init() {
        super.init(nibName: "PVDHomeController", bundle: nil)
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)!
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        waitingTbl.rowHeight = UITableViewAutomaticDimension
        unfinishedTbl.rowHeight = UITableViewAutomaticDimension
        finishedTbl.rowHeight = UITableViewAutomaticDimension
        uploadedTbl.rowHeight = UITableViewAutomaticDimension
        finishedTbl.estimatedRowHeight = 120
        unfinishedTbl.estimatedRowHeight = 120
        waitingTbl.estimatedRowHeight = 120
        uploadedTbl.estimatedRowHeight = 120
        

        waitingTbl.delegate = self
        waitingTbl.dataSource = self
        finishedTbl.delegate = self
        finishedTbl.dataSource = self
        unfinishedTbl.delegate = self
        unfinishedTbl.dataSource = self
        uploadedTbl.delegate = self
        uploadedTbl.dataSource = self
        
        
        let l007003 = String(format: NSLocalizedString("L007-003", comment: "プルダウンで再読み込む"))
        let l007004 = String(format: NSLocalizedString("L007-004", comment: "リリースで再読み込む"))
        let l007005 = String(format: NSLocalizedString("L007-005", comment: "データ請求中"))
        let l007006 = String(format: NSLocalizedString("L007-006", comment: "中断復帰"))
        let l007007 = String(format: NSLocalizedString("L007-007", comment: "中断のデータが見つかりました、復帰しますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))

        let unfinishedHeader = MJRefreshNormalHeader(refreshingBlock: { [weak self]() -> Void in
            if let selfWeak = self {
                selfWeak.unfinishedPullDownAction(true)
            }
        })
        unfinishedHeader?.setTitle(l007003, for: .idle)
        unfinishedHeader?.setTitle(l007004, for: .pulling)
        unfinishedHeader?.setTitle(l007005, for: .refreshing)
        unfinishedHeader?.lastUpdatedTimeLabel?.isHidden = true
        unfinishedTbl.mj_header = unfinishedHeader

        waitingTbl.tableFooterView = UIView()
        finishedTbl.tableFooterView = UIView()
        unfinishedTbl.tableFooterView = UIView()
        uploadedTbl.tableFooterView = UIView()
        self.navigationController?.navigationItem.backBarButtonItem?.title = ""
        self.view.addGestureRecognizer(singleTapgesture)
        singleTapgesture.cancelsTouchesInView = false
        
        showFomartBtn.addTarget(self, action: #selector(PVDHomeController.showTableAction(_:)), for: .touchUpInside)
        showUnfinishedBtn.addTarget(self, action: #selector(PVDHomeController.showTableAction(_:)), for: .touchUpInside)
        showFinishedBtn.addTarget(self, action: #selector(PVDHomeController.showTableAction(_:)), for: .touchUpInside)
        showUploadedBtn.addTarget(self, action: #selector(PVDHomeController.showTableAction(_:)), for: .touchUpInside)
        
        //復帰チェック
        let keychain = Keychain(service: kKeyChainKey)
        let backdatafile:String?
        do{
            backdatafile = try keychain.getString(kreportResultDataBackupKey)
        }catch let error as NSError{
            print(error)
            backdatafile = nil
        }
        
        
        if((backdatafile != nil)&&(backdatafile != "")&&(reportList != nil)&&(reportList.waitingItems != nil) && (reportList.waitingItems?.count > 0)){
            let backUpArray:NSArray = (backdatafile?.components(separatedBy: ","))! as NSArray
            if(backUpArray.count == 3){
                let bReportFromIdKey:String = backUpArray[0] as! String
                let bWorkPlanIdKey:String = backUpArray[1] as! String
                let bInputJsonFileTypeKey:String = backUpArray[2] as! String
                var tmpWaitItem:PVDWaitingModel? = nil
                for backModel in reportList.waitingItems!{
                    if(backModel.reportId == bReportFromIdKey){
                        tmpWaitItem = backModel
                        break
                    }
                }
                if(tmpWaitItem != nil){
                    let alert = UIAlertController(title: l007006, message: l007007, preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: uxxx002, style: .default, handler: { (UIAlertAction) -> Void in
                        //                PVDSwiftUtils.setKeyChainValueForKey("", key: kreportResultDataBackupKey)
                    }))
                    alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                        NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpWaitItem!,kWorkPlanIdKey:bWorkPlanIdKey,kInputJsonFileTypeKey:bInputJsonFileTypeKey])
                    }))
                    DispatchQueue.main.async(execute: {
                        self.present(alert, animated: true, completion: nil)
                    })

                }
                            }else{
                NSLog("イレギュラーの復帰データ")
            }
        }
        
        //クリアバックアップデータ
        PVDSwiftUtils.setKeyChainValueForKey("", key: kreportResultDataBackupKey)
        
        //specker picker初期化
        speakerPicker = UIPickerView()
        speakerPicker.isHidden = true
        speakerPicker.backgroundColor = UIColor.white
        
        self.view.addSubview(speakerPicker)
        
        tapToSelect = UITapGestureRecognizer(target: self, action: #selector(PVDHomeController.tappedToSelectRow(_:)))
        tapToSelect.delegate = self
        
        speakerPicker!.addGestureRecognizer(tapToSelect)
        speakerPicker.delegate = self
        speakerPicker.dataSource = self
        speakerPickerBtn.titleLabel?.lineBreakMode = .byWordWrapping
        speakerPickerBtn.addTarget(self, action: #selector(PVDHomeController.pickerBtnAction(_:)), for: UIControlEvents.touchUpInside)
        self.speakerList = NSMutableArray()
        
        uploadResultBtn.layer.cornerRadius = 5
        uploadResultBtn.clipsToBounds = true
        uploadResultBtn.addTarget(self, action: #selector(PVDHomeController.uploadResultAction), for: .touchUpInside)
        
        uploadResultBtn.isEnabled = false
        uploadResultBtn.backgroundColor = UIColor(red: 254/255.0, green: 214/255.0, blue: 231/255.0, alpha: 1)
        
        speakerPickerBtn.layer.borderColor = UIColor.black.cgColor
        speakerPickerBtn.layer.borderWidth = 1
        
        gsettingStatusView = PVDSettingStatusView.instance()
        gsettingStatusView.frame = CGRect(x: 5, y: 40, width: kScreenWidth - 10, height: kScreenHeight - 60)

        gsettingStatusView.closeBtn.addTarget(self, action: #selector(PVDInputController.closeSettingStatusView), for: .touchUpInside)
        gsettingStatusView.layoutIfNeeded()
        gsettingStatusView.prepareSettingView()
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        heightOfInViewTbl = waitingTbl.frame.height +  unfinishedTbl.frame.height + finishedTbl.frame.height
        
        speakerPicker.frame = CGRect(x: 0, y: speakerPickerBtn.frame.maxY, width: kScreenWidth, height: kPickerHeight)
        
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(gsettingModel.showingModelViewflag == true){
            return
        }
        PVDSwiftUtils.saveSettingFile()
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kReceivedInpectionResultNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceReloadHomeUnfinishedTblNotification), object: nil)
        NotificationCenter.default.removeObserver(self,name: NSNotification.Name(rawValue: kStartInspectionCallbackNotification),object: nil)
        NotificationCenter.default.removeObserver(self,name: NSNotification.Name(rawValue: kUpdateunishedWorkSharingStateNotification),object: nil)
        
//        PVDDatabaseAccess.sharedInstance.clearTmpDumpTable()
        _ = psrManager.voicedoCloseDic()
        DispatchQueue.main.async { () -> Void in
            SVProgressHUD.dismiss()
        }
        PVDDatabaseAccess.sharedInstance.updateTmpDumpToAudioDump { (result) in
            if(result == true){
                print("ダンプファイル保存成功")
            }else{
                print("ダンプファイル保存失敗")
            }
            
        }
        PVDDatabaseAccess.sharedInstance.updateDumpDuration()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if(gsettingModel.showingModelViewflag == true){
            return
        }
        let uxxx068 = String(format: NSLocalizedString("UXXX-068", comment: "engine init failed"))
        //try init engine if engine is not initialized
        if(gInspectInitResult != 0){
            gInspectInitResult =  (PSRManager.shareInstance() as AnyObject).voicedoInit(PVDSwiftUtils.getShareContainerDomainPath(),
                                                                         iniUrl:  PVDSwiftUtils.getEngineSettingFilePath())
            if(gInspectInitResult != 0){
                DispatchQueue.main.async(execute: { () -> Void in
                    PSRManager.sendLogTextAsync([kLogViewKey:uxxx068])
                })
            }
        }
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        if(gsettingModel.globalFontSize  != nil){
            cellfont =  UIFont.systemFont(ofSize: gsettingModel.globalFontSize!)
            let dateRect:CGRect = NSString(string: "YYYY/MM/DD").boundingRect(with: CGSize(width: kScreenWidth, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: cellfont], context: nil)
            
            heightOfDate = dateRect.height
            widthOfDate = dateRect.width
        }
        //音声Dump初期化
        let pathOfDumpFolder:String! = NSHomeDirectory().stringByAppendingPathComponent(kInspectionDumpPath)
        if(FileManager.default.fileExists(atPath: pathOfDumpFolder) == false){
            try! FileManager.default.createDirectory(atPath: pathOfDumpFolder, withIntermediateDirectories: true, attributes: nil)
        }
        gStartInspectionFlag = .kDoNothing
        self.navigationController?.navigationBar.isHidden = true

        NotificationCenter.default.addObserver(self, selector: #selector(PVDHomeController.receivedInpectionResultAction(_:)), name: NSNotification.Name(rawValue: kReceivedInpectionResultNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDHomeController.reloadHomeNOtificationAction(_:)), name: NSNotification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(PVDHomeController.getWaitingList), name: NSNotification.Name(rawValue: kVoiceReloadHomeUnfinishedTblNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDHomeController.startInspectionCBAction(_:)), name: NSNotification.Name(rawValue: kStartInspectionCallbackNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDHomeController.updateunishedWorkSharingState), name: NSNotification.Name(rawValue: kUpdateunishedWorkSharingStateNotification), object: nil)
        
        
        self.getSpeakerList()
        self.getWaitingList()
        let choosedSpeakerfullfilePath =  (NSHomeDirectory() as NSString).appendingPathComponent(gsettingModel.choosedSpeakerfilePath!)
        gReportAndUserSetReuslt = psrManager.voicedoChangeUserAndDic(false, speakerPath: choosedSpeakerfullfilePath, dicPath: NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFile), showMessage: false)
        

        psrManager.voicedoSetLogLevel(Int32(gsettingModel.logLevel!)!)
        updateUnfinishedSort()
        
        DispatchQueue.main.async(execute: { () -> Void in
            if(gsettingModel.unfinishedListOrder == true){
                self.unfinishedOrderbtn.setBackgroundImage(UIImage(named:"icon_sortup" ), for: UIControlState())
                
            }else{
                self.unfinishedOrderbtn.setBackgroundImage(UIImage(named:"icon_sortdown" ), for: UIControlState())
            }
        })

        
        

    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        gsettingModel.showingModelViewflag = false
        UIApplication.shared.isIdleTimerDisabled = true
        if(gsettingModel.choosedSpeaker != nil){
            self.speakerPickerBtn .setTitle( gsettingModel.choosedSpeaker!, for: UIControlState())
        }
        PVDSwiftUtils.dispatchAfterMain(0.3) { (Void) in
            self.reloadHomeAction(true)
        }
        
    }
    
// MARK: - 引き継ぎアップロード、ダウンロード
    /**
    引き継ぎリストから引き継ぎ対象のダウンロード
    */
    func processingWorkSharingDownloadList(_ array:NSMutableArray){
        let l007001 = String(format: NSLocalizedString("L007-001", comment: "引き継ぎ対象が設定されていません"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        if(array.count == 0){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l007001)
            })
            
            return
        }
        if(kworksharefileDownURL == ""){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx003)
            })
            
            return
        }
        let target:String = array.object(at: 0) as! String

        array.removeObject(at: 0)
        self.processingWorkSharingDownload(target,array:array)
    }
    
    /**
     特定の引き継ぎ対象から引き継ぎファイルを引き継ぐ
     
     - parameter target: 引き継ぐ対象のdeviceid
     */
    func processingWorkSharingDownload(_ target:String,array:NSMutableArray?){
        
        
        
        let l007008 = String(format: NSLocalizedString("L007-008", comment: "引き継ぎファイルをダウンロードしています"))
        let l007009 = String(format: NSLocalizedString("L007-009", comment: "引き継ぎファイルダウンロードに失敗しました"))
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let uxxx009 = String(format: NSLocalizedString("UXXX-009", comment: "解凍失敗"))
        let uxxx027 = String(format: NSLocalizedString("UXXX-027", comment: "解凍中"))
        let uxxx028 = String(format: NSLocalizedString("UXXX-028", comment: "解凍成功"))
        
        
        if(gsettingModel.tokenString == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx006)
            })
            
            return
        }
        //暫定で１デバイスのダウンロードしてから適用
        if(FileManager.default.fileExists(atPath: kworksharingTmpzip) == true){
            try! FileManager.default.removeItem(atPath: kworksharingTmpzip)
        }

        SVProgressHUD.show(withStatus: l007008)
        let tokenString = gsettingModel.tokenString!
        var requestURL:String = ""
        let lastdltime:String? = PVDSwiftUtils.getLastWorkSharingDownloadTimeByDeviceId(target)
        if(lastdltime == nil){
            requestURL = kworksharefileDownURL +  "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString) + "&deviceid=" + target + "&lastdltime="
        }else{
            requestURL = kworksharefileDownURL +  "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString) + "&deviceid=" + target + "&lastdltime=" + lastdltime!
        }
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>引き継ぎダウンロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + requestURL)
        print(requestURL)
        if(FileManager.default.fileExists(atPath: kworksharingTmpFoder) == false){
            try! FileManager.default.createDirectory(atPath: kworksharingTmpFoder, withIntermediateDirectories: true, attributes: nil)
        }
        PVDSwiftUtils.saveSettingFile()
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .libraryDirectory, in: .userDomainMask)
        alamofireManager.download(requestURL, to: destination).response { response in // method defaults to `.get`
            if let error = response.error {
                PVDSwiftUtils.writeAccessLog("<<引き継ぎダウンロード>>:" + l007009 + error.localizedDescription)
                DispatchQueue.main.async {
                    SVProgressHUD.showError(withStatus: l007009)
                }
                return
            }
            //暫定で１デバイスのダウンロードしてから適用
            PVDSwiftUtils.writeAccessLog("<<引き継ぎダウンロード>>:" + l007009)
            if(FileManager.default.fileExists(atPath: kworksharingTmpzip) == false){
                DispatchQueue.main.async {
                    SVProgressHUD.showError(withStatus: l007009)
                }
                return
            }
            PVDSwiftUtils.writeAccessLog("<<引き継ぎダウンロード>>:" + uxxx027)
            SVProgressHUD.show(withStatus: uxxx027)
            DispatchQueue.main.async {
                let ret =  ZipArchiveManager.unzipFile(withZipArchive: kworksharingTmpzip, destinationPath: kworksharingTmpFoder)
                if(ret == false){
                    PVDSwiftUtils.writeAccessLog("<<引き継ぎダウンロード>>:" + uxxx009)
                    SVProgressHUD.showError(withStatus: uxxx009)
                    
                    //途中で失敗した場合更新した最終アップロード時間を設定ファイルから読み戻す
                    PVDSwiftUtils.reloadSettingFile()
                    return
                }
                SVProgressHUD.showSuccess(withStatus: uxxx028)
                //download最新時間更新
                let timefilePath = kworksharingTmpFoder + "/unfinished/time.json"
                if(FileManager.default.fileExists(atPath: timefilePath) == true){
                    let timeDic:NSDictionary? = PVDSwiftUtils.getDictionarybyFullPath(kworksharingTmpFoder + "/unfinished/time.json")
                    var timestamp:String?
                    if(timeDic != nil){
                        timestamp = timeDic?.object(forKey: "dl_time") as? String
                    }
                    if(timestamp != nil){
                        PVDSwiftUtils.updateLastWorkSharingDownloadTimeByDeviceId(target, lastWorkSharingDownloadTime: timestamp!)
                    }
                    try! FileManager.default.removeItem(atPath: timefilePath)
                }
                if((array?.count == 0)||(array == nil)){
                    _ = self.applyWorkSharingFileToLocalDevice(kworksharingTmpFoder + "/unfinished")
                    
                }else{
                    self.processingWorkSharingDownloadList(array!)
                }

            }
            
            
        }

    }
    
    
    func removedatafromDownloadlist(_ original_result_id:String){
        if((gdownloadRecordList == nil)||(gdownloadRecordList.items == nil)){
            return
        }
        let downloadRecordDic:[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(kShareDownloadListJson)
        gdownloadRecordList = Mapper<PVDShareDownloadListModel>().map(JSON: downloadRecordDic!)
        if let oindex = gdownloadRecordList?.items?.index(where: {$0.original_result_id == original_result_id}) {
            gdownloadRecordList.items?.remove(at: oindex)
            let tJSONString = Mapper().toJSONString(gdownloadRecordList!, prettyPrint: true)
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kShareDownloadListJson)//引き継ぎダウンロードのレコード
        }
    }
    

    
    /**
     引き継ぎファイルを適応する
     
     - parameter folderPath: 指定のパース
     */
    func applyWorkSharingFileToLocalDevice(_ folderPath:String)->Bool{
        let l007010 = String(format: NSLocalizedString("L007-010", comment: "引き継ぎレポート指定が見つかりません"))
        let l007011 = String(format: NSLocalizedString("L007-011", comment: "引き継ぎ完了"))
        let l007029 = String(format: NSLocalizedString("L007-029", comment: "引き継ぎ適応"))
        //引き継ぎdownload参照リストのファイル読み込み
        let downloadRecordDic:[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(kShareDownloadListJson)
        if(downloadRecordDic == nil){
            gdownloadRecordList = nil
        }else{
            gdownloadRecordList = Mapper<PVDShareDownloadListModel>().map(JSON: downloadRecordDic!)
        }
        
        //解凍した引き継ぎファイルを一つ一つ未完了作業テーブルに追加する
        if(FileManager.default.fileExists(atPath: folderPath) == false){
            NSLog("指定のパースが存在しません")
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l007010)
            })
            
            return false
        }
        SVProgressHUD.show(withStatus: l007029)
        let fm = FileManager.default
        let dirEnum:FileManager.DirectoryEnumerator = fm.enumerator(atPath: folderPath)!
        var tmppath:String? = dirEnum.nextObject() as? String
        while( tmppath != nil){
            if(tmppath?.hasSuffix(".json") == false){
                tmppath = dirEnum.nextObject() as? String
                continue
            }
            let fromPath:String = folderPath + "/" + tmppath!

            let processDic :[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(fromPath)
            if(processDic == nil){
                continue
            }
            let resultModel:PVDReportResultModel  = Mapper<PVDReportResultModel>().map(JSON: processDic!)!
            //以前からダウンロードしたことがある結果ファイルかを確認する
            if((gdownloadRecordList != nil)&&(gdownloadRecordList?.items != nil)){
                //引き継ぎレコードにデータがある
//                var indexInDownloadList:Int = 0
                var foundInDownloadFlag:Bool = false
                var downloadRecord:PVDShareDownloadRecordModel!
                

                if let oindex = gdownloadRecordList?.items?.index(where: {$0.original_result_id == resultModel.original_result_id}) {
                    downloadRecord = gdownloadRecordList.items![oindex]
                    foundInDownloadFlag = true
                    let oldFileName:String = "result_" +  downloadRecord.local_result_id! + ".json"
                    var oldFilePath:String = ""
                    var tmpPath:String = kFinishedFolderPath + "/" + oldFileName
                    var updateType:PVDWorkShareRecordType = .kBackUpWorkShareData
                    //完了フォルーダで探す
                    if(FileManager.default.fileExists(atPath: tmpPath) == true){
                        oldFilePath = tmpPath
                        updateType = .kFinishedWorkShareData
                    }
                    //未完了フォルーダで探す
                    tmpPath = kUnfinishedFolderPath + "/" + oldFileName
                    if(FileManager.default.fileExists(atPath: tmpPath) == true){
                        oldFilePath = tmpPath
                        updateType = .kUnfinishedWorkShareData
                    }
                    //バックアップフォルーダで探す
                    tmpPath = kbackupFolder + "/" + oldFileName
                    if(FileManager.default.fileExists(atPath: tmpPath) == true){
                        oldFilePath = tmpPath
                        updateType = .kBackUpWorkShareData
                    }
                    if(oldFilePath == ""){
                        break
                    }
                    //complex =  N
                    self.checkUpdateWorkSharingData(resultModel, targetPath: oldFilePath,updateType: updateType,indexInDownloadList: oindex  )
                }
                
                if(foundInDownloadFlag == true){
                    tmppath = dirEnum.nextObject() as? String
                    continue
                }
                
            }
            
            //新規の引き継ぎ、リザルトファイルの作成者、更新時間、デバイスID、workPlanIdをダウンロードした時刻に更新する
            self.addNewWorkSharingDataToUnfinished(resultModel)
            tmppath = dirEnum.nextObject() as? String
        }
        //引き継ぎ臨時フォルダーを削除
        do{
            try FileManager.default.removeItem(atPath: folderPath)
        }catch let error as NSError{
            print(error)
        }
        //未完了リスト更新した結果をファイルに保存
        var tJSONString:String! = ""
        if(munfinishedList != nil){
            tJSONString = Mapper().toJSONString(munfinishedList, prettyPrint: true)
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
        }

        //完了リストで更新した結果をファイルに保存
        if(finishedList != nil){
            tJSONString = Mapper().toJSONString(finishedList, prettyPrint: true)
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kfinishedJsonPath)
        }
        

        //引き継ぎdownload参照リストのファイル保存
        if(gdownloadRecordList != nil){
            tJSONString = Mapper().toJSONString(gdownloadRecordList!, prettyPrint: true)
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kShareDownloadListJson)//引き継ぎダウンロードのレコード
        }
        

        

        DispatchQueue.main.async(execute: { () -> Void in
            SVProgressHUD.showSuccess(withStatus: l007011)

            PVDSwiftUtils.saveSettingFile()
        })
        self.reloadunFinishedTbl()
        
        return true
    }
    
    /**
     ダウンロードした引き継ぎファイルの更新時間をローカルのファイルと比較して
     
     - parameter resultModel: ダウンロードした引き継ぎデータ
     - parameter targetPath: ローカルの古い引き継ぎデータ
     */
    func checkUpdateWorkSharingData(_ resultModel:PVDReportResultModel,targetPath:String,updateType:PVDWorkShareRecordType,indexInDownloadList:Int){
        let oldDic :[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(targetPath)
        let oldModel:PVDReportResultModel  = Mapper<PVDReportResultModel>().map(JSON:oldDic!)!
        let oldInterval:TimeInterval = PVDSwiftUtils.getTimeIntervalFromTimeString(oldModel.file_changed_time!)
        let downloadInterval:TimeInterval = PVDSwiftUtils.getTimeIntervalFromTimeString(resultModel.file_changed_time!)
        if(oldInterval >= downloadInterval){
            //ローカルのファイルが新しい→更新しない
            return
        }
        
        
        //ダウンロードしたファイルの更新時間が新しい→更新する
        //データを更新する
        resultModel.work_plan_id = PVDSwiftUtils.getNextWorkPlanId()
        resultModel.user_name =  gsettingModel.choosedSpeaker
        resultModel.device_id = gsettingModel.deviceid!
        let newPath = targetPath.replacingOccurrences(of: oldModel.work_plan_id!, with: resultModel.work_plan_id!)
        let rJSONString = Mapper().toJSONString(resultModel, prettyPrint: true)
        //新しいファイルを作って
        PVDSwiftUtils.overwriteJsonStringTofile(rJSONString!, filePath: newPath)
        //古いファイルを削除
        do {
            try FileManager.default.removeItem(atPath: targetPath)
        }catch let error as NSError{
            print(error)
        }
        var hometargetlist:PVDWaitingListModel?
        //元のデータがいたリストのworkplanidとlast_edit_timeを更新する
        
        //未完了のみ処理
        switch(updateType){
        case .kBackUpWorkShareData:
            hometargetlist = nil
            break
        case .kFinishedWorkShareData:
            hometargetlist = nil
            break
        case .kUnfinishedWorkShareData:
            hometargetlist = munfinishedList
            break
        }
        if(hometargetlist != nil){
            var targetIndex:Int? = nil
            targetIndex = hometargetlist?.waitingItems?.index(where: {$0.workplanid == oldModel.work_plan_id})
            if(targetIndex != nil){
                let item = hometargetlist?.waitingItems![targetIndex!]
                item!.workplanid = resultModel.work_plan_id
                item!.lasteditDate = resultModel.file_changed_time
                if(resultModel.file_changed_time != nil){
                    item!.lasteditDateForSort = PVDSwiftUtils.getTimeIntervalFromTimeString(resultModel.file_changed_time!)
                }else{
                    item!.lasteditDateForSort = 0
                }
                
                item!.work_primary_id = resultModel.work_primary_id
            }
        }
        //download recordリストを更新(work plan idが変わるからファイル名も変わるのでlocal_result_idを更新する)
        let item:PVDShareDownloadRecordModel = (gdownloadRecordList?.items![indexInDownloadList])!
        item.original_result_id = resultModel.original_result_id!
        item.local_result_id = gsettingModel.deviceid! + "_" + resultModel.work_plan_id!
        

    }
    
    /**
     レポートファイルのuser name,device,work_plan_idをこのデバイスに登録されたものに書き換えて、unfinishedに移す
     
     - parameter path: 入力レポートファイルの名前
     */
    func addNewWorkSharingDataToUnfinished(_ resultModel:PVDReportResultModel){
        //workPlanId、ユーザ名、デバイスIDを更新する
        resultModel.work_plan_id = PVDSwiftUtils.getNextWorkPlanId()
        resultModel.user_name =  gsettingModel.choosedSpeaker
        resultModel.device_id = gsettingModel.deviceid!
        //未完了フォルダーへ新規引き継ぎ結果を追加する
        let rJSONString = Mapper().toJSONString(resultModel, prettyPrint: true)
        PVDSwiftUtils.saveReulstfile(nil, jsonString: rJSONString!,workplanid: resultModel.work_plan_id)
        //未完了リストを更新する
        self.workSharingAppendResultToUnfinishedJsonlist(resultModel)

        //引き継ぎ記録jsonを更新する todo check deviceid null
        self.addNewRecordToShareDownloadRecordList(resultModel.original_result_id!, local_result_id: gsettingModel.deviceid! + "_" + resultModel.work_plan_id!)
    }
    
    //引き継ぎダウンロードしたファイルを未完了リストへ適応する
    func workSharingAppendResultToUnfinishedJsonlist(_ resultModel:PVDReportResultModel){
        //create or general unfinished json list
        var neworiginal_result_id = ""
        if(resultModel.original_result_id == nil){
            neworiginal_result_id  = gsettingModel.deviceid! + "_" + resultModel.work_plan_id!
        }else{
            neworiginal_result_id = resultModel.original_result_id!
        }
        var tmpDic:[String:Any]!
        //work primary id とwork plan idの辞書を分けて使う
        if(resultModel.work_primary_id == nil){
            tmpDic = ["name":resultModel.report_form_name!,
                      "report_form_id":resultModel.report_form_id!,
                      "work_plan_id":resultModel.work_plan_id!,
                      "original_result_id":neworiginal_result_id,
                      "last_edit_time":PVDSwiftUtils.getoutputTimeStamp(Date())]
        }else{
            tmpDic = ["name":resultModel.report_form_name!,
                      "report_form_id":resultModel.report_form_id!,
                      "work_plan_id":resultModel.work_plan_id!,
                      "original_result_id":neworiginal_result_id,
                      "last_edit_time":PVDSwiftUtils.getoutputTimeStamp(Date()),
                      "work_primary_id":resultModel.work_primary_id!]
        }

        

        
        if(munfinishedList == nil){
            let unfinishedDic = ["list":[tmpDic]]
            munfinishedList = Mapper<PVDWaitingListModel>().map(JSON: unfinishedDic)
        }else{//同じoriginal result idの古いデータを削除して、引き継いたデータを追加する
            let newItem = Mapper<PVDWaitingModel>().map(JSON: tmpDic)
            if(resultModel.original_result_id != nil){
                //
                
                if let delindex = munfinishedList.waitingItems?.index(where: {$0.original_result_id == resultModel.original_result_id}) {
                    
                    munfinishedList.waitingItems?.remove(at: delindex)
                }
                else {
                    
                }
            }
            if(gsettingModel.unfinishedListOrder == true){
                munfinishedList?.waitingItems?.append(newItem!)
            }else{
                munfinishedList.waitingItems?.insert(newItem!, at: 0)
            }
            
        }
    }
    
    

    

    
    /**
     download listに新しい項目を追加、downlistはグロバル変数別途ファイルに反映する必要がある
     
     - parameter original_result_id: オリジナル結果ID
     - parameter local_result_id:　更新時に生成された結果ID
     */
    func addNewRecordToShareDownloadRecordList(_ original_result_id:String,local_result_id:String){
        var downloadRecordListDic:[String:Any]? = nil
        if(gdownloadRecordList?.items == nil){
            downloadRecordListDic = ["records":[["original_result_id":original_result_id,"local_result_id":local_result_id]]]
            gdownloadRecordList = Mapper<PVDShareDownloadListModel>().map(JSON: downloadRecordListDic!)
        }else{
            let downloadRecordDic:[String:Any]? = ["original_result_id":original_result_id,"local_result_id":local_result_id]
            let downloadRecord:PVDShareDownloadRecordModel? = Mapper<PVDShareDownloadRecordModel>().map(JSON: downloadRecordDic!)
            gdownloadRecordList?.items?.append(downloadRecord!)
        }

    }
    

    
    
    func processingWorkSharingManualUpload(_ workplanid:String){
        let uxxx022 = String(format: NSLocalizedString("UXXX-022", comment: "アップロードURLが正しく設定されていません"))
        let uxxx024 = String(format: NSLocalizedString("UXXX-024", comment: "引き継ぎファイルアップロード中"))
        let uxxx025 = String(format: NSLocalizedString("UXXX-025", comment: "アップロード成功"))
        let uxxx026 = String(format: NSLocalizedString("UXXX-026", comment: "アップロード失敗"))
        let uxxx029 = String(format: NSLocalizedString("UXXX-029", comment: "異常のレスボンス"))
        let l006013 = String(format: NSLocalizedString("L006-013", comment: "サーバーレスボンス取得失敗"))
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            let alert = UIAlertController(title: uxxx020, message: uxxx021, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.processingWorkSharingManualUpload(workplanid)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return
        }
        
        //アップロードして、次のstepへ(次のstep or next report)
        if(kworksharefileUploadURL == ""){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx022)
            })
            
            return
        }
        
        if(gsettingModel.tokenString == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx006)
            })
            
            return
        }
        
        
        let tmpResultFileName:String! =  "/result_" + gsettingModel.deviceid! + "_" + workplanid + ".json"
        let tmpResultFilePath:String! =  kUnfinishedFolderPath + tmpResultFileName
        let tokenString =  gsettingModel.tokenString!
        let downloadUrl = kworksharefileUploadURL + "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString)
        
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>引き継ぎアップロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + downloadUrl)
        SVProgressHUD.show(withStatus: uxxx024)
        if(FileManager.default.fileExists(atPath: tmpResultFilePath) == true){
            NSLog("exist")
        }else{
            NSLog("not exist")
        }
        let fileURL = URL(fileURLWithPath: (tmpResultFilePath))
        
        alamofireManager.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(fileURL, withName: "work")
        }, to: downloadUrl) { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:リクエスト成功")
                    if(response.result.value != nil){
                        let retDic:NSDictionary = response.result.value as! NSDictionary
                        let retValue = retDic.object(forKey: "result") as? NSNumber
                        if(retValue! == 0){
                            PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:" + uxxx025)
                            DispatchQueue.main.async {
                                SVProgressHUD.showSuccess(withStatus: uxxx025)
                            }
                            PVDSwiftUtils.updateWorkShareState(byWorkPlanId: workplanid)
                            self.unfinishedDataReload()//tbl reload in this
                            
                        }else{
                            PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:" + uxxx026)
                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: uxxx026)
                            }
                            
                        }
                    }else{
                        PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:" + uxxx029)

                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: uxxx029)
                        }
                    }
                }
            case .failure(let encodingError):
                print(encodingError)
                PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:リクエスト失敗。error Code:" + String(encodingError._code) + "\n" + l006013)

                DispatchQueue.main.async {
                    SVProgressHUD.showError(withStatus: l006013)
                }
                
                
            }
            
        }

    }
    
    
    func updateunishedWorkSharingState(){
        
        let unfinishedDic:[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)
        if(unfinishedDic == nil){
            return 
        }
        munfinishedDisplayList = Mapper<PVDWaitingListModel>().map(JSON: unfinishedDic!)
        if((munfinishedDisplayList == nil)||(munfinishedDisplayList.waitingItems == nil)){
            NSLog("waitingItems is nil")
            return
        }
        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            do{
                try FileManager.default.createDirectory(atPath: kbackupFolder, withIntermediateDirectories: true, attributes: nil)
            }catch let error as NSError{
                print(error)
            }
            
        }
        var sortBlock:PVDUnfinishedSortBlock?
        //        = { (次のIndex,引き継ぎ済み累積数) in
        sortBlock = { (index,workSharingCnt) in
            let tmpItem = self.munfinishedDisplayList.waitingItems![index]
            var tpworkSharingCnt = workSharingCnt
            if(tmpItem.work_sharing_uploaded == true){
                tpworkSharingCnt += 1
            }else{
                return tpworkSharingCnt
            }
            
            //今の結果記録が設定数目以上の引き継ぎずみデータならそのデータをバックアップに持って行く
            if((tpworkSharingCnt > gsettingModel.workSharingBackUpMax!)){
                //ファイルを移動して、リストから除外
                self.munfinishedDisplayList.waitingItems?.remove(at: index)
            }
            return tpworkSharingCnt
        }
        var workSharingCnt = 0 //引き継ぎ済みのCounter
        // true:古い順->新しい順
        if(gsettingModel.unfinishedListOrder == true){
            var index:Int = munfinishedDisplayList.waitingItems!.count - 1
            while(index >= 0){
                workSharingCnt = sortBlock!(index,workSharingCnt)
                index -= 1
            }

        }else{//false:新しい順->古い順
            var index:Int = 0
            while(index < munfinishedDisplayList.waitingItems!.count){
                let tmpItem = self.munfinishedDisplayList.waitingItems![index]

                if(tmpItem.work_sharing_uploaded == true){
                    workSharingCnt += 1
                }
                if((workSharingCnt > gsettingModel.workSharingBackUpMax!)&&(tmpItem.work_sharing_uploaded == true)){
                    //ファイルを移動して、リストから除外
                    self.munfinishedDisplayList.waitingItems?.remove(at: index)
                }else{
                    index += 1
                }
                
            }
        
        }
        self.reloadunFinishedTbl()

        
    }

    // MARK: - tableview delegate and datasource
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat { return UITableViewAutomaticDimension }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat { return UITableViewAutomaticDimension }
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if(tableView == waitingTbl){
            if((reportList != nil) && reportList.waitingItems != nil){
                return reportList.waitingItems!.count
            }
        }else if(tableView == unfinishedTbl){//unfinished
            if(munfinishedDisplayList != nil && munfinishedDisplayList.waitingItems != nil){
                return munfinishedDisplayList.waitingItems!.count
            }
        }else if(tableView == finishedTbl){//finished
            if(finishedList != nil && finishedList.waitingItems != nil){
                return finishedList.waitingItems!.count
            }
        }else{
            if(guploadedList != nil && guploadedList.waitingItems != nil){
                return guploadedList.waitingItems!.count
            }
        }
        return 0
    }
    

    
    
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let l007012 = String(format: NSLocalizedString("L007-012", comment: "[引き継ぎ済]"))

        var dateArray:NSArray
        if(tableView == waitingTbl){
            let CellIdentifier = kPVDWaitingDefaultCell
            var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: CellIdentifier)
            if cell == nil{
                cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: CellIdentifier)
                cell?.textLabel?.textColor = UIColor(red:111/255.0, green: 113/255.0, blue: 121/255.0, alpha: 1.0)
            }
            if(reportList.waitingItems?.count <= indexPath.row){
                return cell!
            }
            let tmpModel = reportList.waitingItems?[indexPath.row]
            cell!.textLabel?.lineBreakMode = .byWordWrapping
            cell!.textLabel?.numberOfLines = 0
            cell!.textLabel?.text = tmpModel!.waitingTitle
            cell!.textLabel?.font = self.cellfont
            return cell!
        }else if(tableView == unfinishedTbl){
            let cell: PVDWaitingFinishedCell = tableView.dequeueReusableCell(withIdentifier: kPVDWaitingFinishedCell, for: indexPath) as! PVDWaitingFinishedCell
            let tmpModel:PVDWaitingModel! = munfinishedDisplayList.waitingItems?[indexPath.row]
            var hikitugiStr:String = ""
            if(munfinishedDisplayList.waitingItems?.count <= indexPath.row){
                return cell
            }
            if(tmpModel.work_sharing_uploaded == true){
                hikitugiStr = l007012
            }

            cell.titleDetailLbl.text =   tmpModel!.waitingTitle!
            cell.titleDetailLbl.lineBreakMode = .byWordWrapping
            cell.titleDetailLbl.numberOfLines = 0
            
            dateArray = (tmpModel.lasteditDate?.components(separatedBy: " "))! as NSArray
            if(dateArray.count == 2){
                cell.dateLbl.text = dateArray[0] as? String
                cell.dateHMSLbl.text = dateArray[1] as? String
            }
            cell.titleDetailLbl.font = cellfont
            cell.titleLabel.font = cellfont
            cell.dateLbl.font = cellfont
            cell.dateHMSLbl.font = cellfont

            
            cell.dateLbl.textColor = UIColor.black
            cell.dateHMSLbl.textColor = UIColor.black
            
            if((tmpModel.work_primary_id != nil)&&(tmpModel.work_sharing_uploaded != true)){
                cell.titleLabel.text = tmpModel.work_primary_id! + hikitugiStr
                cell.titleLabel.textColor = UIColor.blue
                cell.titleLabel.font = UIFont.boldSystemFont(ofSize: cellfont.pointSize)
            }else{
                cell.titleLabel.text = tmpModel!.workplanid! + hikitugiStr
                cell.titleLabel.textColor = UIColor.lightGray
            }


            if(tmpModel.work_sharing_uploaded == true){//引き継ぎ済みcell
                cell.titleLabel.textColor =  UIColor.lightGray
                cell.titleDetailLbl.textColor = UIColor.lightGray
                cell.dateLbl.textColor = UIColor.lightGray
                cell.dateHMSLbl.textColor = UIColor.lightGray
            }


            
            return cell
        }else if(tableView == finishedTbl){
            let cell: PVDWaitingFinishedCell = tableView.dequeueReusableCell(withIdentifier: kPVDWaitingFinishedCell, for: indexPath) as! PVDWaitingFinishedCell
            if(finishedList.waitingItems?.count <= indexPath.row){
                return cell
            }
            let tmpModel:PVDWaitingModel! = finishedList.waitingItems?[indexPath.row]
            if(tmpModel.work_primary_id != nil){
                cell.titleLabel.text = tmpModel.work_primary_id!
                cell.titleLabel.textColor = UIColor.blue
            }else{
                cell.titleLabel.text = tmpModel!.workplanid!
                cell.titleLabel.textColor = UIColor.lightGray
            }
            cell.titleDetailLbl.text =    tmpModel!.waitingTitle!
            
            
            dateArray = (tmpModel.lasteditDate?.components(separatedBy: " "))! as NSArray
            
            if(dateArray.count == 2){
                cell.dateLbl.text = dateArray[0] as? String
                cell.dateHMSLbl.text = (dateArray[1] as! String)
            }
            cell.dateLbl.font = cellfont
            cell.titleLabel.font = cellfont
            cell.titleDetailLbl.font = cellfont
            cell.dateHMSLbl.font = cellfont
            
            return cell
        }else{//uploaded table
            let cell: PVDWaitingFinishedCell = tableView.dequeueReusableCell(withIdentifier: kPVDWaitingFinishedCell, for: indexPath) as! PVDWaitingFinishedCell
            if(guploadedList.waitingItems?.count <= indexPath.row){
                return cell
            }
            let tmpModel:PVDWaitingModel! = guploadedList.waitingItems?[indexPath.row]
            if((tmpModel.work_primary_id != nil)&&(tmpModel.work_primary_id != "")){
                cell.titleLabel.text = tmpModel.work_primary_id!
                cell.titleLabel.textColor = UIColor.blue
            }else{
                cell.titleLabel.text = tmpModel!.workplanid!
                cell.titleLabel.textColor = UIColor.lightGray
            }
            cell.titleDetailLbl.text =    tmpModel!.waitingTitle!
            
            
            dateArray = (tmpModel.lasteditDate?.components(separatedBy: " "))! as NSArray
            
            if(dateArray.count == 2){
                cell.dateLbl.text = dateArray[0] as? String
                cell.dateHMSLbl.text = (dateArray[1] as! String)
            }
            cell.dateLbl.font = cellfont
            cell.titleLabel.font = cellfont
            cell.titleDetailLbl.font = cellfont
            cell.dateHMSLbl.font = cellfont
        
            return cell
        }

        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let l007040 = String(format: NSLocalizedString("L007-040", comment: "old data"))
        
        let tmpModel:PVDWaitingModel
        let dictionaryPath:String
        let reportPath:String
        if(tableView == waitingTbl){//新規
            tmpModel = (reportList.waitingItems?[indexPath.row])!
            
            
            NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpModel,kWorkPlanIdKey:PVDSwiftUtils.getNextWorkPlanId(),kInputJsonFileTypeKey:kPVDInputTypeNew])
            
            
        }else if(tableView == unfinishedTbl){//未完了レポート
            tmpModel = (munfinishedDisplayList.waitingItems?[indexPath.row])!
            dictionaryPath  =  NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + tmpModel.reportId! + ".mrg")
            reportPath      =  NSHomeDirectory().stringByAppendingPathComponent(kLibReportFolder + tmpModel.reportId! + ".json")
            if((FileManager.default.fileExists(atPath: dictionaryPath) == false)||(FileManager.default.fileExists(atPath: reportPath) == false)){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l007040)
                })
                
                return
            }

            NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpModel,kWorkPlanIdKey:tmpModel.workplanid!,kInputJsonFileTypeKey:kPVDInputTypeUnfinished])
            
        }else if(tableView == finishedTbl){//完了レポート
            tmpModel = (finishedList.waitingItems?[indexPath.row])!
            dictionaryPath  =  NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + tmpModel.reportId! + ".mrg")
            reportPath      =  NSHomeDirectory().stringByAppendingPathComponent(kLibReportFolder + tmpModel.reportId! + ".json")
            if((FileManager.default.fileExists(atPath: dictionaryPath) == false)||(FileManager.default.fileExists(atPath: reportPath) == false)){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l007040)
                })
                return
            }
            NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpModel,kWorkPlanIdKey:tmpModel.workplanid!,kInputJsonFileTypeKey:kPVDInputTypeFinished])
        }else{//アップロード済みのテーブル
            tmpModel = (guploadedList.waitingItems?[indexPath.row])!
            dictionaryPath  =  NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + tmpModel.reportId! + ".mrg")
            reportPath      =  NSHomeDirectory().stringByAppendingPathComponent(kLibReportFolder + tmpModel.reportId! + ".json")
            if((FileManager.default.fileExists(atPath: dictionaryPath) == false)||(FileManager.default.fileExists(atPath: reportPath) == false)){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l007040)
                })
                return
            }
            NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpModel,kWorkPlanIdKey:tmpModel.workplanid!,kInputJsonFileTypeKey:kPVDInputTypeUploaded])
            
        }

        
    }
    
    
    
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool{
        if((tableView == waitingTbl)||(tableView == uploadedTbl)){
            return false
        }else{
            return true
        }
        
    }
    
    func tableView( _ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?  {
        let l007014 = String(format: NSLocalizedString("L007-014", comment: "再アップロード"))
        let l007015 = String(format: NSLocalizedString("L007-015", comment: "削除"))
        let l007016 = String(format: NSLocalizedString("L007-016", comment: "削除しました"))
        let l007041 = String(format: NSLocalizedString("L007-041", comment: "未完了アップ"))
        //未完了アップロード
        let unfinishedUploadAction = UITableViewRowAction(style: .default, title: l007041, handler: { (action , indexPath) -> Void in
            if(FileManager.default.fileExists(atPath: kUnfinishedUploadTmpFolderPath) == true){
                try! FileManager.default.removeItem(atPath: kUnfinishedUploadTmpFolderPath)
            }
            try! FileManager.default.createDirectory(atPath: kUnfinishedUploadTmpFolderPath, withIntermediateDirectories: true, attributes: nil)
            let tmpModel:PVDWaitingModel!  = self.munfinishedDisplayList.waitingItems?[indexPath.row]
            
            let filePath = "/result_" + tmpModel.original_result_id! + ".json"
            //upload
            self.uploadFinishedAndUnfinishedResultAction(filePath,finishedFlag:false,workid:tmpModel.workplanid!)
        })
        // add the action button you want to show when swiping on tableView's cell , in this case add the delete button.
        //作業引き継ぎ再アップロード
        let uploadAction = UITableViewRowAction(style: .default, title: l007014, handler: { (action , indexPath) -> Void in
            let tmpModel:PVDWaitingModel!  = self.munfinishedDisplayList.waitingItems?[indexPath.row]
            //upload
            self.processingWorkSharingManualUpload(tmpModel.workplanid!)
            
        })
        //結果ファイル削除
        let deleteAction = UITableViewRowAction(style: .default, title: l007015, handler: { (action , indexPath) -> Void in
            let tmpModel:PVDWaitingModel!
            var pathOfReportToRemove:String!
    
            if(tableView == self.unfinishedTbl){
                tmpModel = self.munfinishedDisplayList.waitingItems?[indexPath.row]
                let target_originalid = tmpModel.original_result_id
                
                self.removedatafromDownloadlist(target_originalid!)
                let filePath = "/result_" + gsettingModel.deviceid! + "_" +  tmpModel.workplanid! + ".json"
                pathOfReportToRemove = kUnfinishedFolderPath  + filePath
                PVDSwiftUtils.removejsonFromList(false, tWorkPlanId: tmpModel.workplanid!)
                self.getWaitingList()
                PVDSwiftUtils.dispatch_async_main({ () -> () in
                        PVDSwiftUtils.showAlertAfterDismiss("", alertString: l007016, dismissTime: 1)
                })
                
            }else if(tableView == self.finishedTbl){
                tmpModel = self.finishedList.waitingItems?[indexPath.row]
                let filePath = "/result_" + gsettingModel.deviceid! + "_" +  tmpModel.workplanid! + ".json"
                pathOfReportToRemove = kFinishedFolderPath  + filePath
                PVDSwiftUtils.removejsonFromList(true, tWorkPlanId: tmpModel.workplanid!)
                self.getWaitingList()
                PVDSwiftUtils.dispatch_async_main({ () -> () in

                    PVDSwiftUtils.showAlertAfterDismiss("", alertString: l007016, dismissTime: 1)

                    
                })
            }
            
            if(FileManager.default.fileExists(atPath: pathOfReportToRemove)){
                try! FileManager.default.removeItem(atPath: pathOfReportToRemove)
            }else{
                NSLog("remove report failed can find path:%@",pathOfReportToRemove)
            }
            
        })
        
        // You can set its properties like normal button
        deleteAction.backgroundColor = UIColor.red
        uploadAction.backgroundColor = UIColor.green
        unfinishedUploadAction.backgroundColor = UIColor.blue
        if((tableView == self.unfinishedTbl)&&(gsettingModel.workSharingFlag == true)){
            return [unfinishedUploadAction,uploadAction,deleteAction]
        }else{
            return [deleteAction]
        }
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
        
    }

    
    
    //MARK: - xib methods
    @IBAction func sortunfinishedAction(_ sender: UIButton) {
        if(gsettingModel.unfinishedListOrder == false){
            gsettingModel.unfinishedListOrder = true
            unfinishedOrderbtn.setBackgroundImage(UIImage(named:"icon_sortup" ), for: UIControlState())
            
        }else{
            gsettingModel.unfinishedListOrder = false
            unfinishedOrderbtn.setBackgroundImage(UIImage(named:"icon_sortdown" ), for: UIControlState())
        }
        unfinishedSortByLastedit()

        reloadunFinishedTbl()
    }
    
    
    
    @IBAction func openSettingStatus(_ sender: AnyObject) {
        (UIApplication.shared.delegate as! AppDelegate).window?.addSubview(gsettingStatusView)
        gsettingStatusView.layer.cornerRadius = 5
        gsettingStatusView.clipsToBounds = true
        gsettingStatusView.layoutSubviews()
        
        gsettingStatusView.statuslist = PVDSwiftUtils.sharedInstance.getSettingStatus()
        gsettingStatusView.reloadSettingStatusTbl()
        
        
    }
    
    
    // MARK: - private methods
    
    //未完了再開indexを取得
    func getunfinishedIndex()->NSInteger?{
        if(munfinishedDisplayList == nil){
            return nil
        }
        // true:古い順->新しい順
        if(gsettingModel.unfinishedListOrder == true){
            var index:Int = munfinishedDisplayList.waitingItems!.count - 1
            while(index >= 0){
                let tmpItem = self.munfinishedDisplayList.waitingItems![index]
                if(tmpItem.work_sharing_uploaded == false){
                    return index
                }
                index -= 1
            }
            
        }else{//false:新しい順->古い順
            var index:Int = 0
            while(index < munfinishedDisplayList.waitingItems!.count){
                let tmpItem = self.munfinishedDisplayList.waitingItems![index]
                
                if(tmpItem.work_sharing_uploaded == false){
                    return index
                }
                index += 1
                
                
            }
            
        }
        return nil
    }
    
    
    func unfinishedDataReload(){
        let unfinishedDic:[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)

        if((unfinishedDic == nil)||(unfinishedDic?["list"] == nil)){
            print("no unfinished")
            munfinishedList = nil
            munfinishedDisplayList = nil
            return
            
        }
        munfinishedList = Mapper<PVDWaitingListModel>().map(JSON: unfinishedDic!)
        munfinishedDisplayList = Mapper<PVDWaitingListModel>().map(JSON: unfinishedDic!)
        updateunishedWorkSharingState()
        
    }

    
    func updateUnfinishedSort(){
        if((munfinishedList == nil)||(munfinishedList.waitingItems == nil)){
            return
        }
        if(gsettingModel.unfinishedSortUpdated != true){
            SVProgressHUD.show(withStatus: "データ更新中")
            for item in munfinishedList.waitingItems!{
                if((item.lasteditDateForSort == nil)&&(item.lasteditDate != nil)){
                    item.lasteditDateForSort = PVDSwiftUtils.getTimeIntervalFromTimeString(item.lasteditDate!)
                }
            }
            SVProgressHUD.showSuccess(withStatus: "データ更新完了")
            gsettingModel.unfinishedSortUpdated = true
            PVDSwiftUtils.saveSettingFile()
            var tJSONString:String! = ""
            if(munfinishedList != nil){
                tJSONString = Mapper().toJSONString(munfinishedList, prettyPrint: true)
                PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
            }
        }
    
    }
    
    
    func unfinishedSortByLastedit(){
        if((munfinishedList == nil)||(munfinishedList.waitingItems == nil)||(munfinishedList.waitingItems?.count == 0)){
            return
        }
        print("aa#:\(gsettingModel.unfinishedListOrder)")
        munfinishedList.waitingItems?.sort{
            if(($0.lasteditDateForSort == nil)||($1.lasteditDateForSort == nil)){
                gsettingModel.unfinishedSortUpdated = nil
                return true
            }
            let lastdate1 = $0.lasteditDateForSort!
            let lastdate2 = $1.lasteditDateForSort!
            if(lastdate1 < lastdate2){//古い->新しい順
                if(gsettingModel.unfinishedListOrder == false){
                    return false
                }else{
                    return true
                }
            }else{//新しい->古い順
                if(gsettingModel.unfinishedListOrder == false){
                    return true
                }else{
                    return false
                }
            }
        }
        if(gsettingModel.unfinishedSortUpdated == nil){
            updateUnfinishedSort()// preprare data
            unfinishedSortByLastedit()//re-sort
            return
        }
        var tJSONString:String! = ""
        if(munfinishedList != nil){
            tJSONString = Mapper().toJSONString(munfinishedList, prettyPrint: true)
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
        }
        updateunishedWorkSharingState()
    }
    
    
    func closeSettingStatusView(){
        gsettingStatusView.removeFromSuperview()
    }
    func unfinishedPullDownAction(_ manually:Bool){
        let l007001 = String(format: NSLocalizedString("L007-001", comment: "引き継ぎ対象が設定されていません"))
        let l007002 = String(format: NSLocalizedString("L007-002", comment: "引き継ぎダウンロード失敗:ネットワーク接続が 見つかりませんでした"))
        
        if(gsettingModel.workSharingFlag == false){//応支援しないフラグ
            if(manually == true){
                DispatchQueue.main.async(execute: { () -> Void in
                    self.unfinishedTbl.mj_header.endRefreshing()
                })
            }
            
            return
        }
        if(gsettingModel.workSharingArray == nil){//応支援対象がいない
            if(gsettingModel.workSharingFlag == true){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l007001)
                })
                if(manually == true){
                    self.unfinishedTbl.mj_header.endRefreshing()
                    
                }
            }
            
            return
        }
        
        
        if(PVDSwiftUtils.isConnectedToNetwork() == false){//インターネット接続がない
            DispatchQueue.main.async { () -> Void in
                SVProgressHUD.showError(withStatus: l007002)
                if(manually == true){
                    self.unfinishedTbl.mj_header.endRefreshing()
                }
            }
            
            return
        }
        
//        manually
        //応支援実行
        if(FileManager.default.fileExists(atPath: kworksharingTmpFoder) == true){
            try! FileManager.default.removeItem(atPath: kworksharingTmpFoder)
        }
        if(gsettingModel.workSharingFlag == true){
            self.processingWorkSharingDownloadList((gsettingModel.workSharingArray?.mutableCopy())! as! NSMutableArray)
        }
        
        
        if(manually == true){
            self.unfinishedTbl.mj_header.endRefreshing()
        }
    }

    /**
     サーバー設定が抜ける場合のチェック、抜けがある場合はサーバー設定画面まで飛ぶ
     
     - returns: true:設定に抜けがあり false:設定に抜けがない
     */
    func serverSettingCheck()->Bool{
        var nosetflag:Bool = false
        var target:String = ""
        repeat{
            if((gsettingModel.ipAddress == nil)||(gsettingModel.ipAddress == "")){
                nosetflag = true
                target = "「IP」"
                break
            }
            if((gsettingModel.port == nil)||(gsettingModel.port == "")){
                nosetflag = true
                target = "「Port」"
                break
            }
            if((gsettingModel.userid == nil)||(gsettingModel.userid == "")){
                nosetflag = true
                target = "「アカウントID」"
                break
            }
            if((gsettingModel.tokenString == nil)||(gsettingModel.tokenString == "")){
                nosetflag = true
                target = "「認証トークン」"
                break
            }
            if((gsettingModel.deviceid == nil)||(gsettingModel.deviceid == "")){
                nosetflag = true
                target = "「デバイスID」"
                break
            }
            if((gsettingModel.serverPath == nil)||(gsettingModel.serverPath == "")){
                nosetflag = true
                target = "「管理画面パス」"
                break
            }
        
        }while false;
        if(nosetflag == true){
            let l007046 = String(format: NSLocalizedString("L007-046", comment: "title"))
            let l007047 = String(format: NSLocalizedString("L007-047", comment: "message"))
            let uxxx019 = String(format: NSLocalizedString("UXXX-019", comment: "OK"))
            gHomeJumpToServerSettingFlag = true //直接jump to ...

            let alert = UIAlertController(title: l007046, message: target + l007047, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx019, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
                self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDSettingController"), animated: false, completion: nil)
            }))
            
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return true
        }else{
            return false
        }
        
    }
    
    

    func initFileCheck()->Bool{
        if(serverSettingCheck() == true){
            return false
        }
        
        let l007017 = String(format: NSLocalizedString("L007-017", comment: "初期設定のダウンロード"))
        let l007018 = String(format: NSLocalizedString("L007-018", comment: "アプリを動作させるには初期設定ファイルが必要です。ダウンロード画面に遷移します"))
        let uxxx019 = String(format: NSLocalizedString("UXXX-019", comment: "OK"))
        let engineFilePath = PVDSwiftUtils.getEngineSettingFilePath()
        
        if((engineFilePath == nil)||(FileManager.default.fileExists(atPath: engineFilePath!) == false)){
            let alert = UIAlertController(title: l007017, message: l007018, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx019, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                gHomeJumpToExtraSettigFlag = true       //直接jump to ...
                let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
                self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDSettingController"), animated: false, completion: nil)
            }))
            
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            
            return false
        }else{
            return true
        }
        
    }
    
    
    func reloadFinishedTbl(){
        
        
        
        PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
            

            
            if let selfWeak = self {
                let l007019 = String(format: NSLocalizedString("L007-019", comment: "完成0件"))
                selfWeak.finishedTbl.reloadData()
                if((selfWeak.finishedList == nil)||(selfWeak.finishedList.waitingItems?.count == 0)){
                    selfWeak.uploadResultBtn.isEnabled = false
                    selfWeak.uploadResultBtn.backgroundColor = UIColor(red: 254/255.0, green: 214/255.0, blue: 231/255.0, alpha: 1)
                    selfWeak.finishedCountLbl.text = l007019
                }else{
                    let l007020 = String(format: NSLocalizedString("L007-020", comment: "完成%d件"), (selfWeak.finishedList.waitingItems?.count)!)
                    selfWeak.uploadResultBtn.isEnabled = true
                    selfWeak.uploadResultBtn.backgroundColor = UIColor(red: 204/255.0, green: 68/255.0, blue: 125/255.0, alpha: 1)
                    
                    selfWeak.finishedCountLbl.text = l007020
                }
            }
            
            })
        
        
        
        
    }
    
    
    func reloadunFinishedTbl(){

        PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.unfinishedTbl.reloadData()
                
                if((selfWeak.munfinishedList == nil)||(selfWeak.munfinishedList.waitingItems!.count == 0)){
                    let l007021 = String(format: NSLocalizedString("L007-021", comment: "未完成0件"))
                    
                    selfWeak.unfinishedCntLbl.text = l007021
                }else{
                    let l007022 = String(format: NSLocalizedString("L007-022", comment: "未完成%d件"), (selfWeak.munfinishedList.waitingItems?.count)!)
                    selfWeak.unfinishedCntLbl.text = l007022
                    
                }
            }
        })
        
    }
    


    

    

    
    /**
     完了データアップロード
     */
    func uploadResultAction(){
        if((finishedList == nil)||(finishedList.waitingItems?.count == 0)){
            NSLog("完成状態のレポートがありません")
            return
        }
        DispatchQueue.main.async { () -> Void in
            self.uploadResultBtn.isEnabled = false
        }
        
        uploadFinishedAndUnfinishedResultAction(kFinishedFolderPath,finishedFlag:true,workid: nil)
    }
    
    
    
    
    


    

    /**
    完了/未完了の作業結果をアップロードする
    
    - parameter uploadTarget: アップロードの対象
    - parameter finishedFlag: true:完了レポート/false:未完了レポート
    - parameter workid:    finishedFlagがfalseの時のみ有効   未完成レポートから指定のworkplan idのレポートを削除
    */
    func uploadFinishedAndUnfinishedResultAction(_ uploadTarget:String,finishedFlag:Bool,workid:String?){
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx029 = String(format: NSLocalizedString("UXXX-029", comment: "異常のレスボンス"))
        let l007023 = String(format: NSLocalizedString("L007-023", comment: "アカウントが設定されていません"))
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let l007024 = String(format: NSLocalizedString("L007-024", comment: "結果ファイルの圧縮に失敗"))
        let uxxx014 = String(format: NSLocalizedString("UXXX-014", comment: "レスボンスエラー"))
        let l007026 = String(format: NSLocalizedString("L007-026", comment: "結果アップロード中です"))
        let l007027 = String(format: NSLocalizedString("L007-027", comment: "結果アップロード成功"))
        let l007028 = String(format: NSLocalizedString("L007-028", comment: "結果アップロード失敗"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let l007042 = String(format: NSLocalizedString("L007-042", comment: "unfinished upload failed,because of file not exist"))
        let l007043 = String(format: NSLocalizedString("L007-043", comment: "unfinished upload failed,because of workid null"))
        
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            let alert = UIAlertController(title: uxxx020, message: uxxx021, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
                if(finishedFlag == true){
                    self.uploadResultBtn.isEnabled = true
                }
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.uploadFinishedAndUnfinishedResultAction(uploadTarget,finishedFlag:finishedFlag,workid:workid)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return
        }
        if((finishedFlag == false)&&(workid == nil)){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l007043)
            })
            if(finishedFlag == true){
                self.uploadResultBtn.isEnabled = true
            }
            return
        }
        
        
        if(gsettingModel.tokenString == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: uxxx006)
            })
            if(finishedFlag == true){
                self.uploadResultBtn.isEnabled = true
            }
            return
        }
        if(FileManager.default.fileExists(atPath: kresultZipFileName) == true){
            try! FileManager.default.removeItem(atPath: kresultZipFileName)
        }
        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            try! FileManager.default.createDirectory(atPath: kbackupFolder, withIntermediateDirectories: true, attributes: nil);
        }
        
        if(gsettingModel.userid == nil){
            DispatchQueue.main.async(execute: { () -> Void in
                SVProgressHUD.showError(withStatus: l007023)
            })
            if(finishedFlag == true){
                self.uploadResultBtn.isEnabled = true
            }
            return
        }
        
        var uploadFold:String = uploadTarget
        if(finishedFlag == false){//未完了アップロード
            uploadFold = kUnfinishedUploadTmpFolderPath
            let unfinishedPath:String = kUnfinishedFolderPath  + uploadTarget
            print(unfinishedPath)
            if(FileManager.default.fileExists(atPath: unfinishedPath) == false){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: l007042)
                })
                return
            }
            do{
                try FileManager.default.copyItem(atPath: (kUnfinishedFolderPath  + uploadTarget), toPath: (kUnfinishedUploadTmpFolderPath + uploadTarget))
                
            }catch let error as NSError {
                print(error)
            }
        }
        let zipFlag:Bool = ZipArchiveManager.createZipFile(atPath: kresultZipFileName, withContentsOfDirectory: uploadFold, keepParentDirectory: true)
        
        if(zipFlag == false){
            UIAlertView(title: uxxx020, message: l007024, delegate: nil, cancelButtonTitle: "OK").show()
            NSLog(l007024)
            if(finishedFlag == true){
                self.uploadResultBtn.isEnabled = true
            }
            return
        }
        let tokenString =   gsettingModel.tokenString!
        
        let uploadUrl = kresultUploadURL + "&token=" + psrManager.getMD5(by: tokenString)
        SVProgressHUD.show(withStatus: l007026)
        
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>未完了/完了アップロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + uploadUrl)
        
        let fileURL = URL(fileURLWithPath: (kresultZipFileName))
        alamofireManager.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(fileURL, withName: "result")
        }, to: uploadUrl) { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.responseJSON { response in
                    PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:リクエスト成功")
                    debugPrint(response)
                    if(response.result.value != nil){
                        let retDic:NSDictionary = response.result.value as! NSDictionary
                        let retValue = retDic.object(forKey: "result") as? NSNumber

                        if(retValue == 0){//リスボンス取得成功、アップロード結果:成功
                            if(FileManager.default.fileExists(atPath: kresultZipFileName)){
                                do{
                                    try FileManager.default.removeItem(at: URL(fileURLWithPath: kresultZipFileName))
                                }catch let error as NSError{
                                    PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:" + error.localizedDescription)
                                    print(error)
                                }
                            }
                            if(finishedFlag == true){
                                //完了レポードアップロード成功、ファイル移動して結果jsonを削除
                                
                                PVDSwiftUtils.removeFinishedJson()
                                self.finishedList.waitingItems?.removeAll()
                                PVDSwiftUtils.moveuploadedFileToBackup(kFinishedFolderPath)
                            }else{//未完了アップロード
                                do{
                                    try FileManager.default.copyItem(atPath: (kUnfinishedFolderPath  + uploadTarget), toPath: (kbackupFolder + uploadTarget))
                                    
                                }catch let error as NSError {
                                    PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:" + error.description)
                                    print(error)
                                }
                                PVDSwiftUtils.removejsonFromList(false, tWorkPlanId: workid!)
                            }

                            DispatchQueue.main.async { [weak self]() -> Void in
                                if let selfWeak = self {
                                    selfWeak.getWaitingList()
                                }
                            }
                            PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:" + l007027)
                            DispatchQueue.main.async {
                                SVProgressHUD.showSuccess(withStatus: l007027)
                                self.uploadResultBtn.isEnabled = true
                            }
                        }else{
                            PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:" + l007028)

                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: l007028)
                                self.uploadResultBtn.isEnabled = true
                            }
                        }
                    }else{
                        PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:" + uxxx014)

                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: uxxx014)
                            self.uploadResultBtn.isEnabled = true
                        }
                        
                    }
                }
            case .failure(let encodingError):
                
                PVDSwiftUtils.writeAccessLog("<<未完了/完了アップロード>>:リクエスト失敗 error Code:" + encodingError.localizedDescription + "\n" + uxxx029)
                print(encodingError)

                DispatchQueue.main.async {
                    SVProgressHUD.showError(withStatus: uxxx029)
                }
            }
            
        }

        
        NSLog((UIDevice.current.identifierForVendor?.uuidString)!)
        
        
    }
    
    func pickerBtnAction(_ sender:UIButton){
        if(speakerPicker.isHidden == true){
            speakerPicker.isHidden = false
        }else{
            speakerPicker.isHidden = true
        }
        
        
    }
    
    @IBAction func singleTapGestureAction(_ sender: AnyObject) {
        self.view.endEditing(true)
        speakerPicker.isHidden = true
    }
    
    @IBAction func noiseAdjustmentAction(_ sender: UIButton) {
        let l007044 = String(format: NSLocalizedString("L007-044", comment: "enviroment.json not found"))
        let l007045 = String(format: NSLocalizedString("L007-045", comment: "enviroment.json parse json failed"))
        if(FileManager.default.fileExists(atPath: kpathForEnvironmentJson) == false){
            DispatchQueue.main.async(execute: { 
                SVProgressHUD.showError(withStatus: l007044)
            })
            return
        }
        let environmentDic:[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(kpathForEnvironmentJson)
        if(environmentDic == nil){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: l007045 + "1")
            })
            return
        }
        let eModel:PVDEnvironmentListModel? =  Mapper<PVDEnvironmentListModel>().map(JSON: environmentDic!)
        if(eModel == nil){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: l007045 + "2")
            })
            return
        }
        if((eModel?.items == nil)||(eModel?.items?.count == 0)){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: l007045 + "3")
            })
            return
        }
        
        gsettingModel.showingModelViewflag = true
        let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
        self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDNoiseAdjustController"), animated: true, completion: nil)
        
    }
    

    
    func getWaitingList(){
        
        let reportDic:[String:Any]? = PVDSwiftUtils.getDictionaryResourceFromPathS("/homejson/reportlist.json")
        let finishedDic:[String:Any]? = PVDSwiftUtils.getDictionarybyFullPathS(kfinishedJsonPath)
        var uploadedDic:[String:Any]? = nil
        
        if((reportDic == nil)||(reportDic?["list"] == nil)){
            print("report JSON解析失敗")
            self.reportList = nil
        }else{
            reportList = Mapper<PVDWaitingListModel>().map(JSON: reportDic!)
        }
        
        if((finishedDic == nil)||(finishedDic?["list"] == nil)){
            finishedList = nil
        }else{
            finishedList = Mapper<PVDWaitingListModel>().map(JSON: finishedDic!)
            finishedList.waitingItems = finishedList.waitingItems?.reversed()
        }

        unfinishedDataReload()
        
        let dataArray:NSMutableArray? = PVDDatabaseAccess.getUploadRecord()
        if(dataArray == nil){
            guploadedList = nil
        }else{
            uploadedDic = ["list":dataArray!]
            guploadedList = Mapper<PVDWaitingListModel>().map(JSON: uploadedDic!)
        }
        
          
            
        PVDSwiftUtils.dispatch_async_main({ () -> () in
            self.uploadedTbl.reloadData()
            self.waitingTbl.reloadData()
        })

        reloadunFinishedTbl()
        reloadFinishedTbl()
        
    }
    

    /**
     テーブル表示/隠し操作
     
     - parameter sender: <#sender description#>
     */
    func showTableAction(_ sender: UIButton) {
        if(sender == showFomartBtn){
            self.unfinishedTblHeight.constant = 0
            self.finishedTblHeight.constant = 0
            self.waitingTblHeight.constant = heightOfInViewTbl
            self.uploadedTblHeight.constant = 0
        }else if(sender == showUnfinishedBtn){
            self.unfinishedTblHeight.constant = heightOfInViewTbl
            self.finishedTblHeight.constant = 0
            self.waitingTblHeight.constant = 0
            self.uploadedTblHeight.constant = 0
        }else if(sender == showFinishedBtn){
            self.unfinishedTblHeight.constant = 0
            self.finishedTblHeight.constant = heightOfInViewTbl
            self.waitingTblHeight.constant = 0
            self.uploadedTblHeight.constant = 0
        }else if(sender == showUploadedBtn){
            self.unfinishedTblHeight.constant = 0
            self.finishedTblHeight.constant = 0
            self.waitingTblHeight.constant = 0
            self.uploadedTblHeight.constant = heightOfInViewTbl
        }
        self.updateViewConstraints()
    }
    
    func reloadHomeNOtificationAction(_ info:Notification){
        self.reloadHomeAction(false)
    }
    
    func startInspectionCBAction(_ info:Notification){
        switch gStartInspectionFlag!  {
        case .kChangingUser:
            DispatchQueue.main.async(execute: { () -> Void in
                self.waitingTbl.allowsSelection = true
                self.unfinishedTbl.allowsSelection = true
                self.finishedTbl.allowsSelection = true
                gStartInspectionFlag = .kDoNothing
            })
            break
        case .kDoNothing:
            
            break
            
        }
    }
    
    func reloadHomeAction(_ startRule:Bool){
        if(initFileCheck() == false){
            return //設定画面に行きました
        }
        if(gInspectInitResult != 0){
            let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
            let uxxx073 = String(format: NSLocalizedString("UXXX-073", comment: "title"))
            let uxxx074 = String(format: NSLocalizedString( "UXXX-074", comment: "再実行"))
           
            
            let uxxx072 = String(format: NSLocalizedString("UXXX-075", comment: "message"))
            let alert = UIAlertController(title: uxxx073, message: uxxx072, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler:nil))
            alert.addAction(UIAlertAction(title: uxxx074, style: UIAlertActionStyle.cancel, handler: { (UIAlertAction) -> Void in
                //engine restart
                gInspectInitResult =  (PSRManager.shareInstance() as AnyObject).voicedoInit(PVDSwiftUtils.getShareContainerDomainPath(),
                    iniUrl:  PVDSwiftUtils.getEngineSettingFilePath())
                PVDSwiftUtils.dispatchAfterMain(0.5, afterBlock: { (Void) in
                    let choosedSpeakerfullfilePath =  (NSHomeDirectory() as NSString).appendingPathComponent(gsettingModel.choosedSpeakerfilePath!)
                    //set user
                    gReportAndUserSetReuslt = (PSRManager.shareInstance() as AnyObject).voicedoChangeUserAndDic(false, speakerPath: choosedSpeakerfullfilePath, dicPath: NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFile),showMessage: false);
                })
                
                PVDSwiftUtils.dispatchAfterMain(0.75, afterBlock: { (Void) in
                    //set user
                    let ad001 = String(format: NSLocalizedString("AD001", comment: "ホームの認識"))
                    if(startRule == true){
                        _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
                    }
                })
                
                
                
                
            }))
            
            
            DispatchQueue.main.async(execute: { [weak self] in
                if let selfWeak = self {
                    selfWeak.present(alert, animated: true, completion: nil)
                }
            })
        
        }else if(gReportAndUserSetReuslt != 0){
            let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
            let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
            
            let uxxx001 = String(format: NSLocalizedString("UXXX-001", comment: "データダウンロード"))
            
            let l007036 = String(format: NSLocalizedString("L007-036", comment: "帳票データなどが存在しません。ダウンロード画面に遷移しますか?"))
            let alert = UIAlertController(title: uxxx001, message: l007036, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.cancel, handler:nil))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
                self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDSettingController"), animated: true, completion: nil)
            }))
            
            
            DispatchQueue.main.async(execute: { [weak self] in
                if let selfWeak = self {
                    selfWeak.present(alert, animated: true, completion: nil)
                }
            })
        }else{
            let ad001 = String(format: NSLocalizedString("AD001", comment: "ホームの認識"))
            if(startRule == true){
            _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
            }
        }
        
        
    }
    
    
    /**
     認識結果の通知受け取った操作
     
     - parameter notification: <#notification description#>
     */
    func receivedInpectionResultAction(_ notification:Notification){
        let userInfo:NSDictionary = notification.userInfo! as NSDictionary
        let result:NSString = PVDSwiftUtils.getSafeStringFromAnyObject(userInfo.object(forKey: kResultKey) as AnyObject) as NSString
        if(result.length > 0){
            NSLog("認識成功,result:%@",result)
            regonisationAction(result)
        }else{
            NSLog("認識失敗")
        }
    }
    
    
    
    func regonisationAction(_ result:NSString){

        let uxxx030 = String(format: NSLocalizedString("UXXX-030", comment: "イレギュラーな解析結果"))
        let l007037 = String(format: NSLocalizedString("L007-037", comment: "作業名"))
        let ad001 = String(format: NSLocalizedString("AD001", comment: "ホームの認識"))
        let resultArray = result.components(separatedBy: ",")
        if(resultArray.count <= 1){
            NSLog("ホーム認識エラー：イレギュラーな解析結果、分類不能:%@",resultArray)
            PSRManager.sendLogTextAsync([kLogViewKey:uxxx030])
            
            _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
            return
        }
        let resultType = resultArray[1]
        if(resultType == "作業名"){
            PSRManager.sendLogTextAsync([kLogViewKey:l007037])
            for tmpModel in reportList.waitingItems!{
                if(tmpModel.waitingTitle == (resultArray[0] as String)){
                        SpeechTalkManager.sharedInstance.speechTalkAndDoAction(tmpModel.waitingTitle!,forceCancelFlag: true, startBlock: nil, finishedBlock: { (synthesizer, utterance) -> () in
                            PVDSwiftUtils.dispatch_async_main({ () -> () in
                                NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpModel,kWorkPlanIdKey:PVDSwiftUtils.getNextWorkPlanId(),kInputJsonFileTypeKey:kPVDInputTypeNew])
                            })
                        })
                    break;
                    
                }
            }
        }else if(resultType == "ホーム制御語"){
            let command:String = resultArray[0] as String
            
            switch(command){
                case gcontrolBinds.wcontinue!:
                    //未完了再開コマンドの処理:時間が一番新しい「非引き継ぎ済み」レポートを再開する
                    let continueIndex = getunfinishedIndex()
                    
                    if(continueIndex == nil){
                        _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
                        return
                    }
                    let l007040 = String(format: NSLocalizedString("L007-040", comment: "old data"))
                    let tmpModel:PVDWaitingModel  = (self.munfinishedDisplayList.waitingItems?[continueIndex!])!
                    let dictionaryPath  =  NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + tmpModel.reportId! + ".mrg")
                    let reportPath      =  NSHomeDirectory().stringByAppendingPathComponent(kLibReportFolder + tmpModel.reportId! + ".json")
                    if((FileManager.default.fileExists(atPath: dictionaryPath) == false)||(FileManager.default.fileExists(atPath: reportPath) == false)){
                        PVDSwiftUtils.dispatch_async_main({ () -> () in
                            SVProgressHUD.showError(withStatus: l007040)
                        })
                        _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
                        return
                    }
                    SpeechTalkManager.sharedInstance.speechTalkAndDoAction(command,forceCancelFlag: true, startBlock: nil, finishedBlock: { (synthesizer, utterance) -> () in
                        PVDSwiftUtils.dispatch_async_main({ () -> () in
                            NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToInputNotification), object: nil, userInfo:  [kWaitingModelKey:  tmpModel,kWorkPlanIdKey:tmpModel.workplanid!,kInputJsonFileTypeKey:kPVDInputTypeUnfinished])
                        })
                    })
                    break
                case gcontrolBinds.wload!:
                    SpeechTalkManager.sharedInstance.speechTalkAndDoAction(command,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                        if let selfWeak = self {
                            selfWeak.unfinishedPullDownAction(false)
                            _ = selfWeak.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
                        }
                    })
                    
                    break
                default:
                    _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
                    break
            }
            
        }else{
            let ad001 = String(format: NSLocalizedString("AD001", comment: "ホームの認識"))
            NSLog(uxxx030 + resultType)
            PSRManager.sendLogTextAsync([kLogViewKey:uxxx030])
            _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
            
            return
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == kPushToSetting){
            let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
            self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDSettingController"), animated: true, completion: nil)
            
        }
    }
    
  
    
    
    //MARK:Specker picker method
    func getSpeakerList(){
        let userDic:NSDictionary? = PVDSwiftUtils.getDictionaryResourceFromPath("/homejson/speaker.json")
        if((userDic == nil)||(userDic?.object(forKey: "user") == nil)){
            print("JSON解析失敗")
            return
        }
        let useritemArray :NSArray = userDic?.object(forKey: "user") as! NSArray
        if(speakerList != nil){
            speakerList.removeAllObjects()
        }
        var speakerNotFoundFlag = false
        for tmpItem in useritemArray {
            if let dicItem = tmpItem as? NSDictionary{
                let newUserModel:PVDUserModel?  = PVDUserModel(namev: dicItem.object(forKey: "name") as AnyObject, userVoiceDataPathv: dicItem.object(forKey: "file") as AnyObject)
                
                if(newUserModel == nil){
                    NSLog("データ初期化失敗")
                    return
                }
                
                let fullPath:String = (NSHomeDirectory() as NSString).appendingPathComponent(kHomeSpeakerFolder + newUserModel!.userVoiceDataPath!)
                if(FileManager.default.fileExists(atPath: fullPath)){
                    speakerList?.add(newUserModel!)
                }else{
                    speakerNotFoundFlag = true
                    NSLog("jsonファイル指定の話者の中、話者ファイルが見つかりません:%@",fullPath)
                }
                
            }else{
                NSLog("処理ファイルフォーマット不正")
            }
            
        }
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if(speakerNotFoundFlag){
                NSLog("Error:見つかっていない話者があります")
            }
            if let selfWeak = self {
                selfWeak.speakerPicker.reloadAllComponents()
            }
        }
        
    }
    
    
    //MARK: pickerview delegate,datasource
    /**
    * ピッカーに表示する列数を返す
    */
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    /**
     * ピッカーに表示する行数を返す
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        if(self.speakerList != nil){
            return self.speakerList.count
        }else{
            return 0
        }
    }
    
    
    
    /**
     * 行のサイズを変更
     */
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat{
        return kScreenWidth
    }
    
    
    /**
     * ピッカーに表示する値を返す
     */
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        if(self.speakerList != nil){
            let tmpModel:PVDUserModel = speakerList.object(at: row) as! PVDUserModel
            return tmpModel.name
        }else{
            return nil
        }
        
    }
  
    
    /**
     * ピッカーの選択行が決まったとき
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
 
    }
    
    
    
    func tappedToSelectRow(_ tapRecognizer:UITapGestureRecognizer){
        let ad001 = String(format: NSLocalizedString("AD001", comment: "ホームの認識"))
        let uxxx052 = String(format: NSLocalizedString("UXXX-052", comment: "file not found"))
        let uxxx049 = String(format: NSLocalizedString("UXXX-049", comment: "ユーザー設定失敗しました"))

        
        if((speakerPicker == nil)||(speakerPicker?.selectedRow(inComponent: 0) == nil)){
            return
        }
        if(speakerList == nil){
            return
        }
        DispatchQueue.main.async(execute: { () -> Void in
            self.waitingTbl.allowsSelection = false
            self.unfinishedTbl.allowsSelection = false
            self.finishedTbl.allowsSelection = false

            gStartInspectionFlag = .kChangingUser
        })

        let row:Int =  (speakerPicker?.selectedRow(inComponent: 0))!
        
        let tmpModel:PVDUserModel = speakerList.object(at: row) as! PVDUserModel

        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.speakerPickerBtn.setTitle(tmpModel.name!, for: UIControlState())
            }
        }
        SVProgressHUD.showInfo(withStatus: "ユーザ変更中")
        NSLog("picked speacker:%@",tmpModel.name!)
        if(tmpModel.userVoiceDataPath != nil){
            let choosedSpeakerfullfilePath =  (NSHomeDirectory() as NSString).appendingPathComponent(gsettingModel.choosedSpeakerfilePath!)

            if(FileManager.default.fileExists(atPath: choosedSpeakerfullfilePath) == false){
                DispatchQueue.main.async(execute: { () -> Void in
                    SVProgressHUD.showError(withStatus: uxxx052)
                })
            }else{
                psrManager.voicedoStopInspection()
                let setuserRet = psrManager.voicedoSetUser(choosedSpeakerfullfilePath)
                if(setuserRet != 0){
                    DispatchQueue.main.async(execute: { () -> Void in
                        SVProgressHUD.showError(withStatus: uxxx049)
                    })
                }
                _ = self.psrManager.voicedoStartInspection(kHomeRule,detail:ad001)
            }
            SVProgressHUD.dismiss()
            //設定を保存
            gsettingModel.choosedSpeaker = tmpModel.name!
            gsettingModel.choosedSpeakerfilePath = kHomeSpeakerFolder + tmpModel.userVoiceDataPath!
            PVDSwiftUtils.saveSettingFile()
            self.reloadHomeAction(true)
        }else{
            NSLog("話者ファイル設定失敗")
        }
        gsettingModel.choosedSpeaker = tmpModel.name!
        speakerPicker.isHidden = true
        finishedTbl.allowsSelection = true
        unfinishedTbl.allowsSelection = true
        waitingTbl.allowsSelection = true
    }
    
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
