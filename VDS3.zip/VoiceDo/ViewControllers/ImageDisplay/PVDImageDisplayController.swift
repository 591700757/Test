//
//  PVDImageDisplayController.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/05.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import PhotosUI

class PVDImageDisplayController: UIViewController,UIScrollViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate {
    
    var albumName:String!
    
    var photolist:NSArray!
    
    @IBOutlet weak var imageDisplay: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        photolist = NSMutableArray()
        // Do any additional setup after loading the view.
        if(albumName != nil){
            PVDPhotoAlbumUtil.loadPhotoByAlbumName(albumName, completion: { (result, assetsArray) -> () in
                switch result {
                case .success:
                    print("read album success")
                    self.photolist = assetsArray
                    self.photolist = self.photolist.reversed() as NSArray
                    self.imageDisplay.reloadData()
                    break
                case .error:
                    print("read album ERROR")
                    break
                case .denied:
                    print("read album DENIED")
                    break
                }
            })
            imageDisplay.delegate = self
            imageDisplay.dataSource = self
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//SWIFT3_MIGRATION:未実装昨日につきSWIFT2.3->3.0移行対象外
//    override func layoutSublayersOfLayer(_ layer: CALayer) {
//        super.layoutSublayersOfLayer(layer)
//        
//        imageDisplay.contentSize = CGSize(width: kScreenWidth, height: kScreenHeight - 40)
//        
//    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }

    
    
    //MARK:CollectionView delegate datasource
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: IndexPath) -> CGSize {
        return CGSize(width: kScreenWidth, height: kScreenHeight - 40)
    }
   
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return photolist.count
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell:PVDImageDisplayCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: kImageDisplayCell, for: indexPath) as! PVDImageDisplayCollectionCell
        let albumImage:UIImage = photolist.object(at: indexPath.row) as! UIImage

        cell.contentImage.image = albumImage
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 0
    }
    
    
    //MARK: private method
    @IBAction func dismissAction(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)
        PVDSwiftUtils.dispatchAfterMain(0.5) { (Void) -> Void in
            NotificationCenter.default.post(name: Notification.Name(rawValue: kRootFinishedCameraNotification), object: nil, userInfo: nil)
        }
    }

}
