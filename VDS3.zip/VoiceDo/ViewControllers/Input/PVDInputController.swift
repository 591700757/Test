//
//  PVDInputController.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/11.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper
import SVProgressHUD
import Alamofire
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func <= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l <= r
  default:
    return !(rhs < lhs)
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func >= <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l >= r
  default:
    return !(lhs < rhs)
  }
}


class PVDInputController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,PVDProcessingCellDelegate,UIPickerViewDelegate,UIPickerViewDataSource,PVDProcessingFreeInputCellDelegate,UIGestureRecognizerDelegate{
    
    typealias afterSoundFinishedBlock = (_ userdata:NSDictionary)->()
    typealias AfterUploadBlock = () -> ()
    typealias UploadSuccessBlock = () -> ()
    typealias UploadFailureBlock = (_ message:String) -> ()
    typealias UploadRetryCancleBlock = () -> ()

    let kPickerHeight:CGFloat = 100
    let kPickerActualHeight:CGFloat = 162
    let psrManager: AnyObject! = PSRManager.shareInstance() as AnyObject
    let placeholderImg:UIImage!  = UIImage()
    var tinputAccessoryView:UIView!
    var cellfont:UIFont! = UIFont.systemFont(ofSize: 40)
    var smallfont:UIFont = UIFont.systemFont(ofSize: 16)
    var adjustHeight:CGFloat! = 0
    var pickerComponetHeight:CGFloat! = 0
    var processfile :NSString?
    var selectionPicker:UIPickerView?
    var tapToSelect:UITapGestureRecognizer!
    var selectionList:NSArray? = nil

    var dictionaryfile:NSString?
    var processDetail:PVDWaitingModel?
    var resultfile:String?
    var reportid:String?
    var workPlanId:String!
    var inputType:String!
    var mheightOfKeyBoard:CGFloat! = 0
    var evenCnt:Int!                    //一つのタイマー(0.5秒)で0.5秒毎に直接入力自動遷移チェック、1秒毎に時間textの変化
    var lasttextChangedTime:TimeInterval!    //直接入力自動遷移が0.x秒を超えたかとかを計算するためのtimeinterval
    var processlist:PVDProcessListModel?

    var resultlist:PVDReportResultModel?

    var processingIndex:Int!

    var processingFlag:Bool!        //認識結果待ちのフラグ        true:認識結果を待っている false:認識結果を待っていない
    var readFinishedSpeechFlag:Bool!    //終了のスピッチを読むフラグ
    var timerCounter:Timer!

    var reportStartTime:TimeInterval!
    var inspectionStartTime:TimeInterval!
    var inSubViewEventFlag:Bool!            //カメラ、QRscanを使うときに画面のViewXXXappear系ので認識初期化なとを呼ばないため
    var lastRuleBeforeTakePhoto:String!     //撮影前の認識ルール、状況復帰用
    var texthasBeenEditflag:Bool! = false   //テキスト変化のフラグ
    var directinputClearFlag:Bool! = false  //直接入力自動遷移の場合trueに設定して前回の値をクリアする
    var gsettingStatusView:PVDSettingStatusView!
    var mmoveflag:Bool!
    var mspeakOnOrderFree:Bool! = false    //順不同入力で項目を読み上げるフラグ  true:読み上げる   false:読み上げない

    @IBOutlet weak var timeCountLbl: UILabel!
    @IBOutlet weak var controllerTilte: UILabel!
    @IBOutlet weak var processingTbl: UITableView!
    @IBOutlet var tableTapGestur: UITapGestureRecognizer!
    @IBOutlet weak var cameraLbl: UILabel!
    @IBOutlet weak var cameraImage: UIImageView!
    @IBOutlet weak var cameraBtn: UIButton!
    
    
    @IBOutlet weak var prevlbl: UILabel!
    @IBOutlet weak var repeatlbl: UILabel!
    @IBOutlet weak var jumplbl: UILabel!
    @IBOutlet weak var stoplbl: UILabel!
    @IBOutlet weak var changelbl: UILabel!
    @IBOutlet weak var processAllFinishedBtn: UIButton!
    @IBOutlet weak var nextWorkPlanBtn: UIButton!
    

    
    // MARK: - life cycle
    init() {
        super.init(nibName: "PVDInputController", bundle: nil)
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)!
//        fatalError("init(coder:) has not been implemented")
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        tinputAccessoryView = UIView(frame: CGRect(x: 0,y: 0,width: kScreenWidth,height: 1))
        evenCnt = 0
        let l006001 = String(format: NSLocalizedString("L006-001", comment: "処理タイトル"))
        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = false
        self.edgesForExtendedLayout = UIRectEdge()
        self.title = l006001
        processingTbl.delegate = self
        processingTbl.dataSource = self
        processingTbl.separatorStyle = .none
        processingTbl.register(UINib(nibName: "PVDProcessingCell", bundle: nil), forCellReuseIdentifier: kCellIdentifier)
        tableTapGestur.cancelsTouchesInView = false
        inSubViewEventFlag = false
        self.view.addGestureRecognizer(tableTapGestur)
        mmoveflag = false
        
        selectionPicker = UIPickerView(frame: CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: kPickerHeight))
        selectionPicker!.isHidden = true
        selectionPicker!.backgroundColor = UIColor(red: 244.0/255.0, green: 244.0/255.0, blue: 244.0/255.0, alpha: 1.0)
        selectionPicker!.delegate = self
        selectionPicker!.dataSource = self

        tapToSelect = UITapGestureRecognizer(target: self, action: #selector(PVDInputController.tappedToSelectRow(_:)))
        tapToSelect.delegate = self

        selectionPicker!.addGestureRecognizer(tapToSelect)
        
        self.view.addSubview(selectionPicker!)

        processAllFinishedBtn.addTarget(self, action: #selector(PVDInputController.finishedButtonAction), for: UIControlEvents.touchUpInside)
        processAllFinishedBtn.layer.cornerRadius = 5
        nextWorkPlanBtn.addTarget(self, action: #selector(PVDInputController.startNextBtnAction), for: UIControlEvents.touchUpInside)
        nextWorkPlanBtn.layer.cornerRadius = 5
        self.changeButtonLayout(nextWorkPlanBtn, enable: false)
        self.changeButtonLayout(processAllFinishedBtn, enable: false)
        
        gsettingStatusView = PVDSettingStatusView.instance()
        gsettingStatusView.frame = CGRect(x: 5, y: 40, width: kScreenWidth - 10, height: kScreenHeight - 60)
        gsettingStatusView.closeBtn.addTarget(self, action: #selector(PVDInputController.closeSettingStatusView), for: .touchUpInside)
        gsettingStatusView.layoutIfNeeded()
        gsettingStatusView.prepareSettingView()
    }
    
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if(inSubViewEventFlag == true){//カメラ出し消しの場合通常初期化をしない
            return
        }
        if(gsettingModel.showingModelViewflag == true){
            return
        }
        DispatchQueue.main.async { () -> Void in
            SpeechTalkManager.sharedInstance.stopTalk(true)
        }

        processingTbl.tableFooterView = UIView()
        processingTbl.tableFooterView = UIView()

        processlist?.processitems?.removeAll()
        resultlist?.items?.removeAll()
        processlist = nil
        resultlist = nil
        _ = psrManager.voicedoCloseDic()
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kReceivedInpectionResultNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kRootFinishedCameraNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceDoQRCodeScanNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.AVAudioSessionInterruption, object: nil)
//        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kSiriStopFreeInputNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceDoStartNextInputNotification),object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UITextFieldTextDidBeginEditing, object: nil)
        timerCounter.invalidate()
        timerCounter = nil
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.reportStartTime = Date().timeIntervalSince1970
                selfWeak.timeCountLbl.text = ""
                selfWeak.processingTbl.reloadData()

            }
        }
        PVDDatabaseAccess.sharedInstance.updateTmpDumpToAudioDump { (result) in
            if(result == true){
                print("ダンプファイル保存成功")
            }else{
                print("ダンプファイル保存失敗")
            }
            
        }
        PVDDatabaseAccess.sharedInstance.updateDumpDuration()

        
    }
    
    
    deinit{
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if(gsettingModel.showingModelViewflag == true){
            return
        }
        if(inSubViewEventFlag == true){//カメラ出し消しの場合通常初期化をしない
//            inSubViewEventFlag = false
            return
        }else{
            //制御語を画面に反映
            prevlbl.text = gcontrolBinds.wprev
            repeatlbl.text = gcontrolBinds.wrepeat
            jumplbl.text = gcontrolBinds.wnext
            stoplbl.text = gcontrolBinds.wexit
            changelbl.text = gcontrolBinds.wchange
            processAllFinishedBtn.setTitle(gcontrolBinds.wbackhome, for: UIControlState())
            nextWorkPlanBtn.setTitle(gcontrolBinds.wagain, for: UIControlState())
            
            //change font size default heght
            if(gsettingModel.globalFontSize  != nil){
                cellfont =  UIFont.systemFont(ofSize: gsettingModel.globalFontSize!)
            }
            if(gsettingModel.globalDescriptionFontSize  != nil){
                smallfont =  UIFont.systemFont(ofSize: gsettingModel.globalDescriptionFontSize!)
            }
            let spaceString:String = "Adjust"
            let placeholderRect:CGRect = (spaceString as NSString).boundingRect(with: CGSize(width: kScreenWidth - 20, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: cellfont], context: nil)
            
            self.adjustHeight = placeholderRect.height
            
            processingIndex = 0
            let backUpdata =  reportid! + "," + workPlanId + "," + inputType
            PVDSwiftUtils.setKeyChainValueForKey(backUpdata, key: kreportResultDataBackupKey)
            
            if(processlist != nil){
                processlist = nil
            }
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.receivedInpectionResultAction(_:)), name: NSNotification.Name(rawValue: kReceivedInpectionResultNotification), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.cameraFinishedAction(_:)), name: NSNotification.Name(rawValue: kRootFinishedCameraNotification), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.doCommandReloadTable), name: NSNotification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.receivedScanAction(_:)), name: NSNotification.Name(rawValue: kVoiceDoQRCodeScanNotification), object: nil)
            
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.audioSessionInterrupted(_:)), name: NSNotification.Name.AVAudioSessionInterruption, object: nil)
//            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.stopfreeInputAction(_:)), name: NSNotification.Name(rawValue: kSiriStopFreeInputNotification), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.startNextNotificationAction(_:)), name: NSNotification.Name(rawValue: kVoiceDoStartNextInputNotification), object: nil)
            //show keyboard while using bluetooth scanner as input
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.textFieldBegan(_:)), name: NSNotification.Name.UITextFieldTextDidBeginEditing, object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(PVDInputController.keyboardShown(_:)), name: NSNotification.Name.UIKeyboardDidShow, object: nil)

            processingFlag = false
            readFinishedSpeechFlag = true
            
            //画面変えに辞書を切り替え、ユーザを設定する
            var setDicRet:Int32
            let choosedSpeakerfullfilePath =  (NSHomeDirectory() as NSString).appendingPathComponent(gsettingModel.choosedSpeakerfilePath!)
            setDicRet = psrManager.voicedoChangeUserAndDic(false, speakerPath: choosedSpeakerfullfilePath, dicPath: NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + (dictionaryfile! as String)), showMessage: false)
            if(setDicRet != 0){
                //エンジン再起動
                restartEngine()
            }
            
            //自動アップロードの修正
            if(kPVDInputTypeUploaded == self.inputType){
                let tpfileName = "/result_" + gsettingModel.deviceid! + "_" + workPlanId + ".json"
                let tpfinishedfilePath:String =  kFinishedFolderPath + tpfileName
                let tpunfinishedPath:String = kUnfinishedFolderPath + tpfileName
                if(FileManager.default.fileExists(atPath: tpfinishedfilePath) == true){
                    try! FileManager.default.removeItem(atPath: tpfinishedfilePath)
                }
                
                if(FileManager.default.fileExists(atPath: tpunfinishedPath) == true){
                    try! FileManager.default.removeItem(atPath: tpunfinishedPath)
                }
            }

         
            inputCustomize()
            
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if(gsettingModel.showingModelViewflag == true){
            gsettingModel.showingModelViewflag = false
            return
        }
        UIApplication.shared.isIdleTimerDisabled = true
        if(inSubViewEventFlag == true){//カメラ出し消しの場合通常初期化をしない
            return
        }else{
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    //処理内容をファイルから取得
                    selfWeak.getProcessList()
                    selfWeak.processingTbl.reloadData()
                    let tmpIndex:IndexPath!
                    if((selfWeak.processingIndex == selfWeak.processlist?.processitems?.count)||((gsettingModel.inputScrolToTopFlag == true)&&(selfWeak.processingIndex > 0))){
                        tmpIndex = IndexPath(row: selfWeak.processingIndex - 1, section: 0)
                        
                    }else{
                        tmpIndex = IndexPath(row: selfWeak.processingIndex, section: 0)
                    }
                    if(selfWeak.processingTbl.numberOfRows(inSection: 0) > tmpIndex.row){
                        selfWeak.processingTbl.scrollToRow(at: tmpIndex, at: UITableViewScrollPosition.top, animated: true)
                    }else{
                        NSLog("row:%d,index:%d", selfWeak.processingTbl.numberOfRows(inSection: 0),tmpIndex.row)
                    }
                }
            })
        
        }
        
    }
    
    
    // MARK: - tableview delegate and datasource
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{

        if(processlist?.processitems != nil){
            return (processlist?.processitems?.count)!
        }else{
            return 0
        }
        
    }
    
    func restartEngine(){
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx073 = String(format: NSLocalizedString("UXXX-073", comment: "title"))
        let uxxx074 = String(format: NSLocalizedString( "UXXX-074", comment: "再実行"))
        
        
        let uxxx072 = String(format: NSLocalizedString("UXXX-075", comment: "message"))
        let alert = UIAlertController(title: uxxx073, message: uxxx072, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler:nil))
        alert.addAction(UIAlertAction(title: uxxx074, style: UIAlertActionStyle.cancel, handler: { (UIAlertAction) -> Void in
            //engine restart
            gInspectInitResult =  (PSRManager.shareInstance() as AnyObject).voicedoInit(PVDSwiftUtils.getShareContainerDomainPath(),
                iniUrl:  PVDSwiftUtils.getEngineSettingFilePath())
            PVDSwiftUtils.dispatchAfterMain(0.5, afterBlock: { (Void) in
                let choosedSpeakerfullfilePath =  (NSHomeDirectory() as NSString).appendingPathComponent(gsettingModel.choosedSpeakerfilePath!)
                //set user
                gReportAndUserSetReuslt = (PSRManager.shareInstance() as AnyObject).voicedoChangeUserAndDic(false, speakerPath: choosedSpeakerfullfilePath, dicPath: NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFolder + (self.dictionaryfile! as String)),showMessage: false);
            })
            if((self.inSubViewEventFlag == false)&&(gsettingModel.showingModelViewflag == false)){//sub view mode not refresh table
                PVDSwiftUtils.dispatchAfterMain(0.75, afterBlock: { (Void) in
                    //restart rule
                    
                    self.reloadTableAndScroll()
                })
                
            }
        }))
        
        
        DispatchQueue.main.async(execute: { [weak self] in
            if let selfWeak = self {
                selfWeak.present(alert, animated: true, completion: nil)
            }
        })
    }
    
    func getHeightOfCell(_ processModel:PVDProcessItemModel?,indexPath: IndexPath,freeinputflag:Bool)-> CGFloat{
        //|--topMargin(15)--titleLbl(>=30)--gap(5)--inputFiled(>=30)--gap(5)--description(>=0)--(bottomMargin)
        let topMargin:CGFloat = 5
        let bottomMargin:CGFloat = 5
        let gap:CGFloat = 10
        var heightOfLabel:CGFloat = 0
        var heightOfField:CGFloat = 0
        var heightOfDescription:CGFloat = 0
        var heightOfmaxminLbl:CGFloat = 0
        let tmpreportModel = processlist?.processitems![indexPath.row]
        let tmpModel = resultlist?.items?[indexPath.row]
        
        if((tmpreportModel?.min_val != nil)||(tmpreportModel?.max_val != nil)){
            heightOfmaxminLbl = 15
        }
        
        if((processModel == nil)||(processModel!.itemname == nil)){
            NSLog("nil model in %s,%s",#function,#file)
            return 50
        }
        //labelの高さ
        let labelRect:CGRect = (processModel!.itemname! as NSString).boundingRect(with: CGSize(width: kScreenWidth - 50, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: cellfont], context: nil)
        heightOfLabel = labelRect.height
        
        //descriptionの高さ
        if(processModel?.supplementary_guide != nil){
            let descriptionRect:CGRect = (processModel!.supplementary_guide! as NSString).boundingRect(with: CGSize(width: kScreenWidth - 20, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName: smallfont], context: nil)
            heightOfDescription = descriptionRect.height
        }
        
        
        //textfiledの高さ
        if(tmpModel?.result?.value == nil){
            //認識結果が入力してない場合
            if(freeinputflag == true){//自由文セールの高さ
                heightOfField = self.adjustHeight * 4
            }else{
                heightOfField = self.adjustHeight
            }

        }else{
            //認識結果が入力してある場合
            let resultRect = ((tmpModel?.result?.value!)! as NSString).boundingRect(with: CGSize(width: kScreenWidth - 20, height: CGFloat(MAXFLOAT)), options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSFontAttributeName:cellfont], context: nil)
            if(freeinputflag == true){//自由文セールの高さ
                heightOfField = resultRect.height
                if(heightOfField < self.adjustHeight * 4){
                    heightOfField = self.adjustHeight * 4
                }
            }else{
                //2016.05.09 chou修正:文字が入るとセールが高くなるので文字の長さで高度を計算しないようにする
                heightOfField = self.adjustHeight
            }
        }
        //最低限の高さへの補正
        if(heightOfField < 30){
            heightOfField = 30
        }
        
        if(heightOfLabel < 30){
            heightOfLabel = 30
        }
        
        if(indexPath.row == processingIndex){
            return topMargin + heightOfLabel + gap + heightOfField  + gap + bottomMargin + heightOfDescription + heightOfmaxminLbl
        }else{
            return topMargin + heightOfLabel + gap + heightOfField + gap + bottomMargin + heightOfmaxminLbl
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       let tmpModel = processlist?.processitems?[indexPath.row]
        var heightOfCell:CGFloat = 30
        
        
        if((processlist == nil)||(processlist?.processitems == nil)){
            return heightOfCell
        }else{
            if(tmpModel?.itemType == PVDInputType.kFreeInput.rawValue){
                heightOfCell =  getHeightOfCell(tmpModel,indexPath: indexPath,freeinputflag: true)
            }else{
                let tmpModel = processlist?.processitems?[indexPath.row]
                heightOfCell =  getHeightOfCell(tmpModel,indexPath: indexPath,freeinputflag: false)
            }
            
        }
        if((tmpModel?.descriptionImgPath != nil)&&(processingIndex == indexPath.row)&&(tmpModel?.heightOfDiscriptionImage != nil)){
            heightOfCell = heightOfCell + (tmpModel?.heightOfDiscriptionImage)!
        }
        
        return heightOfCell + adjustHeight/2
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        tableView.deselectRow(at: indexPath, animated: false)
        if(PVDSwiftUtils.buildInSpeekerLimit() == true){
            return ;
        }
        
        self.selectTableviewAction(indexPath)

        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{

        let tmpModel = processlist?.processitems?[indexPath.row]
        
        if(tmpModel?.itemType == PVDInputType.kFreeInput.rawValue){
            return reloadFreeInputCell(indexPath, tableView: tableView)
        
        }else{
            return reloadProcessingCell(indexPath, tableView: tableView)
        }
        
    }
    
    //MARK:入順不同処理
    /**
     キーワードが引っかかる項目のindexを返す
     
     - parameter keyWord: キーワード
     
     - returns: -1:異常、見つからない場合  -1以外:引っかかる項目のindex
     */
    func getIndexOfKeyword(_ keyWord:String)->Int{
        if((processlist == nil)||(processlist?.processitems == nil)){
            return -1
        }
        let index =  processlist?.processitems?.index(where: {$0.voiced_name == keyWord})

    
        if(index == nil){
            return -1
        }else{
            return index!
        }
    }
    
    
    /**
     項目のキーワードを取得する
     
     - parameter index: 項目のindex
     
     - returns: 1.nil:取得失敗   2.文字列:キーワード
     */
    func getKeywordByIndex(_ index:Int)->String?{
        if((processlist == nil)||(processlist?.processitems == nil)||(index > (processlist?.processitems?.count)! - 1)){
            return nil
        }
        let keyword = processlist?.processitems![index].voiced_name
        
        return keyword
    }
    
    /**
     全ての項目の入力が完了しているのかをチェック
     
     - returns: 1.一番先頭の未入力項目のindex  2.-1:結果リストがnil 3.-2:全部完了
     */
    func finishedCheck()->Int{
        if((resultlist == nil)||(resultlist?.items == nil)){
            return -1
        }
        var index:Int = 0
        for item in (resultlist?.items)!{
            if((item.result?.value == nil)||(item.result?.value == "")){
                return index
            }
            index = index + 1
        }
        return -2
    }
    
    
    //    1.最後行での未完了チェック
    //    　　　　必須のみチェック○
    //    　　　　非必須も入力させる
    //
    //    2.最初のデータロード時(アップロード済み以外の場合)未完了の行へ
    //    　　　　必須のみチェック
    //    　　　　非必須も入力させる○
    //
    //
    //    3.入力完了
    //    　　　　必須のみチェック○
    //    　　　　非必須も入力させる
    //
    //
    //    4.index+
    //    A>認識結果更新して、結果を発話後次の行へ
    //    　　　　必須のみチェック
    //    　　　　非必須も入力させる○
    //
    //    B>次へ進む
    //    　　　　必須のみチェック
    //    　　　　非必須も入力させる○
    //
    //    C>条件分岐に満足しないなと
    //    　　　　必須のみチェック
    //    　　　　非必須も入力させる○
    //    
    //    D>手入力完了時
    //    　　　　必須のみチェック
    //    　　　　非必須も入力させる○
    /**
     全ての項目の入力が完了しているのかをチェック、条件分岐で満足しない項目を入力済みとして処理
     - checkflag: true:必須のみチェック    false:非必須も入力させる
     - returns: 1.一番先頭の未入力項目のindex  2.-1:結果リストがnil 3.-2:全部完了
     */
    func finishedCheckWithCondition(checkflag:Bool)->Int{
        if((resultlist == nil)||(resultlist?.items == nil)){
            return -1
        }
        var index:Int = 0
        for item in (resultlist?.items)!{
            if((item.result?.value == nil)||(item.result?.value == "")){
                if(checkflag == false){
                    return index
                }
                let conditionflag = checkConditions(index)
                let optionalflag = checkOption(index)
                //分岐条件に満足　かつ　必須の入力項目の場合 indexを返すs
                
                if((conditionflag == true)&&(optionalflag == false)){
                    return index
                }
            }
            index = index + 1
        }
        return -2
    }
    

    /**
     未完了合成音を発話させて遷移
     
     - parameter unfinshedIndex: 未完了index
     */
    func jumptoUnfinshedAction(_ unfinshedIndex:Int){
        var keyword = getKeywordByIndex(unfinshedIndex)
        if(keyword == nil){
            keyword = ""
        }
        let unfinishedSpeach = keyword! + "未入力"

        self.processingIndex = unfinshedIndex
        SpeechTalkManager.sharedInstance.speechTalkAndDoAction(unfinishedSpeach,forceCancelFlag: false, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
            if let selfWeak = self {
//                selfWeak.processingTbl.reloadData()
                selfWeak.scrollAndReloadTable()
            }
         })
    
    }
    
    
    

    /**
     <#Description#>
     
     - parameter targetIndex:
     
     - returns: true:必須じゃない入力項目　　　false:必須の入力項目
     */
    func checkOption(_ targetIndex:Int)->Bool{
        if((resultlist == nil)||(processlist == nil)){
            return true
        }
        if(targetIndex > (resultlist?.items?.count)! - 1){
            return true
        }
        if(targetIndex > processlist?.processitems?.count){
            return true
        }
        
        let tmpResultModel = resultlist?.items?[targetIndex]
        let tmpModel:PVDProcessItemModel = (processlist?.processitems?[targetIndex])!
//        //result未記入+(必須/flag未設定/ID) "false"  == nil
        if((tmpResultModel?.result?.value == "")&&((tmpModel.optional_flag == "false")||(tmpModel.optional_flag == nil)||tmpModel.optional_flag == "ID")){
            return false//必須
        }else{
            return true
        }
    }
    

    /**
       条件分岐の条件に満足しているかをチェック、順不同入力用条件式に
     
     - parameter targetIndex: 対象のindex
     
     - returns: 1.true:条件に満足している/若しくは条件分岐がない→必ず入力させる      2.false:条件を満足しない→飛ばすことが可能
     */
    func checkConditions(_ targetIndex:Int)->Bool{
        if((processlist?.processitems == nil)||(targetIndex > (processlist?.processitems?.count)! - 1)){
            return true
        }
        //条件分岐の処理
        let tmpModel = processlist?.processitems?[targetIndex]
        if((tmpModel?.condition == nil)||(tmpModel?.condition![0].expression == nil)){//条件分岐がない
            return true
        }
        var targetItem:PVDProcessItemModel? = nil
        var targetIndex:Int = 0
        var index = 0
        for tit in (processlist?.processitems)!{
            if(tit.itemid == tmpModel?.condition![0].itemid){
                targetItem = tit
                targetIndex = index
                break
            }
            index = index + 1
        }
        //条件がない場合はtrueを返す
        if(targetItem == nil){
            return true
        }
        
        let resModel = self.resultlist?.items?[targetIndex]
        if((resModel?.result?.value == nil)||(resModel?.result?.value == "")){
            
            return false
        }
        let (evaret,comment) = PVDSwiftUtils.evaluateCondition((targetItem?.itemid)!, target_val: (resModel?.result?.value)!, expression: (tmpModel?.condition![0].expression)!)
        print(comment)
        if(evaret == false){//条件を満足しない場合indexを飛ばす
            return false
        }else{
            return true
        }
        

    }
    
    
    func scrollAndReloadTable(){
        
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.view.endEditing(true)
                let tmpIndex:IndexPath!
                if((gsettingModel.inputScrolToTopFlag == false)||(selfWeak.processingIndex  < 1)){
                    tmpIndex = IndexPath(row: selfWeak.processingIndex, section: 0)
                    
                }else{
                    tmpIndex = IndexPath(row: selfWeak.processingIndex - 1, section: 0)
                    
                }
                print(tmpIndex.row)
                //画像でのスクーロル対応で二回りロード、一回目は画像が表示されるセルの高さがかわる、二回目は変わった高さで指定の位置にスクロールする
                selfWeak.processingTbl.reloadData()
                selfWeak.processingTbl.layoutIfNeeded()
                if(selfWeak.processingIndex <= selfWeak.processlist?.processitems?.count){
                    selfWeak.processingTbl.scrollToRow(at: tmpIndex, at: UITableViewScrollPosition.top, animated: true)
                }
                
            }
        }
    }
    
    
    //MARK:Private
    
    func autoUploadResultAction(_ uploadTarget:String,successBlock:UploadSuccessBlock?,retryCancel:UploadRetryCancleBlock?){
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx029 = String(format: NSLocalizedString("UXXX-029", comment: "異常のレスボンス"))
        let l007023 = String(format: NSLocalizedString("L007-023", comment: "アカウントが設定されていません"))
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let l007024 = String(format: NSLocalizedString("L007-024", comment: "結果ファイルの圧縮に失敗"))
        let uxxx014 = String(format: NSLocalizedString("UXXX-014", comment: "レスボンスエラー"))
        let l007026 = String(format: NSLocalizedString("L007-026", comment: "結果アップロード中です"))
        let l007027 = String(format: NSLocalizedString("L007-027", comment: "結果アップロード成功"))
        let l007028 = String(format: NSLocalizedString("L007-028", comment: "結果アップロード失敗"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx076 = String(format: NSLocalizedString("UXXX-076", comment: "はい"))
        
        let retryBlock:UploadFailureBlock = { (message) in
            let alert = UIAlertController(title: uxxx020, message: message, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
                if(retryCancel != nil){
                    retryCancel!()
                }
            }))
            alert.addAction(UIAlertAction(title: uxxx076, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.autoUploadResultAction(uploadTarget,successBlock: successBlock,retryCancel:retryCancel)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
        }
        
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            retryBlock(uxxx021)
            
            return
        }
        
        
        
        if(gsettingModel.tokenString == nil){
            
            retryBlock(uxxx006)
            return
        }
        if(FileManager.default.fileExists(atPath: kresultZipFileName) == true){
            try! FileManager.default.removeItem(atPath: kresultZipFileName)
        }
        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            try! FileManager.default.createDirectory(atPath: kbackupFolder, withIntermediateDirectories: true, attributes: nil);
        }
        
        if(gsettingModel.userid == nil){
            
            retryBlock(l007023)
            return
        }
        print(uploadTarget)
        if(FileManager.default.fileExists(atPath: uploadTarget) == true){
            print("funk")
        }
        
        
        let zipFlag:Bool = ZipArchiveManager.createZipFile(atPath: kresultZipFileName, withContentsOfDirectory: uploadTarget, keepParentDirectory: true)
        
        if(zipFlag == false){
            
            retryBlock(l007024)
            return
        }
        let tokenString =   gsettingModel.tokenString!
        
        let uploadUrl = kresultUploadURL + "&token=" + psrManager.getMD5(by: tokenString)
        SVProgressHUD.show(withStatus: l007026)
        
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>自動アップロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + uploadUrl)
        
        let fileURL = URL(fileURLWithPath: (kresultZipFileName))
        alamofireManager.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(fileURL, withName: "result")
        }, to: uploadUrl) { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.responseJSON { response in
                    PVDSwiftUtils.writeAccessLog("<<自動アップロード>>:リクエスト成功")
                    debugPrint(response)
                    if(response.result.value != nil){
                        let retDic:NSDictionary = response.result.value as! NSDictionary
                        let retValue = retDic.object(forKey: "result") as? NSNumber

                        if(retValue! == 0){//リスボンス取得成功、アップロード結果:成功
                            if(FileManager.default.fileExists(atPath: kresultZipFileName)){
                                try! FileManager.default.removeItem(at: URL(fileURLWithPath: kresultZipFileName))

                            }
                            PVDSwiftUtils.removeFinishedJson()
                            PVDSwiftUtils.moveuploadedFileToBackup(kFinishedFolderPath)
                            PVDSwiftUtils.writeAccessLog("<<自動アップロード>>:" + l007027)
                            DispatchQueue.main.async {
                                SVProgressHUD.showSuccess(withStatus: l007027)
                            }
                            //次の作業開始/ホームに戻る/中断する
                            if(successBlock != nil){
                                successBlock!()
                            }
                        }else{
                            PVDSwiftUtils.writeAccessLog("<<自動アップロード>>:" + l007028)
                            SVProgressHUD.dismiss()
                            retryBlock(l007028)
                        }
                    }else{
                        PVDSwiftUtils.writeAccessLog("<<自動アップロード>>:" + uxxx014)
                        SVProgressHUD.dismiss()
                        retryBlock(uxxx014)
                        
                    }
                }
            case .failure(let encodingError):
                PVDSwiftUtils.writeAccessLog("<<自動アップロード>>:リクエスト失敗 error Code:" + encodingError.localizedDescription + "\n" + uxxx029)
                SVProgressHUD.dismiss()
                retryBlock(uxxx029)
            }

            
        }

        
        NSLog((UIDevice.current.identifierForVendor?.uuidString)!)
        
        
    }
    
    /**
     アップロード済の更新
     
     - parameter uploadTarget: アップロードの対象(result json file)
     - parameter successBlock: 成功した後の動き
     - parameter retryCancel:  リトライを諦めた後の動き
     */
    func updateResultAction(_ uploadTarget:String,successBlock:UploadSuccessBlock?,retryCancel:UploadRetryCancleBlock?){
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx029 = String(format: NSLocalizedString("UXXX-029", comment: "異常のレスボンス"))
        let l007023 = String(format: NSLocalizedString("L007-023", comment: "アカウントが設定されていません"))
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        let uxxx014 = String(format: NSLocalizedString("UXXX-014", comment: "レスボンスエラー"))
        let l007026 = String(format: NSLocalizedString("L007-026", comment: "結果アップロード中です"))
        let l007027 = String(format: NSLocalizedString("L007-027", comment: "結果アップロード成功"))
        let l007028 = String(format: NSLocalizedString("L007-028", comment: "結果アップロード失敗"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        
        let retryBlock:UploadFailureBlock = { (message) in
            let alert = UIAlertController(title: uxxx020, message: message, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
                if(retryCancel != nil){
                    retryCancel!()
                }
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.updateResultAction(uploadTarget,successBlock: successBlock,retryCancel:retryCancel)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
        }
        
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            retryBlock(uxxx021)
         
            return
        }

        
        
        if(gsettingModel.tokenString == nil){

            retryBlock(uxxx006)
            return
        }
        if(FileManager.default.fileExists(atPath: kresultZipFileName) == true){
            try! FileManager.default.removeItem(atPath: kresultZipFileName)
        }
        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            try! FileManager.default.createDirectory(atPath: kbackupFolder, withIntermediateDirectories: true, attributes: nil);
        }
        
        if(gsettingModel.userid == nil){

            retryBlock(l007023)
            return
        }
        print(uploadTarget)
        if(FileManager.default.fileExists(atPath: uploadTarget) == true){
            print("funk")
        }
        

        let tokenString =   gsettingModel.tokenString!
        
        let uploadUrl = kupdateResultURL + "&token=" + psrManager.getMD5(by: tokenString)
        SVProgressHUD.show(withStatus: l007026)
        
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>アップロード済の更新>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + uploadUrl)
        
        let fileURL = URL(fileURLWithPath: (uploadTarget))
        alamofireManager.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(fileURL, withName: "result")
        }, to: uploadUrl) { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.responseJSON { response in
                    PVDSwiftUtils.writeAccessLog("<<アップロード済の更新>>:リクエスト成功")
                    debugPrint(response)
                    if(response.result.value != nil){
                        let retDic:NSDictionary = response.result.value as! NSDictionary
                        let retValue = retDic.object(forKey: "result") as? NSNumber
                        if(retValue! == 0){//リスボンス取得成功、アップロード結果:成功
                            PVDSwiftUtils.writeAccessLog("<<アップロード済の更新>>:" + l007027)
                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: l007027)
                            }
                            //次の作業開始/ホームに戻る/中断する
                            if(successBlock != nil){
                                successBlock!()
                            }
                        }else{
                            PVDSwiftUtils.writeAccessLog("<<アップロード済の更新>>:" + l007028)
                            SVProgressHUD.dismiss()
                            retryBlock(l007028)
                        }
                    }else{
                        PVDSwiftUtils.writeAccessLog("<<アップロード済の更新>>:" + uxxx014)
                        SVProgressHUD.dismiss()
                        retryBlock(uxxx014)
                        
                    }
                }
            case .failure(let encodingError):
                PVDSwiftUtils.writeAccessLog("<<アップロード済の更新>>:リクエスト失敗 error Code:" + encodingError.localizedDescription + "\n" + uxxx029)
                SVProgressHUD.dismiss()
                retryBlock(uxxx029)
            }

            
            
            
        }


        
        
        

    }

    @IBAction func openSettingStatus(_ sender: AnyObject) {

        (UIApplication.shared.delegate as! AppDelegate).window?.addSubview(gsettingStatusView)
        gsettingStatusView.layer.cornerRadius = 5
        gsettingStatusView.clipsToBounds = true
        gsettingStatusView.layoutSubviews()
        gsettingStatusView.statuslist = PVDSwiftUtils.sharedInstance.getSettingStatus()
        gsettingStatusView.reloadSettingStatusTbl()

        
    }
    
    func closeSettingStatusView(){
        gsettingStatusView.removeFromSuperview()
    }
    
    func selectTableviewAction(_ indexPath:IndexPath){
        
        SpeechTalkManager.sharedInstance._afterSpeechBlock = nil
        var siriCellReclicked:Bool = false
        SpeechTalkManager.sharedInstance.stopTalk(true)
        var tmpModel:PVDProcessItemModel! = processlist?.processitems?[indexPath.row]
        self.updateResultListEndTime(processingIndex, saveresultFlag: true)
        
        if((processingIndex == indexPath.row)&&(tmpModel.itemType == PVDInputType.kFreeInput.rawValue)){
            siriCellReclicked = true
        }
        processingIndex = indexPath.row
        self.updateResultListStartTime(processingIndex)
        processingFlag = false//認識フラグ外す
        tmpModel = processlist?.processitems?[processingIndex]
        tmpModel?.clickFlag = true
        if(siriCellReclicked == true){
            //siri 認識中を再度クリック、siri認識止まらず、キーボードを出す
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    if(tmpModel?.itemType == PVDInputType.kFreeInput.rawValue){
                        let cell = selfWeak.processingTbl.cellForRow(at: indexPath) as! PVDProcesssingFreeInputCell
                        cell.inputFld.becomeFirstResponder()
                    }
                }
            })
        }else{
            //テーブルリーロド処理
//            DictationHelper.sharedInstance().stopDictationWithFallbackIFNeeded()
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    selfWeak.processingTbl.reloadData()
                    if(tmpModel?.itemType == PVDInputType.kFreeInput.rawValue){
                        let cell = selfWeak.processingTbl.cellForRow(at: indexPath) as! PVDProcesssingFreeInputCell
                        cell.inputFld.becomeFirstResponder()
                    }
                }
            })
        }
    }
    
    
    func reloadFreeInputCell(_ indexPath:IndexPath,tableView:UITableView)->PVDProcesssingFreeInputCell{
        let cell: PVDProcesssingFreeInputCell? = tableView.dequeueReusableCell(withIdentifier: kPVDProcessingFreeInputCellID, for: indexPath) as? PVDProcesssingFreeInputCell
        let tmpModel = processlist?.processitems?[indexPath.row]
        let tmpreulstModel = resultlist?.items?[indexPath.row]
        cell!.delegate = self
        cell!.titleLbl.text = tmpModel?.itemname
        cell!.descriptionLbl.text = tmpModel?.supplementary_guide
        cell!.photoBtn.addTarget(self, action: #selector(PVDInputController.showPhotoAction(_:)), for: UIControlEvents.touchUpInside)

        cell!.inputFld.font = cellfont
        cell!.titleLbl.font = cellfont
        
        
            //認識内容を反映
            
            if((tmpModel != nil)&&(tmpreulstModel?.result?.value != nil)){
                PVDSwiftUtils.dispatch_async_main({ () -> () in
                    let inspectionTmp:String = (tmpreulstModel?.result?.value)!
                    cell!.inputFld.text = inspectionTmp
                })
                
            }else{
                cell!.inputFld.text = ""
            }
            if(processingIndex == indexPath.row){
                cell!.backgroundColor = UIColor(red: 247/255.0, green: 185/255.0, blue: 119/255.0, alpha: 1)
                cell!.titleBImage.backgroundColor = UIColor.orange
                cell!.descriptionLbl.font = smallfont
                
                cell!.descriptionLbl.isHidden = false
                cell!.descriptionLbl.lineBreakMode = .byWordWrapping
                cell!.descriptionLbl.numberOfLines = 0
                cell!.descriptionLbl.sizeToFit()
                //認識結果待ちじゃない時、認識再開
                if(processingFlag == false){
                    //次の課目へスクロール
                    PVDSwiftUtils.dispatch_async_main({ () -> () in
                        let tmpIndex:IndexPath!
                        if(indexPath.row - 1 > 0){
                            tmpIndex = IndexPath(row: indexPath.row - 1, section: 0)
                            tableView.scrollToRow(at: tmpIndex, at: UITableViewScrollPosition.top, animated: true)
                        }
                        
                    })
                    startSiriProcessing()
                }
                
                
            }else{
                //
                cell!.descriptionLbl.font =  smallfont
                cell!.descriptionLbl.numberOfLines = 1
                cell!.descriptionLbl.sizeToFit()
                cell!.descriptionLbl.isHidden = true
                cell!.backgroundColor = UIColor.white
                cell!.titleBImage.backgroundColor = UIColor(red: 250/255.0, green: 247/255.0, blue: 237/255.0, alpha: 1)
                
            }
            
            
            //検査終了のチェック
            self.updateReportControlArea(indexPath)
        
        return cell!
    }
    
    

    
    
    /**
    VoiceDoエンジンで認識処理を行うCellを用意する
    
    - parameter indexPath: cellForRowAtIndexPathの indexPath
    - parameter tableView: 認識処理のテーブル
    
    - returns: VoiceDoエンジンで認識処理を行うCell
    */
    func reloadProcessingCell(_ indexPath:IndexPath,tableView:UITableView)->PVDProcessingCell{
        let cell: PVDProcessingCell? = tableView.dequeueReusableCell(withIdentifier: kPVDProcessingCell, for: indexPath) as? PVDProcessingCell
        let tmpModel = processlist?.processitems?[indexPath.row]
        let tmpreulstModel = resultlist?.items?[indexPath.row]
        
        cell!.titleLbl.text = tmpModel?.itemname
        var maxValue:String = ""
        var minValue:String = ""
        //単位と範囲
        if(tmpModel?.max_val != nil){
            maxValue = (tmpModel?.max_val)!
        }
        if(tmpModel?.min_val != nil){
            minValue = (tmpModel?.min_val)!
        }
        if(tmpModel?.unit != nil){
            cell!.unitLbl.text = tmpModel?.unit
        }else{
            cell?.unitLbl.text = ""
        }
        if((tmpModel?.unit == nil) && (tmpModel?.max_val == nil) && (tmpModel?.min_val == nil)){
            cell!.widthOfUnitlbl.constant = 0
            cell?.inputFld.textAlignment = .left
        }else{
            cell!.widthOfUnitlbl.constant = 60
            cell?.inputFld.textAlignment = .right
        }
        if((tmpModel?.min_val == nil)&&(tmpModel?.max_val == nil)){
            cell?.heightOfmaxminlbl.constant = 0
        }else{
            cell?.heightOfmaxminlbl.constant = 15
        }
        
        
        cell!.maxminlbl.text = minValue + "~" + maxValue
        cell!.delegate = self
        cell!.descriptionLbl.text = tmpModel?.supplementary_guide
        cell!.photoBtn.addTarget(self, action: #selector(PVDInputController.showPhotoAction(_:)), for: UIControlEvents.touchUpInside)
        cell!.inputFld.isEnabled = false
        cell!.inputFld.font = cellfont
        
        
        //認識内容を反映
        
        if((tmpModel != nil)&&(tmpreulstModel?.result?.value != nil)){
            PVDSwiftUtils.dispatch_async_main({ () -> () in
                let inspectionTmp:String = (tmpreulstModel?.result?.value)!
                cell!.inputFld.text = inspectionTmp
            })
            
        }else{
            cell!.inputFld.text = ""
        }
        cell?.descriptionImg.isHidden = true
        if(processingIndex == indexPath.row){
            cell!.backgroundColor = UIColor(red: 247/255.0, green: 185/255.0, blue: 119/255.0, alpha: 1)
            cell!.titleBImage.backgroundColor = UIColor.orange
            cell!.descriptionLbl.font =  smallfont
            cell!.descriptionLbl.isHidden = false
            cell!.descriptionLbl.lineBreakMode = .byWordWrapping
            cell!.descriptionLbl.numberOfLines = 0
            cell!.descriptionLbl.sizeToFit()
            
            
            
            if(tmpModel?.descriptionImgPath != nil){
                cell!.descriptionImg.image = UIImage(contentsOfFile:(tmpModel?.descriptionImgPath!)!)
                cell?.descriptionImg.isHidden = false
            }else{
                cell!.descriptionImg.image = placeholderImg
            }
            //認識結果待ちじゃない時、認識再開
            if(processingFlag == false){
                
                startProcessing()
            }
        }else{
            //
            cell!.descriptionLbl.font = smallfont
            cell!.descriptionLbl.numberOfLines = 1
            cell!.descriptionLbl.sizeToFit()
            cell!.descriptionLbl.isHidden = true
            cell!.backgroundColor = UIColor.white
            cell!.titleBImage.backgroundColor = UIColor(red: 250/255.0, green: 247/255.0, blue: 237/255.0, alpha: 1)
            
        }
        cell!.titleLbl.font = cellfont
        cell!.titleLbl.lineBreakMode = .byWordWrapping
        cell!.titleLbl.numberOfLines = 0
        cell!.titleLbl.sizeToFit()
        


        //検査終了のチェック
        self.updateReportControlArea(indexPath)
        cell!.descriptionImg.sizeToFit()
        return cell!

    }
    
    
    /**
    レポートのコントロールエリアの完了ボタンなとの色を変える、完了可能な状態で完了発話
    
    - parameter indexPath: cellForRowAtIndexPathの indexPath
    */
    func updateReportControlArea(_ indexPath:IndexPath){
        if(processingIndex != (processlist?.processitems?.count)!){
            self.changeButtonLayout(nextWorkPlanBtn, enable: false)
            self.changeButtonLayout(processAllFinishedBtn, enable: false)
            return
        }
        
        //最後の行待て来ていたら、未完了の項目がある場合は「(項目キーワード) 未入力」と合成音声で流し、その項目に遷移
        let unfinshedflag = finishedCheckWithCondition(checkflag:true)
        if((unfinshedflag < 0)||(processlist?.random_input != 1)){//全項目入力ずみ(-2)/リスト取得失敗(-1)  ||  順不同入力ではない 項目    ->  作業完了へ
            NSLog("完了作業を行う")
            self.changeButtonLayout(nextWorkPlanBtn, enable: true)
            self.changeButtonLayout(processAllFinishedBtn, enable: true)
            if(indexPath.row + 1 == (processlist?.processitems?.count)!){
                endProcessing()
            }
        }else{//未完了項目があるので、未完了項目へ遷移
            //random_input == 1の場合未完了合成音を発話させて遷移
            jumptoUnfinshedAction(unfinshedflag)
        }

    }
    
    /**
     use as 引き継ぎ
     */
    func inputCustomize(){
        if(gsettingModel.workSharingFlag == false){
            self.cameraLbl.isHidden = true
            self.cameraImage.isHidden = true
            self.cameraBtn.isHidden = true
        }else{
            self.cameraLbl.isHidden = false
            self.cameraImage.isHidden = false
            self.cameraBtn.isHidden = false
        }
    }
    
    
    func changeButtonLayout(_ sender:UIButton,enable:Bool){
        if(enable == true){
            sender.layer.borderWidth = 0
            sender.layer.borderColor = UIColor(red: 136/255.0, green: 136/255.0, blue: 136/255.0, alpha: 1).cgColor
            sender.clipsToBounds = true
            sender.setTitleColor(UIColor.black, for: UIControlState())
            sender.backgroundColor = UIColor.orange
            sender.isEnabled = true
        }else{
            sender.layer.borderWidth = 1
            sender.layer.borderColor = UIColor(red: 150/255.0, green: 150/255.0, blue: 150/255.0, alpha: 1).cgColor
            sender.clipsToBounds = true
            sender.setTitleColor(UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 1), for: UIControlState())
            sender.backgroundColor = UIColor(red: 240.0/255.0, green: 240.0/255.0, blue: 240.0/255.0, alpha: 1)
            sender.isEnabled = false
        }
    }
    
    
    
    
    
    
    /**
     work primary idが存在する場合はそれをタイトルに入れる
     */
    func refreshReportTitle(){
        if(processlist?.processname != nil){
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    var idFont:UIFont
                    
                    if(gsettingModel.globalFontSize  != nil){
                        
                        if(gsettingModel.globalFontSize!*2/3 < 16){
                            idFont = UIFont.systemFont(ofSize: 16)
                        }else{
                            idFont = UIFont.systemFont(ofSize: gsettingModel.globalFontSize!*2/3)
                        }
                        var atttributeTittle:NSMutableAttributedString!
                        if((selfWeak.resultlist?.work_primary_id != nil)&&(selfWeak.resultlist?.work_primary_id != "")){
                            atttributeTittle = NSMutableAttributedString(string: (selfWeak.processlist?.processname)!, attributes: [NSForegroundColorAttributeName:UIColor.black,NSFontAttributeName:self!.cellfont])
                            
                            atttributeTittle.append(NSMutableAttributedString(string: String(format: "[%@]", (selfWeak.resultlist?.work_primary_id)!) , attributes: [NSForegroundColorAttributeName:UIColor.blue,NSFontAttributeName:idFont]))
                        }else{
                            atttributeTittle = NSMutableAttributedString(string: selfWeak.workPlanId, attributes: [NSForegroundColorAttributeName:UIColor.lightGray,NSFontAttributeName:idFont])
                            atttributeTittle.append(NSAttributedString(string: "."))
                            atttributeTittle.append( NSMutableAttributedString(string: (selfWeak.processlist?.processname)!, attributes: [NSForegroundColorAttributeName:UIColor.black,NSFontAttributeName:self!.cellfont]))
                        }
                        
                        
                        //                        selfWeak.controllerTilte.attributedText = selfWeak.workPlanId + "." + (selfWeak.processlist?.processname)!
                        selfWeak.controllerTilte.attributedText = atttributeTittle
                    }
                    
                    
                }
                
                
            })
        }

    }

    
    /**
    作業内容リストをファイルから読み込む
    */
    func getProcessList(){
        if(processfile == nil){
            NSLog("処理ファイルのパスがしてされてない")
            return
        }
        self.controllerTilte.font = cellfont
        let processDic :[String:Any]? = PVDSwiftUtils.getDictionaryResourceFromPathS(NSString(format: "/homejson/reports/%@",processfile!) as String)
        if(processDic == nil){
            SVProgressHUD.showError(withStatus: "processlist is null")
            return
        }
        
        processlist = Mapper<PVDProcessListModel>().map(JSON: processDic!)
        processlist?.processname = processDetail?.waitingTitle
        processlist?.creation_date = processDetail!.creation_date
        processlist?.voiced_name = processDetail!.voiced_name
        var tmpRandom:Int? = nil
        if(processDetail?.random_input == nil){
            processlist?.random_input = 0
            
        }else{
            tmpRandom = Int((processDetail?.random_input)!)
        }
        
        if(tmpRandom != nil){
            processlist?.random_input = tmpRandom
        }
        
        
        if(processlist == nil){
            print("process list get failed in file:%s,function:%s",#file,#function)
        }
        self.refreshReportTitle()
 
        
        var resultDic:[String:Any]!
        let tpfileName = "/result_" + gsettingModel.deviceid! + "_" + workPlanId + ".json"
        let tpfinishedfilePath:String =  kFinishedFolderPath + tpfileName
        let tpunfinishedPath:String = kUnfinishedFolderPath + tpfileName
        let tpuploadedPath:String = kbackupFolder + tpfileName
        if((FileManager.default.fileExists(atPath: tpunfinishedPath))&&(self.inputType != kPVDInputTypeUploaded)){
            //未完成レポート結果
            resultDic = PVDSwiftUtils.getDictionarybyFullPathS(tpunfinishedPath)
            resultlist = Mapper<PVDReportResultModel>().map(JSON:resultDic)

            let ret = finishedCheckWithCondition(checkflag:false)
            if(ret < 0){
                processingIndex = 0
            }else{
                processingIndex = ret
            }
            

            
        }else if((FileManager.default.fileExists(atPath: tpfinishedfilePath))&&(self.inputType != kPVDInputTypeUploaded)){
            //完成レポート結果
            resultDic = PVDSwiftUtils.getDictionarybyFullPathS(tpfinishedfilePath)
            resultlist = Mapper<PVDReportResultModel>().map(JSON: resultDic!)
        }else if(FileManager.default.fileExists(atPath: tpuploadedPath)){
            resultDic = PVDSwiftUtils.getDictionarybyFullPathS(tpuploadedPath)
            resultlist = Mapper<PVDReportResultModel>().map(JSON: resultDic!)
        
        }else{
            //新規
            resultDic = ["work_plan_id":workPlanId!,
                "device_id":gsettingModel.deviceid!,
                "report_form_name":(processlist?.processname)!,
                "report_form_id":reportid!,
                "user_name":gsettingModel.choosedSpeaker!,
                "start_time":PVDSwiftUtils.getoutputTimeStamp(Date()),
                "end_time":"",
                "operating_time":"00:00:00",
                "file_changed_time":PVDSwiftUtils.getoutputTimeStamp(Date()),
                "report_file_name":"",
                "original_result_id":gsettingModel.deviceid! + "_" + self.workPlanId,
                "items":[[
                    
                ]]]
            
            resultlist = Mapper<PVDReportResultModel>().map(JSON: resultDic!)
            for tmpItem  in (processlist?.processitems)!{
                let itemDic:[String:Any]! = ["id":tmpItem.itemid!,"result":["value":""],"item_operating_time":"","item_user_name":""]
                let resultItem    = Mapper<PVDReportResultItemModel>().map(JSON: itemDic!)
                if(resultlist?.items == nil){
                    resultlist?.items = [resultItem!]
                }else{
                    resultlist?.items?.append(resultItem!)
                }
            }
            //create new result file
            self.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
            let rJSONString = Mapper().toJSONString(self.resultlist!, prettyPrint: true)
            PVDSwiftUtils.saveReulstfile(self.inputType, jsonString: rJSONString!,workplanid: workPlanId)
            appendlistJsonFile(false)
            
        }
        self.updateResultListStartTime(processingIndex)
        
        if((resultlist?.operating_time == nil)||(resultlist?.operating_time == "")){
            resultlist?.operating_time = "00:00:00"
        }
        self.reportStartTime = Date().timeIntervalSince1970 - PVDSwiftUtils.timerCountStringToTimeInterval((resultlist?.operating_time)!)

        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.timerCounter = Timer.scheduledTimer( timeInterval: 0.5, target: selfWeak, selector: #selector(PVDInputController.inputTimerCounter(_:)), userInfo: nil, repeats: true)
            }
        }
        let calimg:UIImageView! = UIImageView()
        var i = 0
        while(i < processlist?.processitems?.count){
            let tmpModel = processlist?.processitems![i]
            var imagePath:String? = nil
            let jpgPath = kpathForReportFolder + "/" + reportid! + "/" + tmpModel!.itemid! + ".jpg"
            let pngPath = kpathForReportFolder + "/" + reportid! + "/" + tmpModel!.itemid! + ".png"
            if(FileManager.default.fileExists(atPath: jpgPath) == true){
                imagePath = jpgPath
            }else if(FileManager.default.fileExists(atPath: pngPath) == true){
                imagePath = pngPath
            }
            
            if(imagePath != nil){
                tmpModel?.descriptionImgPath = imagePath
                
                calimg.image = UIImage(contentsOfFile: imagePath!)
                
                
                tmpModel?.heightOfDiscriptionImage = (calimg.image!.size.height)/(calimg.image!.size.width) * kScreenWidth
                
                
            }
            i += 1
        }
    }
    
    /**
     未完了->完了ファイルの移動
     */
    func finishReportFile(){
        let tpfileName = "/result_" + gsettingModel.deviceid! + "_" + workPlanId + ".json"
        let tpfinishedfilePath:String =  kFinishedFolderPath + tpfileName
        let tpunfinishedPath:String = kUnfinishedFolderPath + tpfileName
        if(FileManager.default.fileExists(atPath: kFinishedFolderPath) == false){
            try! FileManager.default.createDirectory(atPath: kFinishedFolderPath, withIntermediateDirectories: true, attributes: nil)
        }
        do{
            try FileManager.default.moveItem(atPath: tpunfinishedPath, toPath: tpfinishedfilePath)
        }catch{
            print(error)
        }
    }
    
    
    
    func finishedReportMoveBackToUnfinished(){
        let tpfileName = "/result_" + gsettingModel.deviceid! + "_" + workPlanId + ".json"
        let tpfinishedfilePath:String =  kFinishedFolderPath + tpfileName
        let tpunfinishedPath:String = kUnfinishedFolderPath + tpfileName

        if(FileManager.default.fileExists(atPath: kUnfinishedFolderPath) == false){
            try! FileManager.default.createDirectory(atPath: kUnfinishedFolderPath, withIntermediateDirectories: true, attributes: nil)
        }
        do{
            try FileManager.default.moveItem(atPath: tpfinishedfilePath, toPath: tpunfinishedPath)
        }catch{
            print(error)
        }
    }
    
    /**
     データリストの更新(現レポートの最終更新時間を更新、optional_flagがIDの項目にworkPrimaryIdを書き込むなど)
     
     - parameter workPrimaryId: work primary id,""で変更しない,nilでclear
     - parameter index:設定するindex
     - parameter workShareFlag:引き継ぎアップロード成功時のみtrue
     */
    func updateListJsonWithWorkPrimaryID(_ workPrimaryId:String?,index:Int,workShareFlag:Bool){
        if((index < self.processlist?.processitems?.count)&&(index >= 0)){
            let processModel:PVDProcessItemModel = (self.processlist?.processitems?[index])!
            if(processModel.optional_flag == "ID"){
                self.updateListJsonfile(workPrimaryId,workShareFlag: workShareFlag)//workPrimaryIDを設定する
                return
            }
            
        }
        self.updateListJsonfile(nil,workShareFlag: workShareFlag)//設定せず
    }
    
    
    /**
     現レポートの最終更新時間を更新
     
     - parameter work_primary_id:　work primary id ある時は設定する、nilの時は設定しはい、や""の時はクリア
     */
    func updateListJsonfile(_ workPrimaryId:String?,workShareFlag:Bool){
        var dataDic:[String:Any]!
        var newlist:PVDWaitingListModel!
        //データ取得
        if((self.inputType == kPVDInputTypeNew)||(self.inputType == kPVDInputTypeUnfinished)){
            dataDic = PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)
        }else if(self.inputType == kPVDInputTypeFinished){
            dataDic = PVDSwiftUtils.getDictionarybyFullPathS(kfinishedJsonPath)
        }
        
        if(FileManager.default.fileExists(atPath: kbackupFolder) == false){
            try! FileManager.default.createDirectory(atPath: kbackupFolder, withIntermediateDirectories: true, attributes: nil);
        }
        
        if(self.inputType != kPVDInputTypeUploaded){
            //修正時間を更新
            var index:Int = 0
            newlist = Mapper<PVDWaitingListModel>().map(JSON: dataDic!)
            //        print(dataDic)
            //reportがwork_primary_idを持つ場合はホームでのlistに書き込む
//            var maxCnt:Int = 1
            newlist.waitingItems = newlist.waitingItems?.reversed()
            let tpLastEditDate = PVDSwiftUtils.getoutputTimeStamp(Date())
            let tpLastEditDateForSort = PVDSwiftUtils.getTimeIntervalFromTimeString(tpLastEditDate)
            while(index < newlist.waitingItems!.count){
                let tmpWaitItem = newlist.waitingItems![index]
                if(tmpWaitItem.workplanid == self.workPlanId){
                    if((tmpWaitItem.original_result_id == nil)||(tmpWaitItem.original_result_id == "")){
                        tmpWaitItem.original_result_id = gsettingModel.deviceid! + "_" + self.workPlanId
                    }
                    if(workPrimaryId == nil){
                        //do nothing
                    }else if(workPrimaryId == ""){
                        tmpWaitItem.work_primary_id = nil
                        self.resultlist?.work_primary_id = nil
                    }else{
                        tmpWaitItem.work_primary_id = workPrimaryId
                        self.resultlist?.work_primary_id = workPrimaryId
                        
                    }
                    if(tmpWaitItem.work_sharing_uploaded != true){
                        tmpWaitItem.work_sharing_uploaded = workShareFlag
                    }
                    tmpWaitItem.lasteditDate = tpLastEditDate
                    tmpWaitItem.lasteditDateForSort = tpLastEditDateForSort
                    //                break
                }


                index += 1
                
            }
            newlist.waitingItems = newlist.waitingItems?.reversed()
            let tJSONString = Mapper().toJSONString(newlist, prettyPrint: true)
            //更新後のデータ保存
            if((self.inputType == kPVDInputTypeNew)||(self.inputType == kPVDInputTypeUnfinished)){
                PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
                
            }else if(self.inputType == kPVDInputTypeFinished){
                PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kfinishedJsonPath)
            }
        
        }else{
            if((workPrimaryId != nil)&&(workPrimaryId != "")){
                self.resultlist?.work_primary_id = workPrimaryId
            }
            
            let tpfileName = "/result_" + (self.resultlist?.original_result_id)! + ".json"

            //add record to uploaded table
            PVDDatabaseAccess.sharedInstance.addNewUploadedRecord(tpfileName, name: (self.resultlist?.report_form_name)!, work_plan_id: (self.resultlist?.work_plan_id)!, last_edit_time: self.resultlist!.file_changed_time!, original_result_id: (self.resultlist?.original_result_id)!, report_form_id: (self.resultlist?.report_form_id)!, work_primary_id: self.resultlist?.work_primary_id)
        }
        
        self.refreshReportTitle()
        
    }
    
   

    
    /**
     現在のレポートを指定のjsonfileに登録(ホーム画面の表示のため)
     
     - parameter finishedflag:  true:完了へ登録   false未完了へ保存
     */
    func appendlistJsonFile(_ finishedflag:Bool){
        //create or general unfinished json list
        
        var dataDic:[String:Any]!
        var tmplist:PVDWaitingListModel!
        if(finishedflag == false ){
//            tmplist = unfinishedList
            dataDic =   PVDSwiftUtils.getDictionarybyFullPathS(kUnfinishedJsonPath)
        }else{
//            tmplist = finishedList
            dataDic =   PVDSwiftUtils.getDictionarybyFullPathS(kfinishedJsonPath)
        }
        var tmpDic:[String:Any]!
        let tpLastEditDate = PVDSwiftUtils.getoutputTimeStamp(Date())
        let tpLastEditDateForSort = PVDSwiftUtils.getTimeIntervalFromTimeString(tpLastEditDate)
        //work primary id とwork plan idの辞書を分けて使う
        if(self.resultlist?.work_primary_id == nil){
            tmpDic = ["name":(processlist?.processname)!,
                "report_form_id":reportid!,
                "work_plan_id":workPlanId,
                "original_result_id":gsettingModel.deviceid! + "_" + self.workPlanId,
                "last_edit_time":tpLastEditDate,
                "lasteditDateForSort":tpLastEditDateForSort]
                
            
        }else{
            tmpDic = ["name":(processlist?.processname)!,
                "report_form_id":reportid!,
                "work_plan_id":workPlanId,
                "last_edit_time":tpLastEditDate,
                "lasteditDateForSort":tpLastEditDateForSort,
                "original_result_id":gsettingModel.deviceid! + "_" + self.workPlanId,
                "work_primary_id":(self.resultlist?.work_primary_id)!]
        }
        
        if(dataDic == nil){
            
            dataDic = ["list":[tmpDic]]
            
            tmplist = Mapper<PVDWaitingListModel>().map(JSON: dataDic!)
        }else{
            tmplist = Mapper<PVDWaitingListModel>().map(JSON: dataDic!)
            if let delindex = tmplist.waitingItems?.index(where: {$0.workplanid == workPlanId}) {
                
                tmplist.waitingItems?.remove(at: delindex)
            }
            

            let newItem = Mapper<PVDWaitingModel>().map(JSON: tmpDic!)
            //未完成且未完成リストが新しい順->古い順の場合追加するデータはinsert　at 0　で
            if((finishedflag == false)&&(gsettingModel.unfinishedListOrder == false)){
                
                tmplist.waitingItems?.insert(newItem!, at: 0)
            }else{
                
                tmplist?.waitingItems?.append(newItem!)
            }
        }
        
        let tJSONString = Mapper().toJSONString(tmplist, prettyPrint: true)
        if(finishedflag == false ){
            PVDSwiftUtils.overwriteJsonStringTofile(tJSONString!, filePath: kUnfinishedJsonPath)
        }else{
            PVDSwiftUtils.overwriteJsonStringTofile( tJSONString!, filePath: kfinishedJsonPath)
        }
        
    }
    
    
    

    
    /**
    Siri認識開始
    */
    func startSiriProcessing(){
//        if((processlist == nil)||(processlist?.processitems == nil)){
//            print("processlist or processlist.processitems is nil")
//            return
//        }
//        if(processingIndex >= processlist?.processitems?.count){
//            print("処理完了")
//            return
//        }
//        selectionPicker?.hidden = true
//        let tmpModel = processlist?.processitems?[processingIndex]
////        var speechString:String!
////        speechString = (tmpModel?.voiced_name)! + "、自由入力開始"
//        //siri認識
//        DictationHelper.sharedInstance().startdictionWithoutDuration {[weak self] (dictationString) -> Void in
//            if(dictationString != nil){
//                if let selfWeak = self {
//                    var retString:NSString = ""
//                    retString = dictationString
//                    let rangeStop:NSRange = retString.rangeOfString("音声入力完了")
//                    if(rangeStop.location != NSNotFound){
//                        NSNotificationCenter.defaultCenter().postNotificationName(kSiriStopFreeInputNotification, object: nil)
//                    }else{
//                        let resModel = selfWeak.resultlist?.items?[selfWeak.processingIndex]
//                        var tmpString:String = ""
//                        if( resModel?.result?.value != nil){
//                            tmpString = (resModel?.result?.value)!
//                        }
//                        resModel?.result?.value = tmpString + dictationString
//                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
//                            
//                            let indexPath = NSIndexPath(forRow: selfWeak.processingIndex, inSection: 0)
//                            let cell = selfWeak.processingTbl.cellForRowAtIndexPath(indexPath) as? PVDProcesssingFreeInputCell
//                            if(cell != nil){
//                                cell!.inputFld.text = resModel?.result?.value
//                            }
//                        })
//                    }
//                }
//            }
//        }
    }
    
    /**
    Voicedo認識開始処理
    */
    func startProcessing(){
        lasttextChangedTime = nil
        directinputClearFlag = false
        if((processlist == nil)||(processlist?.processitems == nil)){
            print("processlist or processlist.processitems is nil")
            return
        }
        
        if(processingIndex >= processlist?.processitems?.count){
            print("処理完了")
            return
        }
        
        let tmpModel = processlist?.processitems?[processingIndex]
        
        
        selectionPicker?.isHidden = true
        processingFlag = true
        
        var speechString:String!
        if(tmpModel?.voiced_name != nil){
            speechString = tmpModel?.voiced_name
        }else{
            speechString = tmpModel?.itemname
        }
        if(speechString == nil){
            speechString = ""
        }
        var instanceRule:String = "Item_"+(tmpModel?.itemid)!
        if(tmpModel!.itemType == PVDInputType.kSelection.rawValue){//選択式
            //選択式の時選択を表示
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    selfWeak.selectionList = tmpModel?.itemoption! as NSArray?
                    if((selfWeak.selectionList != nil)&&(selfWeak.selectionList?.count > 0)){
                        selfWeak.selectionPicker?.reloadAllComponents()
                        selfWeak.selectionPicker?.selectRow(0, inComponent: 0, animated: false)
                        selfWeak.selectionPicker?.isHidden = false
                        selfWeak.selectionPicker?.layer.frame = CGRect(x: 0, y: selfWeak.processingTbl.frame.maxY , width: kScreenWidth, height: selfWeak.kPickerHeight)
                    }
                }
            })
        }else if(tmpModel?.itemType == PVDInputType.kQRCode.rawValue){//QRCode
            instanceRule = kQRControlRuleKey
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                
                if let selfWeak = self {
                    selfWeak.inSubViewEventFlag = true
                    let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
                    
                    selfWeak.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDQRScanControl"), animated: true, completion: nil)
                }
                
            })
            SpeechTalkManager.sharedInstance.speechTalk(speechString, forceCancelFlag: false)
            return
            
        }else if(tmpModel?.itemType == PVDInputType.kFreeInput.rawValue){
            //
            NSLog("異常:voicedoの認識処理Cellで自由入力タイプが出だ")
//            //自由入力に切り替える

//            self.psrManager.voicedoClose()
        
        }else if((tmpModel?.itemType == PVDInputType.kDirectInput.rawValue)||(tmpModel?.itemType == PVDInputType.kDirectInputG.rawValue)){
            //直接入力
            if(tmpModel?.itemType == PVDInputType.kDirectInputG.rawValue){//自動遷移の場合データの上書きフラグを設定する
                directinputClearFlag = true
            }
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    let indexPath = IndexPath(row: selfWeak.processingIndex, section: 0)
                    let cell = selfWeak.processingTbl.cellForRow(at: indexPath) as! PVDProcessingCell
                    cell.inputFld.keyboardType = UIKeyboardType.default
                    cell.validateFlag = false
                    cell.inputFld.isEnabled = true
                    cell.inputFld.becomeFirstResponder()
                }
            })
        }
        else{//数値,カスタム (tmpModel?.itemType == PVDInputType.kValue.rawValue)
            if(tmpModel?.clickFlag == true){
                tmpModel?.clickFlag = false
                PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                    if let selfWeak = self {
                        let indexPath = IndexPath(row: selfWeak.processingIndex, section: 0)
                        let cell = selfWeak.processingTbl.cellForRow(at: indexPath) as! PVDProcessingCell
                        if(tmpModel?.itemType == PVDInputType.kValue.rawValue){
                            cell.inputFld.keyboardType = UIKeyboardType.numbersAndPunctuation
                            cell.validateFlag = true
                        }else{
                            cell.inputFld.keyboardType = UIKeyboardType.default
                            cell.validateFlag = false
                        }
                        cell.inputFld.isEnabled = true
                        cell.inputFld.becomeFirstResponder()
                    }
                
                    
                })
            }
            
        }

        //読み上げを飛ばす(未入力なと)
        if((processlist?.random_input == 1)&&(mspeakOnOrderFree == false)){
            speechString = ""
        }
        if(mspeakOnOrderFree == true){
            mspeakOnOrderFree = false
        }
        
        
        if(gsettingModel.inspectionOnSpeech == "true"){
            NSLog("inspectionOnSpeech_true")
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    _ = selfWeak.psrManager.voicedoStartInspection(instanceRule,detail:tmpModel?.itemname)
                }
            })
            
            SpeechTalkManager.sharedInstance.speechTalk(speechString!,forceCancelFlag: false)
            
        }else{
            NSLog("inspectionOnSpeech_false")
            SpeechTalkManager.sharedInstance.speechTalkAndDoAction(speechString!,forceCancelFlag: false, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                if let selfWeak = self {
                    
                    _ = selfWeak.psrManager.voicedoStartInspection(instanceRule,detail:tmpModel?.itemname)
                }
                
            })
        }
    
    }
    
    /**
    完了時の処理
    */
    func endProcessing(){
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.selectionPicker!.isHidden = true
            }
        }
        if(readFinishedSpeechFlag == false){
            let ad002 = String(format: NSLocalizedString("AD002", comment: "完了状態の認識"))
            _ = self.psrManager.voicedoStartInspection(kEndControlRuleKey, detail: ad002)
        }else{
            readFinishedSpeechFlag = false

            processFinishedSpeach()

        }
    }
    
    
    
    /**
       完了メッセージの発話
    */
    func processFinishedSpeach(){
        finishedAction(true, clearRecoverFlag: false, backToHome: false,uploadFlag: .kWriteFileOnly,retryActionType: .kNone)
        let ad002 = String(format: NSLocalizedString("AD002", comment: "完了状態の認識"))
        let s002 = String(format: NSLocalizedString("S002", comment: "作業完了"))
        SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s002,forceCancelFlag: false, startBlock: nil) { [weak self](synthesizer, utterance) -> () in
            if let selfWeak = self {
                _ = selfWeak.psrManager.voicedoStartInspection(kEndControlRuleKey, detail: ad002)
            }
        }

    }
    
    
    /**
      発話種類の判別
     
    - parameter result: 認識結果
    */
    func regonisationAction(_ result:NSString){
        let uxxx030 = String(format: NSLocalizedString("UXXX-030", comment: "イレギュラーな解析結果"))
        let l006004 = String(format: NSLocalizedString("L006-004", comment: "未処理タイプ:"))
        
        let resultArray = result.components(separatedBy: ",")
        
        if(resultArray.count < 1){
            NSLog("認識エラー：イレギュラーな解析結果、分類不能:%@",resultArray)
            PSRManager.sendLogTextAsync([kLogViewKey:uxxx030])
            self.doCommandReloadTable()
            return
        }
        var resultType:String = ""
        if(resultArray.count > 1){
            resultType = resultArray[1]
        }
        if((resultType == "入力値")||(resultArray.count == 1)||(resultType == "")){
            let regret = inputValueRegonisationAction(resultArray[0] as String)
            if(regret == true){//結果処理成功の場合は処理終了
                return
            }
            
        }else if(resultType == "制御語"){
            doVoiceCommand(resultArray[0] as String)
            return
        }else if(resultType == "カメラ制御語"){
            if(inSubViewEventFlag == true){
                if(resultArray[0] == "撮影"){
                    NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceTakePhotoNotification), object: nil)
                    //todo camera Command
                }else if(resultArray[0] == "戻る"){
                    NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceTakePhotoCancelNotification), object: nil)
                }else{
                    NSLog("未処理カメラコマンド:%@",result)
                }
            }
            return
        }
        let logString = l006004 + (result as String)
        //結果処理失敗なとの場合項目をもう一度読み上げる
        PSRManager.sendLogTextAsync([kLogViewKey:logString])
        if(mmoveflag == true){
            mmoveflag = false
            self.scrollAndReloadTable()
        }else{
            PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
                if let selfWeak = self {
                    selfWeak.processingTbl.reloadData()
                }
            }
        }

    }
    
    /**
     値の処理
     
     - parameter inputString: 認識結果の値
     
     - returns: true:処理成功  false:処理失敗
     */
    func inputValueRegonisationAction(_ inputString:String)->Bool{
        let s003 = String(format: NSLocalizedString("S003", comment: "。入力ちが規定外です"))
        var prefix:String = ""
        //入力値処理
        NSLog("入力値として処理します")
        //bound over check

        //項目+値 => res1Array
        //移動+項目 => res2Array
        let res1Array = inputString.components(separatedBy: "__")
        let res2Array = inputString.components(separatedBy: "___")
        var resultString:String!
        if((res2Array.count >= 2)&&(processlist?.random_input == 1)){//移動+キーワード
            let keyword = res2Array[1].replacingOccurrences(of: "__", with: "")
            let targetIndex = getIndexOfKeyword(keyword)
            if(targetIndex != -1){
                resultString = res2Array[1]
                //移動する前
                self.updateResultListEndTime(self.processingIndex,saveresultFlag:true)
                processingIndex = targetIndex
                self.updateResultListStartTime(self.processingIndex)
                self.processingFlag = false
                mmoveflag = true
                SpeechTalkManager.sharedInstance.speechTalk(inputString,forceCancelFlag: false)
            }
            return false
        }else if((res1Array.count >= 2)&&(processlist?.random_input == 1)){//キーワード+値
            let targetIndex = getIndexOfKeyword(res1Array[0])
            if(targetIndex != -1){
                prefix = res1Array[0]
                resultString = res1Array[1]
                processingIndex = targetIndex
                mmoveflag = true
            }else{//index取得失敗の場合再度読みあげ
                return false
            }
        }else{//値=>フォーカスしている項目に値を設定する
            resultString = inputString
        }
//        let targetindex = getIndexOfKeyword("装置Ｎ番号は")
        //入力完了(最後の「入力完了」 ⇒ 作業完了状態に遷移。入力必須項目に未入力があれば「高さ(項目キーワード) 未入力」と合成音声で流し、その項目に遷移以外)
        
        
        //以上入順不同処理
        //以下通常値としての処理
        if(processingIndex >= self.processlist?.processitems?.count){
            NSLog("illegal input")
            return false
        }
        let tmpModel:PVDProcessItemModel = (processlist?.processitems?[processingIndex])!
        let resModel = resultlist?.items?[self.processingIndex]
        var extraMessage:String = ""
        let resValueString:String = resultString
        //最小値、最大値チェックして数字かつ範囲外の場合はエラーメッセージを出す
        if((PVDSwiftUtils.isNumeric(resValueString))&&((tmpModel.max_val != nil)||(tmpModel.min_val != nil))){
            
            let resValue = Double(resValueString)
            if(((tmpModel.min_val != nil)&&(resValue < Double(tmpModel.min_val!)))||((tmpModel.max_val != nil)&&(resValue > Double(tmpModel.max_val!)))){
                extraMessage = s003
            }
        }
        var yomi:String = ""
        
        
        if(resModel != nil){
            resModel?.result?.value = resultString//入力値として保存
            if(tmpModel.ext != nil){
                if(tmpModel.ext?.range(of: "棒読み") != nil){
                    //棒読みフラグがオンの場合、数字の棒読み文字列を作る
                    yomi = PVDSwiftUtils.numberTransForm(resultString)
                }
            }else{
                yomi = (resModel?.result?.value)!
            }
        }
        processingFlag = true
        DispatchQueue.main.async(execute: {[weak self]  in
            if let selfWeak = self {
                //レポート最終更新時間を更新して、項目の終了時間を更新してー>ファイルに反映
                selfWeak.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
                let tJSONString = Mapper().toJSONString(selfWeak.resultlist!, prettyPrint: true)
                selfWeak.updateResultListEndTime(selfWeak.processingIndex,saveresultFlag:false)
                PVDSwiftUtils.saveReulstfile(selfWeak.inputType, jsonString: tJSONString!,workplanid: selfWeak.workPlanId)
                //
                selfWeak.updateListJsonWithWorkPrimaryID(resModel?.result?.value, index: (self?.processingIndex)!,workShareFlag: false)
                selfWeak.processingTbl.reloadData()
            }
        })
        //結果発話
        //---
        PSRManager.writeInspectionLog("結果発話:" + prefix + yomi + extraMessage )
        SpeechTalkManager.sharedInstance.speechTalkAndDoAction((prefix + yomi + extraMessage), forceCancelFlag: true, startBlock: nil, finishedBlock: { (synthesizer, utterance) -> () in
            if(self.processingIndex  < self.processlist?.processitems?.count){
                self.processingIndexIncrease(true)//認識結果更新して、結果を発話後次の行へ
                self.updateResultListStartTime(self.processingIndex)
            }
            self.processingFlag = false
            self.reloadTableAndScroll()
        })
        return true
    }
    
    func doVoiceCommand(_ commandStr:String){
        NSLog("%s,processingIndex:%d",#function,processingIndex)
        let uxxx037 = String(format: NSLocalizedString("UXXX-037", comment: "コマンドファイル読み込み失敗コマンドの設定されたアカウントで初期ファイルを再ダウンロードしてください"))
        let uxxx038 = String(format: NSLocalizedString("UXXX-038", comment: "「中断」コマンド読み込み失敗、"))
        let uxxx040 = String(format: NSLocalizedString("UXXX-040", comment: "「前に戻る」コマンド読み込み失敗、"))
        let uxxx041 = String(format: NSLocalizedString("UXXX-041", comment: "「次へ進む」コマンド読み込み失敗、"))
        let uxxx042 = String(format: NSLocalizedString("UXXX-042", comment: "「交代」コマンド読み込み失敗、"))
        let uxxx043 = String(format: NSLocalizedString("UXXX-043", comment: "「ホームへ」戻るコマンド読み込み失敗、"))
        let uxxx044 = String(format: NSLocalizedString("UXXX-044", comment: "「もう一度」コマンド読み込み失敗、"))
        let uxxx049 = String(format: NSLocalizedString("UXXX-048", comment: "「次の作業再開」コマンド読み込み失敗、"))
        if(gcontrolBinds.wnext == nil){
            gcontrolBinds.wnext = ""
        }
        let s004 = gcontrolBinds.wnext! + "できません"
        let s008 = gcontrolBinds.wprev//String(format: NSLocalizedString("S008", comment: "前に戻る"))
        let s009 = gcontrolBinds.wrepeat //String(format: NSLocalizedString("S009", comment: "もう一度"))
        let s010 = gcontrolBinds.wnext //String(format: NSLocalizedString("S010", comment: "ジャンプ"))
        let s011 = gcontrolBinds.wexit //String(format: NSLocalizedString("S011", comment: "中断する"))
        let s012 = gcontrolBinds.wchange //String(format: NSLocalizedString("S012", comment: "作業引き継ぎ"))
        let s013 = gcontrolBinds.wagain //String(format: NSLocalizedString("S013", comment: "次の作業開始"))
        let s014 = gcontrolBinds.wbackhome //String(format: NSLocalizedString("S014", comment: "ホームに戻る"))
        let s015 = String(format: NSLocalizedString("S015", comment: "未処理の制御語"))
        let backlogPath = kbackupFolder + "/" + gsettingModel.statusLogFileName!
        PSRManager.writeLog(toFile: (commandStr + "\n"), filePath: backlogPath)
        //制御設定が不正かをチェック
        if((gcontrolBinds.wprev == "")||(gcontrolBinds.wprev == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx040)
            return
        }
        
        if((gcontrolBinds.wnext == "")||(gcontrolBinds.wnext == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx041)
            return
        }
        
        if((gcontrolBinds.wbackhome == "")||(gcontrolBinds.wbackhome == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx043)
            return
        }
        if((gcontrolBinds.wexit == "")||(gcontrolBinds.wexit == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx038)
            return
        }
        
        if((gcontrolBinds.wagain == "")||(gcontrolBinds.wagain == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx049)
            return
        
        }
        if((gcontrolBinds.wrepeat == "")||(gcontrolBinds.wrepeat == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx044)
            return
        }
        
        if((gcontrolBinds.wchange == "")||(gcontrolBinds.wchange == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx042)
            return
        }
        if((gcontrolBinds.wmove == "")||(gcontrolBinds.wmove == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx049)
            return
        }
        if((gcontrolBinds.wfinish == "")||(gcontrolBinds.wfinish == nil)){
            SVProgressHUD.showError(withStatus: uxxx037 + uxxx049)
            return
        }
        
        switch commandStr{
        case PVDInputcommandType.kGoBackCmd.rawValue,gcontrolBinds.wprev!:
            self.processingIndexDecrease()
            SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s008,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                if let selfWeak = self {
                    selfWeak.reloadTableAndScroll()
                }
            })
            break
        case PVDInputcommandType.kSkipCmd.rawValue,gcontrolBinds.wnext! :
            
            //最後の課目じゃない場合は次へ行ける
            if(processingIndex  <= (processlist?.processitems?.count)! - 1){
                //skip可能性の検証
                let tmpResultModel = resultlist?.items?[self.processingIndex]
                let tmpModel:PVDProcessItemModel = (processlist?.processitems?[processingIndex])!
                //result未記入+(必須/flag未設定/ID) "false"  == nil
                if((tmpResultModel?.result?.value == "")&&((tmpModel.optional_flag == "false")||(tmpModel.optional_flag == nil)||tmpModel.optional_flag == "ID")){
                    
                    SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s004,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                        if let selfWeak = self {
                            selfWeak.doCommandReloadTable()
                        }
                    })
                }else{
                    self.processingIndexIncrease(true)
                    SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s010,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                        if let selfWeak = self {
                            selfWeak.reloadTableAndScroll()
                        }
                    })
                    
                }
            }else{
                self.doCommandReloadTable()
                
            }
            
            
            break
        case PVDInputcommandType.kFinishedCmd.rawValue,gcontrolBinds.wbackhome!://ホームに戻る
            if(self.processingIndex == self.processlist?.processitems?.count){
                SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s014,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                    if let selfWeak = self {
                        if(self?.inputType == kPVDInputTypeUploaded){
                            selfWeak.finishedAction(false,clearRecoverFlag: true,backToHome: true, uploadFlag: .kResultUpdate,retryActionType: .kGoHome)
                        }else{
                            selfWeak.finishedAction(false,clearRecoverFlag: true,backToHome: true, uploadFlag: .kFinishedUpload,retryActionType: .kGoHome)
                        
                        }
                        
                    }
                })
            }else{
                self.doCommandReloadTable()
            }
            break
        
        case PVDInputcommandType.kStopCmd.rawValue,gcontrolBinds.wexit!://中断
                //最後の課目じゃない場合は中断できる
            SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s011,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                if let selfWeak = self {
                    if(self?.inputType == kPVDInputTypeUploaded){
                        selfWeak.finishedAction(false,clearRecoverFlag: true,backToHome: true, uploadFlag: .kResultUpdate,retryActionType: .kGoHome)
                    }else{
                        selfWeak.finishedAction(false,clearRecoverFlag: true,backToHome: true,uploadFlag: .kWriteFileOnly,retryActionType: .kGoHome)
                    }
                    
                }
            })
            break
        case PVDInputcommandType.kStartNextCmd.rawValue,gcontrolBinds.wagain!://次の作業開始
                if(self.processingIndex == self.processlist?.processitems?.count){
                    SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s013,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                        if let selfWeak = self {
                            selfWeak.startNextAction()
                        }
                    })
                }else{
                    self.doCommandReloadTable()
                }
            break

        case PVDInputcommandType.kRepeatCmd.rawValue,gcontrolBinds.wrepeat!:
            print("もう一度コマンド")
            SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s009,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                if let selfWeak = self {
                    selfWeak.mspeakOnOrderFree = true
                    selfWeak.doCommandReloadTable()
                }
            })
            
            
            break
            
        case PVDInputcommandType.kWorkShareCmd.rawValue,gcontrolBinds.wchange!:
            print("作業引き継ぎ")
            //引き継ぎAction
            if(gsettingModel.workSharingFlag == false){
                self.doCommandReloadTable()
                return
            }
            SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s012,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                if let selfWeak = self {
                    if(gsettingModel.workSharingGoOn == true){//引き継ぎ後次の作業開始
                        selfWeak.finishedAction(false, clearRecoverFlag: true, backToHome: false, uploadFlag: .kWorkShareUpload,retryActionType: .kNone)
                    }else{//引き継ぎ後ホーム
                        selfWeak.finishedAction(false, clearRecoverFlag: true, backToHome: true, uploadFlag: .kWorkShareUpload,retryActionType: .kNone)
                    }
                }
            })
            break
        case PVDInputcommandType.kFinisheCmd.rawValue,gcontrolBinds.wfinish!:
            let unfinshedIndex = finishedCheckWithCondition(checkflag:true)
            if((processlist?.random_input != 1)||(unfinshedIndex < 0)){//順不同入力オフ/全項目入力済みの場合は入力完了へ
                self.processingIndex = (self.processlist?.processitems?.count)!
                self.scrollAndReloadTable()
            }else{
                //未完了へ
                self.processingIndex = unfinshedIndex
                var keyword = getKeywordByIndex(unfinshedIndex)
                if(keyword == nil){
                    keyword = ""
                }
                let unfinishedSpeach = keyword! + "未入力"

                self.processingIndex = unfinshedIndex
                SpeechTalkManager.sharedInstance.speechTalkAndDoAction(unfinishedSpeach,forceCancelFlag: false, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                    if let selfWeak = self {
                        selfWeak.processingFlag = false
                        selfWeak.scrollAndReloadTable()
                    }
                })
                return
            }
            break
        case PVDInputcommandType.kMoveToUnfinished.rawValue,gcontrolBinds.wmoveToUnfinished!://未完了移動
            let moveindex = finishedCheckWithCondition(checkflag: false)
            
            self.processingFlag = false
            if((processlist?.random_input != 1)||(moveindex < 0)){//順不同入力オフ/全項目入力済みの場合はリロード
                self.scrollAndReloadTable()
            }else{
                self.processingIndex = moveindex
                //未完了へ
                var keyword = getKeywordByIndex(moveindex)
                if(keyword == nil){
                    keyword = ""
                }
                SpeechTalkManager.sharedInstance.speechTalkAndDoAction("未入力移動",forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                    if let selfWeak = self {
                        selfWeak.mspeakOnOrderFree = true
                        selfWeak.scrollAndReloadTable()
                    }
                })
                return
            }

            break
            
        case PVDInputcommandType.kMoveToRequired.rawValue,gcontrolBinds.wmoveToRequired!://必須移動
            let moveindex = finishedCheckWithCondition(checkflag: true)
            self.processingFlag = false
            if((processlist?.random_input != 1)||(moveindex < 0)){//順不同入力オフ/全項目入力済みの場合はリロード
                self.processingIndex = (self.processlist?.processitems?.count)!
                self.scrollAndReloadTable()
            }else{
                //未完了へ
                self.processingIndex = moveindex
                SpeechTalkManager.sharedInstance.speechTalkAndDoAction("必須移動",forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                    if let selfWeak = self {
                        selfWeak.mspeakOnOrderFree = true
                        selfWeak.scrollAndReloadTable()
                    }
                })
                
                return
            }

            break
        default:
            NSLog("未処理のコマンドを認識しました:%d",commandStr)
            SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s015,forceCancelFlag: true, startBlock: nil, finishedBlock: { [weak self](synthesizer, utterance) -> () in
                if let selfWeak = self {
                    selfWeak.doCommandReloadTable()
                }
            })
            
        }
        
    }
    

    

    
    
    func showPhotoAction(_ sender:UIButton){
        

        inSubViewEventFlag = true //表示フラグ、画面変えの時の初期化分岐用
        let cell:UITableViewCell? = PVDSwiftUtils.parentCellFor(sender)
        if(cell != nil){
            let l006005 = String(format: NSLocalizedString("L006-005", comment: "アルバム閲覧"))
            let l006006 = String(format: NSLocalizedString("L006-006", comment: "アルバムが見つかりません"))
            let uxxx019 = String(format: NSLocalizedString("UXXX-019", comment: "OK"))
            let indexPath:IndexPath = processingTbl.indexPath(for: cell!)!
            
            let tmpModel = processlist?.processitems?[indexPath.row]
            
            
            if(tmpModel!.albumName == nil){
                if((processlist?.processname == nil)||(processlist?.creation_date == nil)||(tmpModel!.itemname == nil)){
                    UIAlertView(title: l006005, message: l006006, delegate: nil, cancelButtonTitle: uxxx019).show()
                    return
                }
                let albumName = NSString(format: "VoiceDo_%@-%@%@",(processlist?.processname)!,tmpModel!.itemname!,(processlist?.creation_date)!)
                tmpModel!.albumName = albumName as String
            }
            NotificationCenter.default.post(name: Notification.Name(rawValue: kShowProcessItemImagesNotification), object: nil,userInfo:[kShowPhotoAlbumNameKey:tmpModel!.albumName!])
        }
        
        
    }
    func startNextAction(){
        if(self.inputType == kPVDInputTypeUploaded){
            self.finishedAction(true, clearRecoverFlag: false, backToHome: false, uploadFlag: .kResultUpdate ,retryActionType:.kStartNext)
        }else{
            self.finishedAction(true, clearRecoverFlag: false, backToHome: false, uploadFlag: .kFinishedUpload ,retryActionType:.kStartNext)
        }
    }
    
    
    
    func startNextNotificationAction(_ notification:Notification){
        processlist?.processitems?.removeAll()
        resultlist?.items?.removeAll()
        processlist = nil
        resultlist = nil
        
        if(timerCounter != nil){
            timerCounter.invalidate()
            timerCounter = nil
        }
        
        //初期化
        workPlanId = PVDSwiftUtils.getNextWorkPlanId()
        inputType = kPVDInputTypeNew
        let backUpdata =  reportid! + "," + workPlanId + "," + inputType
        PVDSwiftUtils.setKeyChainValueForKey(backUpdata, key: kreportResultDataBackupKey)
        
        if(processlist != nil){
            processlist = nil
        }
        

        processingFlag = false
        processingIndex = 0
        readFinishedSpeechFlag = true
        
        getProcessList()// report list/result listを取得

        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.processingTbl.layer.removeAllAnimations()
                selfWeak.processingTbl.contentOffset = CGPoint(x: 0, y: -selfWeak.processingTbl.contentInset.top);
                selfWeak.processingTbl.reloadData()
            }
        }
        
        
    }
    
    func startNextBtnAction(){
        self.doVoiceCommand(PVDInputcommandType.kStartNextCmd.rawValue)
    }
    
    /**
     完了ボタンが押されたら
     */
    func finishedButtonAction(){
        if(self.inputType == kPVDInputTypeUploaded){
            //完了アップデート
            finishedAction(false,clearRecoverFlag: true,backToHome: true, uploadFlag: .kResultUpdate,retryActionType: .kGoHome)
        }else{
            //自動結果アップロード
            finishedAction(false,clearRecoverFlag: true,backToHome: true, uploadFlag: .kFinishedUpload,retryActionType: .kGoHome)
        }
        
    }
    
    
    

    
    
    func shareWorkUpload(retryCancel:UploadRetryCancleBlock?){
        if(self.inputType == kPVDInputTypeUploaded){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: "再編集した作業結果は交代できない")
            })
            if(retryCancel != nil){
                retryCancel!()
            }
            return
            
        }
        let uxxx020 = String(format: NSLocalizedString("UXXX-020", comment: "エラー"))
        let uxxx021 = String(format: NSLocalizedString("UXXX-021", comment: "ネットワーク接続が 見つかりませんでしたリトライしますか?"))
        let uxxx002 = String(format: NSLocalizedString("UXXX-002", comment: "いいえ"))
        let uxxx003 = String(format: NSLocalizedString("UXXX-003", comment: "はい"))
        let uxxx022 = String(format: NSLocalizedString("UXXX-022", comment: "アップロードURLが正しく設定されていません"))
        let uxxx023 = String(format: NSLocalizedString("UXXX-023", comment: "アップロードファイルが見つかりません"))
        let uxxx024 = String(format: NSLocalizedString("UXXX-024", comment: "引き継ぎファイルアップロード中"))
        let uxxx025 = String(format: NSLocalizedString("UXXX-025", comment: "アップロード成功"))
        let uxxx026 = String(format: NSLocalizedString("UXXX-026", comment: "アップロード失敗"))
        let uxxx029 = String(format: NSLocalizedString("UXXX-029", comment: "異常のレスボンス"))
        let l006013 = String(format: NSLocalizedString("L006-013", comment: "サーバーレスボンス取得失敗"))
        let uxxx006 = String(format: NSLocalizedString("UXXX-006", comment: "認証トークンが設定されていません"))
        if(PVDSwiftUtils.isConnectedToNetwork() == false){
            let alert = UIAlertController(title: uxxx020, message: uxxx021, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: uxxx002, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                //アップロードせずに、次のstepへ(次のstep or next report)
                if(retryCancel != nil){
                    retryCancel!()
                }
            }))
            alert.addAction(UIAlertAction(title: uxxx003, style: UIAlertActionStyle.default, handler: { (UIAlertAction) -> Void in
                self.shareWorkUpload(retryCancel: retryCancel)
            }))
            
            DispatchQueue.main.async(execute: {
                self.present(alert, animated: true, completion: nil)
            })
            return
        }
        //アップロードして、次のstepへ(次のstep or next report)
        if(kworksharefileUploadURL == ""){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: uxxx022)
            })
            if(retryCancel != nil){
                retryCancel!()
            }
            return
        }
        if(gsettingModel.tokenString == nil){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: uxxx006)
            })
            if(retryCancel != nil){
                retryCancel!()
            }
            return
        }

        
        let tokenString =  gsettingModel.tokenString!
        let uploadUrl = kworksharefileUploadURL + "&token=" + (PSRManager.shareInstance() as AnyObject).getMD5(by: tokenString)
        PVDSwiftUtils.writeAccessLog(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>引き継ぎアップロード>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n URL = " + uploadUrl)
        
        var tmpResultFileName:String! =  "/result_" + gsettingModel.deviceid! + "_" + self.workPlanId + ".json"
        tmpResultFileName =  kUnfinishedFolderPath + tmpResultFileName
        if(FileManager.default.fileExists(atPath: tmpResultFileName) == false){
            DispatchQueue.main.async(execute: {
                SVProgressHUD.showError(withStatus: uxxx023)
            })
            if(retryCancel != nil){
                retryCancel!()
            }
            return
        }
        
        SVProgressHUD.show(withStatus: uxxx024)
        print(tmpResultFileName)
        let fileURL = URL(fileURLWithPath: (tmpResultFileName))
        
        alamofireManager.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(fileURL, withName: "work")
        }, to: uploadUrl) { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:リクエスト成功")
                    if(response.result.value != nil){
                        let retDic:NSDictionary = response.result.value as! NSDictionary
                        let retValue = retDic.object(forKey: "result") as? NSNumber
                        if(retValue == 0){
                            PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:" + uxxx025)
                            DispatchQueue.main.async {
                                SVProgressHUD.showSuccess(withStatus: uxxx025)
                            }

                            PVDSwiftUtils.updateWorkShareState(byWorkPlanId: self.workPlanId)
                            self.updateListJsonWithWorkPrimaryID(nil, index: -1,workShareFlag: true)
                            if(gsettingModel.workSharingGoOn == true){
                                
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: kVoiceDoStartNextInputNotification), object: nil)
                            }else{
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: kVoiceReloadHomeUnfinishedTblNotification), object: nil)
                            }
                        }else{
                            PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:" + uxxx026)
                            self.updateListJsonWithWorkPrimaryID(nil, index: -1,workShareFlag: false)
                            DispatchQueue.main.async {
                                SVProgressHUD.showError(withStatus: uxxx026)
                            }
                            if(retryCancel != nil){
                                retryCancel!()
                            }
                        }
                    }else{
                        PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:" + uxxx029)
                        DispatchQueue.main.async {
                            SVProgressHUD.showError(withStatus: uxxx029)
                        }
                        if(retryCancel != nil){
                            retryCancel!()
                        }
                    }
                }
            case .failure(let encodingError):
                PVDSwiftUtils.writeAccessLog("<<引き継ぎアップロード>>:リクエスト失敗 error code:" + String(encodingError._code) + "\n"  + l006013)
                
                self.updateListJsonWithWorkPrimaryID(nil, index: -1,workShareFlag: false)
                DispatchQueue.main.async {
                    SVProgressHUD.showError(withStatus: l006013)
                }
                if(retryCancel != nil){
                    retryCancel!()
                }

            }
            
        }
        
        
        
        

    }

    
    
//暫定2016.10.27
//                       自動up       引き継ぎup     retryActionC 		UploadOKAction
//    完了メッセージの発話		❌			❌		 	❌				❌
//    ホームに戻る発話完了		⭕️			❌		    gohome		    gohome
//    中断発話完了				⭕️->❌		❌		    gohome 	        gohome
//    作業引き継ぎ発話完了*2　	⭕️->❌		⭕️	        ❌				❌
//    次の作業開始発話完了		⭕️			❌   	    startNext		startNext
//    完了ボタン				⭕️			❌		    gohome		    gohome
    
    /**
     ファイル保存してホームに戻る・リカバリフラグクリア
     
     - parameter finishflag:       保存フラグ
     - parameter clearRecoverFlag: リカバリーリセットフラグ(リカバリさせないフラグ)
     - parameter backToHome:       ホームに戻る
     - uploadFlag:　引き継ぎ作業としてアップロード
     */
    func finishedAction(_ finishflag:Bool,clearRecoverFlag:Bool,backToHome:Bool,uploadFlag:UploadServerAction,retryActionType:RetryActionType){
        
        // リカバリフラグをリセットする
        if(clearRecoverFlag == true){
            PVDSwiftUtils.setKeyChainValueForKey("", key: kreportResultDataBackupKey)
        }
        
        // タイムスタンプを更新する
        self.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
        self.resultlist?.operating_time = PVDSwiftUtils.timerIntervalToFormatString(Date().timeIntervalSince1970 - self.reportStartTime,withdecimal: true)
        self.updateResultListEndTime(self.processingIndex,saveresultFlag:false)
        
        // 作業終了時のみ、終了時間を記録する
        if(finishflag == true){
            self.resultlist?.end_time = PVDSwiftUtils.getoutputTimeStamp(Date())
        }
        
        // ファイルを保存する
        let tJSONString = Mapper().toJSONString(self.resultlist!, prettyPrint: true)
        PVDSwiftUtils.saveReulstfile(self.inputType, jsonString: tJSONString!,workplanid: self.workPlanId)
        
        //retry block
        var retryAction:AfterUploadBlock?
        if(retryActionType == .kGoHome){
            // ホームに戻る場合
            retryAction = {
                if(backToHome == true){
                    NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToHomeNotification), object: nil, userInfo: nil)
                }
            }
        }else if(retryActionType == .kStartNext){
            // 次の作業開始する場合
            retryAction = {
                NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoStartNextInputNotification), object: nil)
            }
        }else{
            if(uploadFlag == UploadServerAction.kWorkShareUpload){
                retryAction = {
                    self.processingFlag = false
                    self.processingTbl.reloadData()
                }
            }else{
                retryAction = nil
            }
            
        }
        
        // 作業終了時のみ、未完了作業から完了作業にデータを移動する
        if(finishflag == true){
//            self.resultlist?.end_time = PVDSwiftUtils.getoutputTimeStamp(NSDate())
            print(inputType)
            if((inputType != kPVDInputTypeFinished)&&(inputType != kPVDInputTypeUploaded)){
                //レポートを完了へ保存
                finishReportFile()
                appendlistJsonFile(true)
                PVDSwiftUtils.removejsonFromList(false, tWorkPlanId: workPlanId)
            }
        }
        
        


        //
        //upload action
        if(uploadFlag == UploadServerAction.kFinishedUpload){
            self.updateListJsonWithWorkPrimaryID(nil, index: -1,workShareFlag: false)
            //自動結果アップロード
            if(gsettingModel.autoUpload == true){
                autoUploadResultAction(kFinishedFolderPath, successBlock: {
                    if(retryAction != nil){
                        retryAction!()
                    }
                }, retryCancel: {
                        if(retryAction != nil){
                            retryAction!()
                        }
                })
                return
                
            }else{
                if(retryAction != nil){
                    retryAction!()
                }
            }
            
            
            
        }else if(uploadFlag == UploadServerAction.kWorkShareUpload){//UploadServerAction.kWorkShareUpload
            //引き継ぎアップロード
            let tpfileName = "/result_" + gsettingModel.deviceid! + "_" + workPlanId + ".json"
            let tpfinishedfilePath:String =  kFinishedFolderPath + tpfileName
            if(FileManager.default.fileExists(atPath: tpfinishedfilePath) == true){
                finishedReportMoveBackToUnfinished()
                appendlistJsonFile(false)
                PVDSwiftUtils.removejsonFromList(true, tWorkPlanId: workPlanId)
            }
            shareWorkUpload(retryCancel: { 
                if(retryAction != nil){
                    retryAction!()
                }
            })
        }else if(uploadFlag == UploadServerAction.kResultUpdate){
            let tmpResultFileName:String! =  "/result_" + (self.resultlist?.original_result_id)! + ".json"
            let tmpResultFilePath:String! = kbackupFolder + tmpResultFileName
            //アップロード済をアップデート
            updateResultAction(tmpResultFilePath, successBlock: {
                if(retryAction != nil){
                    retryAction!()
                }
                }, retryCancel: {
                    if(retryAction != nil){
                        retryAction!()
                    }
            })
            return
            
        }else{
            //保存するのみ
            self.updateListJsonWithWorkPrimaryID(nil, index: -1,workShareFlag: false)
        }
        
        //back to home
        if(backToHome == true){
            NotificationCenter.default.post(name: Notification.Name(rawValue: kChangeRootChildToHomeNotification), object: nil, userInfo: nil)
        }

        
    }
    //MARK: UIボタンActions
    
    @IBAction func gobackToHome(_ sender: AnyObject) {

        doVoiceCommand(PVDInputcommandType.kStopCmd.rawValue)
    }
    
    @IBAction func skipBtnAction(_ sender: AnyObject) {
        doVoiceCommand(PVDInputcommandType.kSkipCmd.rawValue)
    }
    
    @IBAction func lastProcessItemBtnAction(_ sender: AnyObject) {
        doVoiceCommand(PVDInputcommandType.kGoBackCmd.rawValue)
    }
    
    
    //Build version 81 use this button as 引き継ぎ
    /**
    
    
    - parameter sender:
    */
    @IBAction func takePhotoBtnAction(_ sender: UIButton) {
        //temperally use as 引き継ぎAction
        doVoiceCommand(PVDInputcommandType.kWorkShareCmd.rawValue)
    }
    
    @IBAction func playAgainBtnAction(_ sender: AnyObject) {
        doVoiceCommand(PVDInputcommandType.kRepeatCmd.rawValue)
    }
    
    //MARK: time count
    func inputTimerCounter(_ timer:Timer){
        
        evenCnt = evenCnt + 1
        if(evenCnt == 100){
            evenCnt = 0
        }
        
        //直接入力自動遷移の場合、5秒以上経過したら自動遷移する
        if((lasttextChangedTime != nil)&&(processingIndex + 1 < processlist?.processitems?.count)&&(Date().timeIntervalSince1970 - lasttextChangedTime > 0.5)){
            let tmpModel = processlist?.processitems?[processingIndex]
            if(tmpModel?.itemType == PVDInputType.kDirectInputG.rawValue){
                self.view.endEditing(true)//直接入力途中でもキーボドを下す
            }
        }
        if(evenCnt % 2 == 0){
            return
        }
        
        if(resultlist == nil){
            print("%s:resultlist access nil",#function)
            return
        }
        
        if(processlist == nil){
            print("%processlist access nil",#function)
            return
        }
        let totalInterval:TimeInterval = Date().timeIntervalSince1970 - self.reportStartTime
        if((processingIndex >= processlist?.processitems?.count)||(processingIndex >= resultlist!.items?.count)){
            PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
                if let selfWeak = self {
                    let totalTimeStr:String = PVDSwiftUtils.timerIntervalToFormatString(totalInterval,withdecimal: false)
                    selfWeak.timeCountLbl.text =  "計" + totalTimeStr
                }
            }
            return
        }
        
        
        let resModel = resultlist?.items?[processingIndex]
        let tmpModel:PVDProcessItemModel = (processlist?.processitems?[processingIndex])!
        if(inspectionStartTime == nil){
            print("%s:item of resultlist index:%d is nil",index,#function)
            return ;
        }
        
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                let passedTimerStr:String!
                if(resModel?.item_operating_time == nil){
                    passedTimerStr = PVDSwiftUtils.timerIntervalToFormatString(Date().timeIntervalSince1970 - selfWeak.inspectionStartTime,withdecimal: false)
                }else{
                    let lastInterval:TimeInterval = PVDSwiftUtils.timerCountStringToTimeInterval((resModel!.item_operating_time)!)
                    passedTimerStr = PVDSwiftUtils.timerIntervalToFormatString(Date().timeIntervalSince1970 - selfWeak.inspectionStartTime + lastInterval,withdecimal: false)
                }
                var defaultTimeStr:String! = ""
                let totalTimeStr:String = PVDSwiftUtils.timerIntervalToFormatString(totalInterval,withdecimal: false)
                
                defaultTimeStr = tmpModel.standarad_operation_time
                if((defaultTimeStr != nil)&&(defaultTimeStr != "")){
                    selfWeak.timeCountLbl.text = "作業" + passedTimerStr + "標準[" + defaultTimeStr + "] 計" + totalTimeStr
                }else{
                    selfWeak.timeCountLbl.text = "作業" + passedTimerStr + "計" + totalTimeStr
                }
            }
        }
    }
    
    //MARK: item time
    /**
     <#Description#>
     
     - parameter index: <#index description#>
     */
    func updateResultListStartTime(_ index:Int){
        if(resultlist == nil){
            print("%s:resultlist access nil",#function)
            return
        }
        if(index >= resultlist!.items?.count){
            print("%s:resultlist access out of bounds",#function)
            return
        }
//        let tmpModel = resultlist?.items?[index]
        self.inspectionStartTime = Date().timeIntervalSince1970
    }
    
    /**
     結果リスト内部の項目の終了時間を更新する
     
     - parameter index: <#index description#>
     - parameter saveresultFlag: <#saveresultFlag description#>
     */
    func updateResultListEndTime(_ index:Int,saveresultFlag:Bool){
        if(resultlist == nil){
            print("%s:resultlist access nil",#function)
            return
        }
        if(index >= resultlist!.items?.count){
            print("\(#function):resultlist access out of bounds,index:\(index)")
            return
        }
        let tmpModel = resultlist?.items?[index]
        if(self.inspectionStartTime == nil){
            print("%s:item of index:%d is nil",index,#function)
            return
        }
        let endTimeStamp:TimeInterval = Date().timeIntervalSince1970

        if(tmpModel?.item_operating_time == nil){
            tmpModel?.item_operating_time = PVDSwiftUtils.timerIntervalToFormatString((endTimeStamp -  self.inspectionStartTime),withdecimal: true)
            
        }else{
            let lastInterval:TimeInterval = PVDSwiftUtils.timerCountStringToTimeInterval((tmpModel?.item_operating_time)!)
            tmpModel?.item_operating_time = PVDSwiftUtils.timerIntervalToFormatString((endTimeStamp -  self.inspectionStartTime + lastInterval),withdecimal: true)
        }
        tmpModel?.item_user_name = gsettingModel.choosedSpeaker
        if(saveresultFlag == true){
            let rJSONString = Mapper().toJSONString(self.resultlist!, prettyPrint: true)
            PVDSwiftUtils.saveReulstfile(self.inputType, jsonString: rJSONString!,workplanid: self.workPlanId)
        }
        
        
    }
    
    
    
    
    
    
    //MARK:   touches methods 
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
//        if((gestureRecognizer.view == selectionBtn) && (gestureRecognizer.isKindOfClass(UISwipeGestureRecognizer))){
//            return false
//        }else{
            return true
//        }
    }
    
   
    func tappedToSelectRow(_ tapRecognizer:UITapGestureRecognizer){
        if((selectionPicker == nil)||(selectionPicker?.selectedRow(inComponent: 0) == nil)){
            return
        }
        if(selectionList == nil){
            return
        }
        let row:Int =  (selectionPicker?.selectedRow(inComponent: 0))!
        let tmpOptionModel:PVDProcessItemOptionModel = selectionList!.object(at: row) as! PVDProcessItemOptionModel
        selectionPicker!.layer.frame = CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: kPickerHeight)
        let tmpModel = resultlist?.items?[processingIndex]
        tmpModel?.result?.value = tmpOptionModel.optionname
        
        //write file
        self.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
        self.resultlist?.operating_time = PVDSwiftUtils.timerIntervalToFormatString(Date().timeIntervalSince1970 - self.reportStartTime,withdecimal: true)
        
        self.updateResultListEndTime(self.processingIndex,saveresultFlag:false)
        let tJSONString = Mapper().toJSONString(self.resultlist!, prettyPrint: true)
        PVDSwiftUtils.saveReulstfile(self.inputType, jsonString: tJSONString!,workplanid: self.workPlanId)
        self.updateListJsonWithWorkPrimaryID(tmpModel?.result?.value, index: self.processingIndex,workShareFlag: false)
        self.processingIndexIncrease(false)
        self.reloadTableAndScroll()
    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        if(gestureRecognizer.isKind(of: UITapGestureRecognizer.self)&&otherGestureRecognizer.isKind(of: UITapGestureRecognizer.self)){
            return true
        }else{
            return false
        }

    }
    
    
    func printGestureTap(_ gestureRecognizer: UIGestureRecognizer){
        if(gestureRecognizer.isKind(of: UITapGestureRecognizer.self)){
            print("printG:UITapGestureRecognizer\n")
        }else if(gestureRecognizer.isKind(of: UIPinchGestureRecognizer.self)){
            print("printG:UIPinchGestureRecognizer\n")
        }else if(gestureRecognizer.isKind(of: UIPanGestureRecognizer.self)){
            print("printG:UIPanGestureRecognizer\n")
        }else if(gestureRecognizer.isKind(of: UISwipeGestureRecognizer.self)){
            print("printG:UISwipeGestureRecognizer\n")
        }else if(gestureRecognizer.isKind(of: UIRotationGestureRecognizer.self)){
            print("printG:UIRotationGestureRecognizer\n")
        }else if(gestureRecognizer.isKind(of: UILongPressGestureRecognizer.self)){
            print("printG:UILongPressGestureRecognizer\n")
        }else{
            print("printG:UnknowGestureRecognizer\n")
        }
    }
    
    
//    -(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
//    // return
//    return true;
//    }
    
    // MARK: - test methods
    
    @IBAction func doTestVoicedoStart(_ sender: AnyObject) {
        
        _ = psrManager.voicedoStartInspection("kubun",detail:"testの認識")
    }
    
    @IBAction func doTestVoicedoStop(_ sender: AnyObject) {
        _ = psrManager.voicedoCloseDic()
    }
    
    @IBAction func touchesGestureAction(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true)
        selectionPicker!.frame = CGRect(x: 0, y: kScreenHeight, width: kScreenWidth, height: kPickerHeight)
        
    }
    
    
    //MARK: - 条件分岐付きindex制御
    /**
     <#Description#>
     
     - parameter onFinishedCheck: 全ての項目が終わったら作業完了状態へ遷移フラグ
     */
    func processingIndexIncrease(_ onFinishedCheck:Bool){
        if(self.processingIndex  < (self.processlist?.processitems?.count)!){
            self.processingIndex = self.processingIndex + 1
            if(self.processingIndex == self.processlist?.processitems?.count){//bound over
                return
            }
        }else{
            return
        }
        //完了チェック、完了した場合
        if((onFinishedCheck == true)&&(finishedCheckWithCondition(checkflag:false) < 0)){//全ての結果が埋まった場合、作業完了状態へ
            self.processingIndex = (self.processlist?.processitems?.count)!
            return
        }
        
        //条件分岐の処理
        let tmpModel = processlist?.processitems?[processingIndex]
        if((tmpModel?.condition == nil)||(tmpModel?.condition![0].expression == nil)){//条件分岐がない
            return
        }
        var targetItem:PVDProcessItemModel? = nil
        var targetIndex:Int = 0
        var index = 0
        for tit in (processlist?.processitems)!{
            if(tit.itemid == tmpModel?.condition![0].itemid){
                targetItem = tit
                targetIndex = index
                break
            }
            index = index + 1
        }
        if(targetItem == nil){
            return
        }
        
        let resModel = self.resultlist?.items?[targetIndex]
        if((resModel?.result?.value == nil)||(resModel?.result?.value == "")){
            processingIndexIncrease(true)//条件式の対象に値がない場合次のindexへ
            return
        }
        let (evaret,comment) = PVDSwiftUtils.evaluateCondition((targetItem?.itemid)!, target_val: (resModel?.result?.value)!, expression: (tmpModel?.condition![0].expression)!)
        print(comment)
        if(evaret == false){//条件を満足しない場合indexを飛ばす
            processingIndexIncrease(true)
        }
    }
    
    
    func processingIndexDecrease(){
        if(processingIndex >= 1){
            processingIndex = processingIndex - 1
        }else{
            return
        }
        
        
        //条件分岐の処理
        let tmpModel = processlist?.processitems?[processingIndex]
        if((tmpModel?.condition == nil)||(tmpModel?.condition![0].expression == nil)){//条件分岐がない
            return
        }
        var targetItem:PVDProcessItemModel? = nil
        var targetIndex:Int = 0
        var index = 0
        for tit in (processlist?.processitems)!{
            if(tit.itemid == tmpModel?.condition![0].itemid){
                targetItem = tit
                targetIndex = index
                break
            }
            index = index + 1
        }
        if(targetItem == nil){
            return
        }
        
        let resModel = self.resultlist?.items?[targetIndex]
        if((resModel?.result?.value == nil)||(resModel?.result?.value == "")){
            processingIndexDecrease()
            return 
        }
        let (evaret,comment) = PVDSwiftUtils.evaluateCondition((targetItem?.itemid)!, target_val: (resModel?.result?.value)!, expression: (tmpModel?.condition![0].expression)!)
        print(comment)
        if(evaret == false){
            processingIndexDecrease()
        }
    }

    
    
    // MARK: - Notifications
    func keyboardShown(_ notification: Notification) {
        let info  = notification.userInfo!
        let value: AnyObject = info[UIKeyboardFrameEndUserInfoKey]! as AnyObject
        
        let rawFrame = value.cgRectValue
        let keyboardFrame = view.convert(rawFrame!, from: nil)
        mheightOfKeyBoard = keyboardFrame.height
        
    }
    
    func textFieldBegan(_ notification: Notification){
        let theTextField:UITextField? = notification.object as? UITextField
        if(inputAccessoryView == nil){
            tinputAccessoryView = UIView(frame: CGRect(x: 0,y: 0,width: kScreenWidth,height: 1))
        }
        theTextField?.inputAccessoryView = tinputAccessoryView
        self.perform(#selector(PVDInputController.forceKeyboard), with: nil, afterDelay: 0)
    }

    func forceKeyboard(){
        if(mheightOfKeyBoard != 0){
            tinputAccessoryView.superview?.frame = CGRect(x: 0, y: kScreenHeight - mheightOfKeyBoard, width: kScreenWidth, height: mheightOfKeyBoard)
        }else{
            tinputAccessoryView.superview?.frame = CGRect(x: 0, y: 759, width: 768, height: 265)
        }
        
    }
    

    /**
    自由入力中断呼び出し
    
    - parameter notification: <#notification description#>
    */
//    func stopfreeInputAction(_ notification: Notification) {
//        if(self.processingIndex  < self.processlist?.processitems?.count){
//            self.processingIndexIncrease(true)
//            self.updateResultListStartTime(self.processingIndex)
//        }
//        self.processingFlag = false
//        self.reloadTableAndScroll()
//    }
    
    //audio 中断呼び出し
    func audioSessionInterrupted(_ notification: Notification) {
        //println("Interrupt")
        if let userInfos = notification.userInfo {
            if let type = userInfos["AVAudioSessionInterruptionTypeKey"] as? NSNumber {
//                if type is NSNumber {
                    if type.uintValue == AVAudioSessionInterruptionType.began.rawValue{
                        print("Began")
                    }
                    if type.uintValue == AVAudioSessionInterruptionType.ended.rawValue{
                        print("Ended")
                        startSiriProcessing()
                    }
//                }
            }
        }
    }

    /**
     認識結果受け取る通知
     
     - parameter notification: 通知内容
     */
    func receivedInpectionResultAction(_ notification:Notification){
        let userInfo:NSDictionary = notification.userInfo! as NSDictionary
        let result:NSString = PVDSwiftUtils.getSafeStringFromAnyObject(userInfo.object(forKey: kResultKey) as AnyObject) as NSString
        if(result.length > 0){
            NSLog("認識成功,result:%@",result)
            regonisationAction(result)
            
        }else{
            NSLog("認識失敗")
        }
        
        
    }
    
    /**
     カメラ撮影から戻り、認識を再開
     
     - parameter notification: 通知内容
     */
    func cameraFinishedAction(_ notification:Notification){
        inSubViewEventFlag = false
        readFinishedSpeechFlag = true
        self.processingFlag = false
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.reloadTableAndScroll()
            }
            
        }
    }
    
    /**
     読み上げのないリフレッシュs
     */
    func doCommandReloadTable(){
        //中断、完了の場合は画面遷移の通知を出す
        print("doTableRefresh")
        //完了メッセージの発話をONにする
        readFinishedSpeechFlag = true
        self.processingFlag = false
        
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.view.endEditing(true)
                selfWeak.processingTbl.reloadData()
            }
        }
    }
    
    
    /**
     読み上げ+画面遷移
     */
    func reloadTableAndScroll(){
        readFinishedSpeechFlag = true
        self.processingFlag = false
        
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.view.endEditing(true)
                
                let tmpIndex:IndexPath!
                
                var scrollTargetIndex:Int!
                
                if(gsettingModel.inputScrolToTopFlag == false){
                    scrollTargetIndex =  selfWeak.processingIndex
                    
                }else{
                    scrollTargetIndex = selfWeak.processingIndex - 1
                }
                if(scrollTargetIndex < 0){
                    scrollTargetIndex = 0
                }
                if(scrollTargetIndex >= selfWeak.processlist?.processitems?.count){
                    scrollTargetIndex = (selfWeak.processlist?.processitems?.count)! - 1
                }
                
                tmpIndex = IndexPath(row: scrollTargetIndex, section: 0)
                
                
                
                //画像でのスクーロル対応で二回りロード、一回目は画像が表示されるセルの高さがかわる、二回目は変わった高さで指定の位置にスクロールする
                selfWeak.processingTbl.reloadData()
                selfWeak.processingTbl.layoutIfNeeded()
                print("selfWeak.processingIndex:" + String(selfWeak.processingIndex))
                print("selfWeak.processlist?.processitems?.count:" + String(describing: selfWeak.processlist?.processitems?.count))
                if(selfWeak.processingIndex <= selfWeak.processlist?.processitems?.count){
                    selfWeak.processingTbl.scrollToRow(at: tmpIndex, at: UITableViewScrollPosition.top, animated: true)
                }
                
            }
        }
    }
    
    func receivedScanAction(_ notification:Notification){
        inSubViewEventFlag = false
        readFinishedSpeechFlag = true
        var userinfo:NSDictionary? = nil
        var metaData:String? = nil
        if(notification.userInfo != nil){
            userinfo = notification.userInfo! as NSDictionary
            metaData = userinfo!.object(forKey: kScanCodeKey) as? String
        }
        
        DispatchQueue.main.async(execute: { [weak self]() -> Void in
            if let selfWeak = self {
                
                if(metaData != nil){
                    
                    if(selfWeak.processingIndex < selfWeak.resultlist?.items?.count){
                        let tmpreulstModel = selfWeak.resultlist?.items?[selfWeak.processingIndex]
                        
                        tmpreulstModel?.result?.value = metaData
                    }
                    selfWeak.updateResultListStartTime(selfWeak.processingIndex)
                    //write file
                    selfWeak.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
                    let tJSONString = Mapper().toJSONString(selfWeak.resultlist!, prettyPrint: true)
                    PVDSwiftUtils.saveReulstfile(selfWeak.inputType, jsonString: tJSONString,workplanid: selfWeak.workPlanId)
                    
                    selfWeak.updateListJsonWithWorkPrimaryID(metaData, index: (self?.processingIndex)!,workShareFlag: false)
                    
                    
                }
                if(selfWeak.processingIndex  < selfWeak.processlist?.processitems?.count){
                    selfWeak.processingIndex = selfWeak.processingIndex + 1
                    selfWeak.updateResultListStartTime(selfWeak.processingIndex)
                }
                selfWeak.processingTbl.reloadData()
                PVDSwiftUtils.dispatchAfterMain(1, afterBlock: { (Void) in
                    selfWeak.reloadTableAndScroll()
                })
                
            }
        })
        
    }
    
    //MARK: cell delegate 
    func inputDidBeginEditing(_ textField: UITextField){
        texthasBeenEditflag = false
    }
    
    func inputViewDidBeginEditing(_ textView: UITextView){
        texthasBeenEditflag = false
    }
    
    func inputViewShouldBeginEditing(_ textView: UITextView) -> Bool{
        return true
    }
    
    func inputDidChangedValue(_ textField: UITextField){
        texthasBeenEditflag = true
        
        let tmpModel = processlist?.processitems?[processingIndex]
        
        if(tmpModel?.itemType == PVDInputType.kDirectInputG.rawValue){
            lasttextChangedTime = Date().timeIntervalSince1970
            if(directinputClearFlag == true){
                directinputClearFlag = false
                textField.text = ""
            }
        }else{
            lasttextChangedTime = nil
        }
        
        
    }
    
    func inputViewDidChangedValue(_ textView: UITextView){
        texthasBeenEditflag = true
    }
    
    
    //normal cell
    func inputDidEndEditing(_ textField: UITextField){
        if(textField.isFirstResponder == false){
            if(self.processingIndex < self.processlist?.processitems?.count){
                let tmpModel = resultlist?.items?[self.processingIndex]
                if(texthasBeenEditflag == true){
                    tmpModel?.result?.value = textField.text
                    
                    //write file
                    if(self.resultlist != nil){
                        self.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
                        
                        self.updateResultListEndTime(self.processingIndex,saveresultFlag:false)
                        let tJSONString = Mapper().toJSONString(self.resultlist!, prettyPrint: true)
                        PVDSwiftUtils.saveReulstfile(self.inputType, jsonString: tJSONString!,workplanid: self.workPlanId)
                    }
                    self.updateListJsonWithWorkPrimaryID(tmpModel?.result?.value, index: self.processingIndex,workShareFlag: false)

                    self.processingIndexIncrease(true)
                    self.reloadTableAndScroll()
                }
                
            }
        }
        
    }
    
    
    //free input cell not in use
    func inputViewDidEndEditing(_ textView: UITextView){
        if(textView.isFirstResponder == false){
            if(self.processingIndex < self.processlist?.processitems?.count){
                let tmpModel = resultlist?.items?[self.processingIndex]
                
                if(texthasBeenEditflag == true){
                    tmpModel?.result?.value = textView.text
                    
                    //write file
                    if(self.resultlist != nil){
                        self.resultlist?.file_changed_time = PVDSwiftUtils.getoutputTimeStamp(Date())
                        //手入力の時の時間更新
                        self.updateResultListEndTime(self.processingIndex,saveresultFlag:false)
                        let tJSONString = Mapper().toJSONString(self.resultlist!, prettyPrint: true)
                        PVDSwiftUtils.saveReulstfile(self.inputType, jsonString: tJSONString!,workplanid: self.workPlanId)
                    }
                    self.updateListJsonWithWorkPrimaryID(tmpModel?.result?.value, index: self.processingIndex,workShareFlag: false)
                    self.processingIndexIncrease(true)
                    self.reloadTableAndScroll()
                    
                }
                
            }

        }
    }
    
    //MARK: pickerview delegate,datasource
    /**
    * ピッカーに表示する列数を返す
    */
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    /**
     * ピッカーに表示する行数を返す
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        if(self.selectionList != nil){
            return self.selectionList!.count
        }else{
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat{
        return self.adjustHeight
    }
    
    
    
    /**
     * 行のサイズを変更
     */
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat{
        return kScreenWidth
    }
    
    
    /**
     * ピッカーに表示する値を返す
     */
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var reuseView:UILabel
        if(view == nil){
            reuseView = UILabel(frame: CGRect(x: 0,y: 0,width: kScreenWidth,height: pickerView.rowSize(forComponent: component).height))
            reuseView.textAlignment = .center
            reuseView.backgroundColor = UIColor.lightGray
        }else{
            reuseView = view as! UILabel
        }
        if(self.selectionList != nil){
            let tmpModel:PVDProcessItemOptionModel = selectionList!.object(at: row) as! PVDProcessItemOptionModel
            reuseView.text = tmpModel.optionname
        }
        reuseView.font = cellfont
        return reuseView
        
    }
    
    
    
    
    
    /**
     * ピッカーの選択行が決まったとき
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
         print("was selected")
    }

  
    
}
