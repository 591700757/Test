//
//  NoiseAdjustController.swift
//  VoiceDo
//
//  Created by ying.zhang on 2016/06/07.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import ObjectMapper
import SVProgressHUD


class PVDNoiseAdjustController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    @IBOutlet weak var noiseAdjustTbl: UITableView!
    var emodellist:PVDEnvironmentListModel?
    var selectedIndex:Int!
    var changedFlag:Bool?
    //MARK: - life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        noiseAdjustTbl.delegate = self
        noiseAdjustTbl.dataSource = self
        noiseAdjustTbl.tableHeaderView = UIView()
        noiseAdjustTbl.tableFooterView = UIView()
        noiseAdjustTbl.separatorStyle = .none
        changedFlag = false
        let environmentDic:NSDictionary? = PVDSwiftUtils.getDictionarybyFullPath(kpathForEnvironmentJson)
//        emodellist =  Mapper<PVDEnvironmentListModel>().map(environmentDic)
        emodellist =  Mapper<PVDEnvironmentListModel>().map(JSON: environmentDic as! [String : Any])
        (PSRManager.shareInstance() as AnyObject).voicedoStopInspection()

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        selectedIndex = -1
        if(emodellist?.items == nil){
            return
        }
        var ii:Int = 0
        for emodel in (emodellist?.items)!{
            if(emodel.file_name == gsettingModel.chosedEnv){
                selectedIndex = ii
                break
            }
            ii = ii + 1
        }
        noiseAdjustTbl.reloadData()
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }
    
    //MARK: - xib methods
    
    @IBAction func closeControllerAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
        

    }

    
    //MARK: - tableview delegate
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        if((emodellist != nil) && (emodellist?.items != nil)){
            return (emodellist?.items?.count)!
        }else{
            return 0
        }
    }
    
    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell: PVDNoiseAdjustCell? = tableView.dequeueReusableCell(withIdentifier: kPVDNoiseAdjustCellID, for: indexPath) as? PVDNoiseAdjustCell
        cell?.selectionStyle = .none
        let item:PVDEnvironmentModel = (emodellist?.items![indexPath.row])!
        cell?.cellTitle.text = item.env_title
        if(indexPath.row == selectedIndex){
            cell!.checkBtn.setBackgroundImage(UIImage(named: "icon_checkmark2"), for: UIControlState())
        }else{
            cell?.checkBtn.setBackgroundImage(UIImage(named: "icon_uncheckmark2"), for: UIControlState())
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let l011001 = NSLocalizedString("L011-001", comment: "")
        let uxxx066 = NSLocalizedString("UXXX-066", comment: "")
        tableView.deselectRow(at: indexPath, animated: true)
        let item:PVDEnvironmentModel = (emodellist?.items![indexPath.row])!
        let settingPath = kLibDomainPath + "/" + item.file_name!
        if((item.file_name == nil)||(FileManager.default.fileExists(atPath: settingPath) == false)){
            DispatchQueue.main.async(execute: { 
                SVProgressHUD.showError(withStatus: l011001)
            })
            return
        }
        //sr.iniを更新する
        let ret =  PVDSwiftUtils.modifySRinibySettingFile(settingPath)
        if(ret == false){
            DispatchQueue.main.async(execute: { 
                SVProgressHUD.showError(withStatus: uxxx066)
            })
            return
        }
        
        gsettingModel.chosedEnv = item.file_name!
        gsettingModel.envDetail = item.env_title
        PVDSwiftUtils.saveSettingFile()
        changedFlag = true
        
        let enginePath   = PVDSwiftUtils.getEngineSettingFilePath()
        //エンジン再起動
        (PSRManager.shareInstance() as AnyObject).voicedoClose()
        gInspectInitResult = (PSRManager.shareInstance() as AnyObject).voicedoInit(PVDSwiftUtils.getShareContainerDomainPath(), iniUrl: enginePath)
        (PSRManager.shareInstance() as AnyObject).voicedoOpenDic(NSHomeDirectory().stringByAppendingPathComponent(kHomeDicFile))
        let choosedSpeakerfullfilePath =  (NSHomeDirectory() as NSString).appendingPathComponent(gsettingModel.choosedSpeakerfilePath!)
        (PSRManager.shareInstance() as AnyObject).voicedoSetUser(choosedSpeakerfullfilePath)
        (PSRManager.shareInstance() as AnyObject).voicedoStartInspection(kHomeRule,detail:"ホームの認識")
        
        selectedIndex = indexPath.row
        DispatchQueue.main.async { 
            self.noiseAdjustTbl.reloadData()
        }
    }
    
    

}
