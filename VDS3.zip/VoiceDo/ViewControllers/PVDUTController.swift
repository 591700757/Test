//
//  PVDUTController.swift use to uint test
//  VoiceDo
//
//  Created by ying.zhang on 2016/06/03.
//  Copyright © 2016年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDUTController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    
}
