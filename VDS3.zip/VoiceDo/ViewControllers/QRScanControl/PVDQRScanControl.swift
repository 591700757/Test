//
//  PVDQRScanControl.swift
//  VoiceDo
//
//  Created by user2 on 2015/10/28.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import AVFoundation
import SVProgressHUD

class PVDQRScanControl: UIViewController,PVDQRCodeReaderDelegate {

    @IBOutlet weak var controlPannel: UIView!
    @IBOutlet weak var scanerView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        PVDQRReader.sharedInstance.delegate = self
        PVDQRReader.sharedInstance.startReaderOnView(scanerView,pannel: controlPannel,camera:AVCaptureDevicePosition.back,firstIn: true)

    }
    
    func turnByBound(){
        let size:CGSize  = UIScreen.main.bounds.size
        if size.width < size.height {
            PVDQRReader.sharedInstance.captureVideoPreviewLayer.frame = CGRect(x: 0, y: 0, width: kScreenWidth, height: kScreenHeight - controlPannel.frame.height - 20)
        } else if size.width > size.height{
            PVDQRReader.sharedInstance.captureVideoPreviewLayer.frame = CGRect(x: 0, y: 0, width: kScreenHeight, height: kScreenWidth - controlPannel.frame.height - 20)
        }
        
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        super.viewWillTransition(to: size, with: coordinator)
//        if size.width < size.height {
//            PVDQRReader.sharedInstance.captureVideoPreviewLayer.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight - controlPannel.frame.height - 20)
//        } else if size.width > size.height{
//            PVDQRReader.sharedInstance.captureVideoPreviewLayer.frame = CGRectMake(0, 0, kScreenHeight, kScreenWidth - controlPannel.frame.height - 20)
//        }
        var tpsize:CGSize  = UIScreen.main.bounds.size
        tpsize.height = tpsize.height - controlPannel.frame.height - 20
        PVDQRReader.sharedInstance.captureVideoPreviewLayer.frame = CGRect(x: 0, y: 0, width: tpsize.width, height: tpsize.height)
        
//        [previewLayerConnection setVideoOrientation:[[UIApplication sharedApplication] statusBarOrientation]]
//        PVDQRReader.sharedInstance.captureVideoPreviewLayer.connection.videoOrientation = PVDQRReader.sharedInstance.transformOrientation(UIInterfaceOrientation(rawValue: UIApplication.sharedApplication().statusBarOrientation.rawValue)!)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NSLog("%d,%d",scanerView.frame.width,scanerView.frame.height)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDQRScanControl.closeAction(_:)), name: NSNotification.Name(rawValue: kVoiceDoQRCodeScanCloseNotification), object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceDoQRCodeScanCloseNotification), object: nil)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func changeToFontCamera(){
    
    }
    
    
    //MARK: delegate methods
    func didDetectQRCode(_ metaObject:AVMetadataMachineReadableCodeObject){
//        let msg = "Detected a QR code! type:" + metaObject.type + metaObject.stringValue
//        NSLog("detected code,type" + metaObject.type + "," + msg)
        let title = String(format: NSLocalizedString("L001-003", comment: "コード読み込み失敗"))
        
        if((metaObject.type == nil)||(metaObject.stringValue == nil)||(metaObject.stringValue == "")||(metaObject.type == "")){
            let tmpAlert = UIAlertView(title: title, message: nil, delegate: nil, cancelButtonTitle: nil)
            tmpAlert.show()
            PVDSwiftUtils.dispatchAfterMain(1, afterBlock: { (Void) -> Void in
                tmpAlert.dismiss(withClickedButtonIndex: 0, animated: true)
            })
            return
        }
        
        PVDQRReader.sharedInstance.stopReader()
        PVDSwiftUtils.dispatch_async_main { () -> () in
            self.dismiss(animated: true) { () -> Void in
                NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoQRCodeScanNotification), object: nil, userInfo: [kScanCodeKey:metaObject.stringValue])
            }

        }
        
    }

    @IBAction func exchangeCameraAction(_ sender: UIButton) {
        let fontString = String(format: NSLocalizedString("L001-001", comment: ""))
        let backString = String(format: NSLocalizedString("L001-002", comment: ""))
        if(sender.title(for: UIControlState()) == fontString){
            sender.setTitle(backString, for: UIControlState())
            PVDQRReader.sharedInstance.stopReader()
            PVDQRReader.sharedInstance.startReaderOnView(scanerView,pannel: controlPannel,camera:AVCaptureDevicePosition.front,firstIn: false)
        }else{
            sender.setTitle(fontString, for: UIControlState())
            PVDQRReader.sharedInstance.stopReader()
            PVDQRReader.sharedInstance.startReaderOnView(scanerView,pannel: controlPannel,camera:AVCaptureDevicePosition.back,firstIn: false)
        }
//        turnByBound()
    }
    @IBAction func closeAction(_ sender: AnyObject) {
        PVDQRReader.sharedInstance.stopReader()
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.dismiss(animated: true, completion: { () -> Void in
                    NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoQRCodeScanNotification), object: nil, userInfo: nil)
                })
            }
            
            
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
