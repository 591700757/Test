//
//  PVDRootViewController.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/16.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit
import AssetsLibrary
import Photos
import AudioToolbox
import SVProgressHUD
import ObjectMapper


class PVDRootViewController: UIViewController  ,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    var containerViewController:PVDRootContainerController!
    var assetLib:ALAssetsLibrary!
    var logCnt:Int32 = 0
    var photoAssets = [PHAsset]()
    let photoPicker:UIImagePickerController = UIImagePickerController()
    var takePhotoBtn:UIButton!
    var cancelPhotoBtn:UIButton!
    var toverlayView:UIView!
    var iconTimer:Timer!
    var inspectionRunningFlag:Bool!
    var lightCnt:Int32! = 0
    var heavyCnt:Int32! = 0
    @IBOutlet weak var showStatusLogBtn: UIButton!
    @IBOutlet weak var mikeIconImage: UIImageView!
    @IBOutlet weak var logView: UITextView!
    
    @IBOutlet weak var stopVoiceInspectionBtn: UIButton!
    
//    @IBOutlet weak var touchInputBtn: UIButton!
    
    @IBOutlet weak var stopImage: UIImageView!
    // MARK: - lifecycle

    
    @IBOutlet weak var levelMeter: UIProgressView!
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: Bundle!) {
        super.init(nibName: nil, bundle: nil)
        
    }
    
    convenience init() {
        self.init(nibName: nil, bundle: nil)
    }
    
    deinit{
        
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lightCnt = 0
        self.heavyCnt = 0
        
        //reportURL　レポートダウンロード
        kReportFileDownloadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/"
        kReportFileDownloadURL = kReportFileDownloadURL + gsettingModel.serverPath! + "/downloadFile.php?type=report&id=" + gsettingModel.userid!
        
        //speakerURL　話者ファイルダウンロード
        kSpearkFileDownloadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/"
        kSpearkFileDownloadURL = kSpearkFileDownloadURL + gsettingModel.serverPath! + "/downloadFile.php?type=speaker&id=" + gsettingModel.userid!
        
        //kresultUploadURL　結果アップロード
        kresultUploadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kresultUploadURL = kresultUploadURL  + "/uploadResult.php?id=" + gsettingModel.userid! + "&deviceid=" + gsettingModel.deviceid!
        
        //kupdateResultURL  結果アップデート
        kupdateResultURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kupdateResultURL = kupdateResultURL  + "/updateResult.php?id=" + gsettingModel.userid! + "&deviceid=" + gsettingModel.deviceid!
        
        //kinitFileDownloadURL 初期ファイルダウンロード
        kinitFileDownloadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kinitFileDownloadURL = kinitFileDownloadURL + "/downloadIni.php?id=" + gsettingModel.userid!
        
        //作業引き継ぎアップロード
        kworksharefileUploadURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! + "/" + gsettingModel.serverPath!
        kworksharefileUploadURL = kworksharefileUploadURL + "/uploadWork.php?id=" + gsettingModel.userid! + "&deviceid=" + gsettingModel.deviceid!
        
        //作業引き継ぎダウンロード
        kworksharefileDownURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! +   "/" + gsettingModel.serverPath!
        kworksharefileDownURL = kworksharefileDownURL + "/downloadWork.php?id=" + gsettingModel.userid!
        
        //トークン検証
        ktokenCheckURL = gsettingModel.ipAddress! + ":" + gsettingModel.port! +  "/" + gsettingModel.serverPath!
        ktokenCheckURL = ktokenCheckURL + "/checkAuth.php?id=" + gsettingModel.userid!

        
        assetLib = ALAssetsLibrary()
        // Do any additional setup after loading the view.
        logView.layer.borderColor = UIColor(red:111/255.0, green: 113/255.0, blue: 121/255.0, alpha: 1.0).cgColor
        logView.layer.borderWidth = 1

        let l005001 = String(format: NSLocalizedString("L005-001", comment: ""))
        let uxxx018 = String(format: NSLocalizedString("UXXX-018", comment: ""))

        logView.textColor = UIColor(red:111/255.0, green: 113/255.0, blue: 121/255.0, alpha: 1.0)

        toverlayView = UIView()
        toverlayView.frame = self.view.bounds
        takePhotoBtn = UIButton(frame: CGRect(x: kScreenWidth/2 - 30 , y: kScreenHeight - 130, width: 60, height: 60))
        cancelPhotoBtn = UIButton(frame: CGRect(x: kScreenWidth - 70, y: takePhotoBtn.frame.origin.y, width: 60, height: 60))

        takePhotoBtn.backgroundColor = UIColor.clear
        let takePhotoLbl:UILabel = UILabel(frame: CGRect(x: takePhotoBtn.frame.origin.x, y: takePhotoBtn.frame.maxY+5 , width: takePhotoBtn.frame.width, height: 21))
        takePhotoLbl.text = l005001
        takePhotoLbl.textAlignment = .center
        takePhotoLbl.textColor = UIColor.white
        let cancelLbl:UILabel = UILabel(frame: CGRect(x: cancelPhotoBtn.frame.origin.x, y: cancelPhotoBtn.frame.maxY+5 , width: cancelPhotoBtn.frame.width, height: 21))
        cancelLbl.text = uxxx018
        cancelLbl.textAlignment = .center
        cancelLbl.textColor = UIColor.white
        cancelPhotoBtn.setBackgroundImage(UIImage(named: "icon_close"), for: UIControlState())
        takePhotoBtn.setBackgroundImage(UIImage(named: "icon_takePhoto"), for: UIControlState())
        takePhotoBtn.setTitleColor(UIColor.black, for: UIControlState())
        toverlayView.backgroundColor = UIColor.clear
        cancelPhotoBtn.setTitleColor(UIColor.black, for: UIControlState())
        cancelPhotoBtn.addTarget(self, action: #selector(PVDRootViewController.cancelPhotoAction(_:)), for: UIControlEvents.touchUpInside)
        toverlayView.addSubview(takePhotoBtn)
        takePhotoBtn.addTarget(self, action: #selector(PVDRootViewController.takePhotoAction(_:)), for: UIControlEvents.touchUpInside)
        toverlayView.addSubview(cancelPhotoBtn)
        toverlayView.addSubview(takePhotoLbl)
        toverlayView.addSubview(cancelLbl)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kReturnToNormalModeNotification), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.tryReturnToNormalMode), name: NSNotification.Name(rawValue: kReturnToNormalModeNotification), object: nil)
        

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let inspectPauseflag:String? = UserDefaults.standard.object(forKey: kHVDWaitModeOnFlagKey) as? String
        if((inspectPauseflag != nil)&&(inspectPauseflag! == "true")){
            self.stopVoiceInspectionBtn.setTitle("入力待ち", for: UIControlState())
            self.stopImage.image = UIImage(named: "icon_wait")
            UserDefaults.standard.set("true", forKey: kHVDWaitingFlagKey)
            UserDefaults.standard.synchronize()
        }else{
            self.stopVoiceInspectionBtn.setTitle("通常認識", for: UIControlState())
            self.stopImage.image = UIImage(named: "icon_nowait")
        }
    }
    
    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        iconTimer = Timer.scheduledTimer( timeInterval: 0.1, target: self, selector: #selector(PVDRootViewController.iconFlashTimer(_:)), userInfo: nil, repeats: true)
        inspectionRunningFlag = false
        (PSRSoundRec.shareInstance() as AnyObject).onshowMeterBlock { (level:CGFloat) -> Void in
           
            let levelValue:Float = Float(level)
            if(levelValue > 0){
                PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
                    if let selfWeak = self {
                        selfWeak.levelMeter.setProgress((levelValue * 5)/LEVEL_MAX, animated: false)
                    }
                }
            }
        }
        
            
        
        //Notification
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.refreshLogAction(_:)), name: NSNotification.Name(rawValue: kSetLogTextNotification), object: nil)//show log
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.showProcessItemPhotos(_:)), name: NSNotification.Name(rawValue: kShowProcessItemImagesNotification), object: nil)//show image
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.changeRootChildToInputAction(_:)), name: NSNotification.Name(rawValue: kChangeRootChildToInputNotification), object: nil)//home -> input notification
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.changeRootHomeToInputAction(_:)), name: NSNotification.Name(rawValue: kChangeRootChildToHomeNotification), object: nil)//input -> home notification
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.meterChangeNotificationAction(_:)), name: NSNotification.Name(rawValue: kMeterChangeNotification), object: nil)//meter changed notification
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.rootShowCameraAction(_:)), name: NSNotification.Name(rawValue: kRootShowCameraNotification), object: nil)//showCamera notification

        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.voiceTakePhoto(_:)), name: NSNotification.Name(rawValue: kVoiceTakePhotoNotification), object: nil)//showCamera notification
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.cancelPhotoAction(_:)), name: NSNotification.Name(rawValue: kVoiceTakePhotoCancelNotification), object: nil)//showCamera notification
//        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(PVDRootViewController.applicationWillEnterForegroundAction(_:)), name: UIApplicationWillEnterForegroundNotification, object: nil)//applicationEnterForeground
//        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(PVDRootViewController.applicationDidEnterBackgroundAction(_:)), name: UIApplicationDidEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.voicedoGlobalInspectionRestartAction(_:)), name: NSNotification.Name(rawValue: kVoiceDoInSpectionRestartToRootNotification), object: nil)//voice do Inspection restart at root
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.voicedoGlobalInspectionPauseAction(_:)), name: NSNotification.Name(rawValue: kVoiceDoInSpectionPauseToRootNotification), object: nil)//applicationEnterForeground
        NotificationCenter.default.addObserver(self, selector: #selector(PVDRootViewController.aVAudioSessionMediaServicesWereResetNotificationAction(_:)), name: NSNotification.Name(rawValue: "AVAudioSessionMediaServicesWereResetNotification"), object: nil)//media reset detected
        

       
        
        

    }

    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        iconTimer.invalidate()
        iconTimer = nil
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kSetLogTextNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kShowProcessItemImagesNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kChangeRootChildToInputNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kChangeRootChildToHomeNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kMeterChangeNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kRootShowCameraNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceTakePhotoNotification), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceTakePhotoCancelNotification), object: nil)
//        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIApplicationWillEnterForegroundNotification, object: nil)
//        NSNotificationCenter.defaultCenter().removeObserver(self, name: kVoiceDoInSpectionRestartToRootNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: kVoiceDoInSpectionPauseToRootNotification), object: nil)
        
        
        
    }

    
    override func viewDidLayoutSubviews() {
        logView.contentInset = UIEdgeInsetsMake(-5, 0, 0, 0)
//        stopVoiceInspectionBtn.layer.borderColor = UIColor.grayColor().CGColor
//        stopVoiceInspectionBtn.layer.borderWidth = 1
        
    }
    
    func tryReturnToNormalMode(){
        if(stopVoiceInspectionBtn.title(for: UIControlState()) == "入力待ち"){
            SpeechTalkManager.sharedInstance.mskipCnt = 1
            NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil, userInfo: nil)
            PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
                if let selfWeak = self {
                    selfWeak.stopVoiceInspectionBtn.setTitle("通常認識", for: UIControlState())
                    selfWeak.stopImage.image = UIImage(named: "icon_nowait")
                    UserDefaults.standard.set("false", forKey: kHVDWaitModeOnFlagKey)//key voicedo on
                    UserDefaults.standard.set("false", forKey: kHVDWaitingFlagKey)//true:wait rule
                    UserDefaults.standard.synchronize()
                    
                }
                SVProgressHUD.showInfo(withStatus: "Dump再生で入力モードを解除しました")
            }
            
        }
    }
    
    
    
    let grayImage:UIImage! = UIImage(named: "icon_MikeGray")
    let mikeImage:UIImage! = UIImage(named: "icon_Mike")
    
    // MARK: xib methods
    
    @IBAction func updateSaveFlagAction(_ sender: UIButton) {
        let chosedDumpMode:String? = UserDefaults.standard.object(forKey: kSaveRecordDumpKey) as? String
        if(chosedDumpMode != kDumpChoiceChoosedDump){
            return
        }else{
            PVDDatabaseAccess.sharedInstance.updateRecordSaveFlag()
        
        }
        
        
        
    }

    @IBAction func inspectionStopAction(_ sender: UIButton) {
        
        if(sender.title(for: UIControlState()) == "入力待ち"){
#if _STOPRECOGANDRECOVER
            //認識一時停止
            self.stopInspectionAtRoot()
#else
            //Hey VoiceDoモード

    SpeechTalkManager.sharedInstance.mskipCnt = 1
    NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil, userInfo: nil)
    PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
        if let selfWeak = self {
            selfWeak.stopVoiceInspectionBtn.setTitle("通常認識", for: UIControlState())
            selfWeak.stopImage.image = UIImage(named: "icon_nowait")
            UserDefaults.standard.set("false", forKey: kHVDWaitModeOnFlagKey)//key voicedo on
            UserDefaults.standard.set("false", forKey: kHVDWaitingFlagKey)//true:wait rule
            UserDefaults.standard.synchronize()
            
        }
    }
    
    
    


#endif
        }else{
#if _STOPRECOGANDRECOVER
            self.restartInspectionAtRoot()
#else
    
    SpeechTalkManager.sharedInstance.mskipCnt = 1
    NotificationCenter.default.post(name: Notification.Name(rawValue: kVoiceDoInSpectionResumeToChildViewNotification), object: nil, userInfo: nil)
    PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
        if let selfWeak = self {
            selfWeak.stopVoiceInspectionBtn.setTitle("入力待ち", for: UIControlState())
            selfWeak.stopImage.image = UIImage(named: "icon_wait")
            UserDefaults.standard.set("true", forKey: kHVDWaitModeOnFlagKey)//key voicedo on
            UserDefaults.standard.set("true", forKey: kHVDWaitingFlagKey)//true:wait rule
            UserDefaults.standard.synchronize()
            
        }
    }

#endif
            
        }
    }
    
    @IBAction func swapButtonPressed(_ sender: AnyObject) {
        self.containerViewController.swapViewControllers(nil)
    }
    

    /**
    共有の認識パネルの点滅動画を止める＋ボタンのテキスト変更＋認識一時停止フラグのON
    */
    @IBAction func showBackLogAction(_ sender: UIButton) {
        let tpStoryBoard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
        gsettingModel.showingModelViewflag = true
        self.stopInspectionAtRoot()
        self.present(tpStoryBoard.instantiateViewController(withIdentifier: "PVDBackLogController"), animated: true, completion: nil)
    }
    
    // MARK: - private methods
    

    
    
    //反応を速くするためタイマーは0.1秒で回る、点滅の変化は0.5秒にしますのでカウンターで計算必要
    func iconFlashTimer(_ timer:Timer){
        let onWait:String? = UserDefaults.standard.object(forKey: kHVDWaitModeOnFlagKey) as? String
        let waitFlag:String? = UserDefaults.standard.object(forKey: kHVDWaitingFlagKey) as? String
        //Hey Voicedo機能
//        if([onWait isEqualToString:@"true"]&&[waitFlag isEqualToString:@"true"]){
        if((self.inspectionRunningFlag == false)||((onWait != nil)&&(waitFlag != nil)&&(onWait! == "true")&&(waitFlag == "true"))){
            self.mikeIconImage.alpha = 1
            self.mikeIconImage.image = grayImage
            lightCnt = 0
            heavyCnt = 0
            return
        }

        DispatchQueue.main.async { () -> Void in
            if(self.mikeIconImage.image == self.grayImage){
                self.mikeIconImage.image = self.mikeImage
            }
            if(self.mikeIconImage.alpha  == 1){
                if(self.lightCnt % 5 == 0){
                    self.lightCnt = 0
                    UIView.animate(withDuration: 0.5, animations: { () -> Void in
                        self.mikeIconImage.alpha = 0.5
                    })
                }
                self.lightCnt = self.lightCnt + 1
            }else{
                if(self.heavyCnt%5 == 0){
                    self.heavyCnt = 0
                    UIView.animate(withDuration: 0.5, animations: { () -> Void in
                        self.mikeIconImage.alpha = 1
                    })
                }
                self.heavyCnt = self.heavyCnt + 1
                
            }
        }
        
    }
    
    func stopInspectionAtRoot(){
//        let s007 = String(format: NSLocalizedString("S007", comment: "音声認識を一時停止しました"))
//
//        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
//            if let selfWeak = self {
//                selfWeak.stopVoiceInspectionBtn.setTitle(gcontrolBinds.wrecog_start!, forState: .Normal)
//                selfWeak.stopImage.image = UIImage(named: "icon_play")
//                NSUserDefaults.standardUserDefaults().setObject("true", forKey: kGlobalPausekey)
//                NSUserDefaults.standardUserDefaults().synchronize()
//                
//            }
//        }
//        SpeechTalkManager.sharedInstance.speechTalk(s007,forceCancelFlag: true)
    }
    
    /**
     共有の認識パネルの点滅動画を止める＋ボタンのテキスト変更＋認識一時停止フラグのOFF
     */
    func restartInspectionAtRoot(){
//        stopVoiceInspectionBtn.enabled = false
//        let l005013 = String(format: NSLocalizedString("L005-013", comment: "再開失敗"))
//        let s005 = String(format: NSLocalizedString("S005", comment: "音声認識が再開されました"))
//        if((PSRManager.shareInstance().lastRule == nil)||(PSRManager.shareInstance().lastDetail == nil)){
//            print("lastRule nil out")
//            dispatch_async(dispatch_get_main_queue(), { () -> Void in
//                print("l005014 out")
//                SVProgressHUD.showErrorWithStatus(l005013)
//            })
//            return 
//        }
//        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0)) { () -> Void in
//            self.stopVoiceInspectionBtn.enabled = true
//            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
//                if let selfWeak = self {
//
//                    selfWeak.stopVoiceInspectionBtn.setTitle(gcontrolBinds.wrecog_end, forState: .Normal)
//                    selfWeak.stopImage.image = UIImage(named: "icon_ban")
//                    NSUserDefaults.standardUserDefaults().setObject("false", forKey: kGlobalPausekey)
//                    NSUserDefaults.standardUserDefaults().synchronize()
//                }
//            })
//        }
//        
//       
//        SpeechTalkManager.sharedInstance.speechTalkAndDoAction(s005,forceCancelFlag: true, startBlock: nil) { (synthesizer, utterance) -> () in
//            NSNotificationCenter.defaultCenter().postNotificationName(kVoiceDoInSpectionResumeToChildViewNotification, object: nil, userInfo: nil)
//        }
        
    }
    

    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return true
    }
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == kSegueIndentifierContainer) {
            self.containerViewController = segue.destination as! PVDRootContainerController
        }
    }
    
    func aVAudioSessionMediaServicesWereResetNotificationAction(_ notification:Notification){
        let l005004 = String(format: NSLocalizedString("L005-004", comment: "異常：メディアリセットが発生しました、Audio再起動します"))
        
        DispatchQueue.main.async { () -> Void in
            SVProgressHUD.showError(withStatus: l005004)
            if(gsettingModel.voiceDoChannel == "1ch"){
                (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.oneChannelType)
            }else{
                (PSRManager.shareInstance() as AnyObject).change(PSRChannelType.twoChannelType)
            }
        }
        
    }
    
    
    
        
    /**
     認識一時停止する
     
     - parameter notification: <#notification description#>
     */
    func voicedoGlobalInspectionPauseAction(_ notification:Notification){
        
        self.stopInspectionAtRoot()
    }

    
    
    /**
     認識再開
     
     - parameter notification: <#notification description#>
     */
    func voicedoGlobalInspectionRestartAction(_ notification:Notification){
        self.restartInspectionAtRoot()
    
    }
    func applicationWillEnterForegroundAction(_ notification:Notification){
        

    }
    
    func applicationDidEnterBackgroundAction(_ notification:Notification){
        
        
        
    }
    
    func changeRootChildToInputAction(_ notification:Notification){
//        print("%@",notification.userInfo)
        self.containerViewController.swap(notification.userInfo! as NSDictionary)
        
    }
    
    func changeRootHomeToInputAction(_ notification:Notification){
//        print("%@",notification.userInfo)
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.containerViewController.swap(nil)
            }
            
        }
        NotificationCenter.default.post(name: Notification.Name(rawValue: kUpdateunishedWorkSharingStateNotification), object: nil)
        
        

       
    }
    
    func showProcessItemPhotos(_ notification:Notification){

        let l005005 = String(format: NSLocalizedString("L005-005", comment: "メッセージ"))
        let l005006 = String(format: NSLocalizedString("L005-006", comment: "アルバム名が確定できません"))
        let uxxx019 = String(format: NSLocalizedString("UXXX-019", comment: "OK"))
        

        let userinfo: NSDictionary? = notification.userInfo! as NSDictionary
        let albumName:String = userinfo?.object(forKey: kShowPhotoAlbumNameKey) as! String
        if((userinfo == nil)||(userinfo?.object(forKey: kShowPhotoAlbumNameKey) == nil)){
            PVDSwiftUtils.dispatch_async_main({ () -> () in
                UIAlertView(title: l005005, message: l005006, delegate: nil, cancelButtonTitle: uxxx019).show()
            })
            return
        }
        let storyboard = UIStoryboard(name: kiPhoneStoryboardName, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: kImageDisplayIdentifier) as! PVDImageDisplayController
        vc.albumName = albumName
        self.present(vc, animated: true, completion: nil)
        
    }
    
    /**
     メーターを動かす
     
     - parameter notification: <#notification description#>
     */
    func meterChangeNotificationAction(_ notification:Notification){
        //        print("%@",notification.userInfo)
        let userinfo: NSDictionary? = notification.userInfo! as NSDictionary
        let levelValue:Float = ((userinfo?.object(forKey: kMeterValueKey) as AnyObject).floatValue)!
        if(levelValue > 0){
            PVDSwiftUtils.dispatch_async_main { () -> () in
                //                NSLog("meter level:%hd",levelValue!)
                self.levelMeter.setProgress((levelValue * 5)/LEVEL_MAX, animated: false)
                
            }
        }
        
        
    }

    /**
    ログを出す(主に認識関連)
    - parameter notification: 通知内容
    */
    func refreshLogAction(_ notification:Notification){
        let uxxx019 = String(format: NSLocalizedString("UXXX-019", comment: "OK"))
        let l005007 = String(format: NSLocalizedString("L005-007", comment: "音声認識が開始できませんでした"))
        let l005008 = String(format: NSLocalizedString("L005-008", comment: "辞書データに問題がある可能性があります。該当箇所の作業帳票Excelやカスタム辞書が正しいか確認してください"))
        let l005009 = String(format: NSLocalizedString("L005-009", comment: "音声認識停止中です"))
        let logMessage3 = String(format: NSLocalizedString("logMessage3", comment: "認識待ち"))
        let logMessage6 = String(format: NSLocalizedString("logMessage6", comment: "認識完了"))
        

        let inspectPauseflag:Bool = ((UserDefaults.standard.object(forKey: kGlobalPausekey) as AnyObject).boolValue)!
        let userInfo:NSDictionary = notification.userInfo! as NSDictionary
        var logString:NSString = PVDSwiftUtils.getSafeStringFromAnyObject(userInfo.object(forKey: kLogViewKey) as AnyObject) as NSString
        let pauseKey:String? = UserDefaults.standard.object(forKey: kGlobalPausekey) as? String
        if(inspectPauseflag == true){
            logString = l005009 as NSString
        }
        //認識失敗コールバックのメッセージを出す
        if(logString == "SRFailureCB2"){
            let ssalert = UIAlertController(title: l005007, message: l005008, preferredStyle: .alert)
            ssalert.addAction(UIAlertAction(title: uxxx019, style: UIAlertActionStyle.default, handler: nil))
            PVDSwiftUtils.dispatch_async_main({ () -> () in
                self.present(ssalert, animated: true, completion: nil)
            })
            
        }else if(logString as String == logMessage3){
            self.inspectionRunningFlag = true
        }else if(logString as String == logMessage6){
            self.inspectionRunningFlag = false
        }
        
        if(logString.length > 0){
            let backlogPath = kbackupFolder + "/" + gsettingModel.statusLogFileName!
            if(pauseKey == "false"){
                PSRManager.writeLog(toFile: (logString as String + "\n"), filePath: backlogPath)
            }
            
            PVDSwiftUtils.dispatch_async_main({ [weak self]() -> () in
                if let selfWeak = self {
                    let tmpString:NSMutableString =  NSString(string: selfWeak.logView.text).mutableCopy() as! NSMutableString
                    if(selfWeak.logCnt >= kMAXLinesInLogView){
                        //前の行を削除
                        let turnRange:NSRange = tmpString.range(of: "\n")
                        if(turnRange.location != NSNotFound){
                            tmpString.deleteCharacters(in: NSMakeRange(0, turnRange.location+1))
                        }
                        selfWeak.logCnt -= 1;
                    }
                    
                    let atrributetmpString = NSMutableAttributedString(string: tmpString as String, attributes: [NSForegroundColorAttributeName:UIColor.black])
                    let atrributelogString = NSAttributedString(string: (logString as String)+"\n" ,attributes: [NSForegroundColorAttributeName:UIColor.red])
                    atrributetmpString.append(atrributelogString)
                    

                    if(selfWeak.logView != nil){
                        selfWeak.logView.attributedText = atrributetmpString
                    }
                    
                    selfWeak.logCnt += 1
                }
            })

        }else{
            NSLog("空のログ")
        }
    }
    
    


    
    //MARK: カメラ操作
    func voiceTakePhoto(_ notification:Notification){
        photoPicker.takePicture()
    
    }
    
    func rootShowCameraAction(_ notification:Notification){
//        let userInfo:NSDictionary = notification.userInfo!
//        let albumName:NSString = PVDSwiftUtils.getSafeStringFromAnyObject(userInfo.objectForKey(kPhotoAlbumNameKey))
        
        showCamera()
    }
    // 1. カメラを起動する
    func showCamera(){
        
        photoPicker.sourceType = UIImagePickerControllerSourceType.camera
        photoPicker.delegate = self
        photoPicker.showsCameraControls = false
        self.addChildViewController(photoPicker)
        photoPicker.didMove(toParentViewController: self)
        self.view .addSubview(photoPicker.view)
        self.view.addSubview(toverlayView)
        
    }
    
    func cancelPhotoAction(_ sender:AnyObject?){
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.toverlayView.removeFromSuperview()
                selfWeak.photoPicker.view .removeFromSuperview()
                selfWeak.photoPicker.removeFromParentViewController()
            }
        }
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: kRootFinishedCameraNotification), object: nil, userInfo: nil)
        UserDefaults.standard.set(nil, forKey: kPhotoAlbumNameKey)
        UserDefaults.standard.synchronize()
    }
    func takePhotoAction(_ sender:AnyObject?){
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.photoPicker.takePicture()
            }
            
        }
    }
    
    // 2. 撮影が完了した場合
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let l005010 = String(format: NSLocalizedString("L005-010", comment: "画像の保存が失敗しました"))
        let l005011 = String(format: NSLocalizedString("L005-011", comment: "画像の保存が拒否されました"))
        let l005012 = String(format: NSLocalizedString("L005-012", comment: "画像の保存が成功しました"))
        let l005005 = String(format: NSLocalizedString("L005-005", comment: "メッセージ"))
//        weak var weakPicker:UIImagePickerController? = picker
        let tempImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        var alertString:String!
        let albumName:String = UserDefaults.standard.object(forKey: kPhotoAlbumNameKey) as! String
        PVDPhotoAlbumUtil.saveImageInAlbum(tempImage, albumName: albumName) { (result) -> () in
            NSLog("in save Image Album")
            switch result {
            case .error:
                NSLog("save photo error")
                alertString = l005010
                break
                
            case .denied:
                NSLog("save photo denied")
                alertString = l005011
                break
                
            case .success:
                NSLog("save photo success")
                alertString = l005012
                
                break
            
            
            }
            let alertc =  UIAlertView(title: l005005, message: alertString, delegate: nil, cancelButtonTitle: nil)
            PVDSwiftUtils.dispatch_async_main({ () -> () in
                
                alertc.show()
                
            })
            PVDSwiftUtils.dispatchAfterMain(1, afterBlock: { (Void) -> Void in
                alertc.dismiss(withClickedButtonIndex: 0, animated: true)
                NotificationCenter.default.post(name: Notification.Name(rawValue: kRootFinishedCameraNotification), object: nil, userInfo: nil)
                UserDefaults.standard.set(nil, forKey: kPhotoAlbumNameKey)
                UserDefaults.standard.synchronize()
            })
            
        }
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.toverlayView.removeFromSuperview()
                picker.view.removeFromSuperview()
                picker.removeFromParentViewController()
            }
        }
        
        
        

    }
    

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        PVDSwiftUtils.dispatch_async_main { [weak self]() -> () in
            if let selfWeak = self {
                selfWeak.toverlayView.removeFromSuperview()
                picker.view .removeFromSuperview()
                picker.removeFromParentViewController()
            }
        }
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: kRootFinishedCameraNotification), object: nil, userInfo: nil)
        UserDefaults.standard.set(nil, forKey: kPhotoAlbumNameKey)
        UserDefaults.standard.synchronize()
    }
    
    
    

  
    
    
    }
