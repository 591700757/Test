//
//  PVDRootContainerController.swift
//  VoiceDo
//
//  Created by user2 on 2015/09/16.
//  Copyright © 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

import UIKit

class PVDRootContainerController: UIViewController {
    var transitionInProgress:Bool!
    var currentSegueIdentifier:String!
    var homeViewControl:PVDHomeController!
    var inputViewControl:PVDInputController!
    
    
    // MARK: - life cycle

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: Bundle!) {
        super.init(nibName: nil, bundle: nil)
        
    }
    
    convenience init() {
        self.init(nibName: nil, bundle: nil)
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.transitionInProgress = false
        
        self.currentSegueIdentifier = kSegueIdentifierHome
        self.performSegue(withIdentifier: self.currentSegueIdentifier, sender: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation
    func swap(_ userinfo:NSDictionary?){
        
//        print(userinfo)
        self.swapViewControllers(userinfo)

    }
    
    func swapViewControllers(_ userinfo:NSDictionary?){
        if(self.transitionInProgress == true){
            return
        }
        self.transitionInProgress = true
        
        if(self.currentSegueIdentifier == kSegueIdentifierHome){
            self.currentSegueIdentifier = kSegueIdentifierInput
        
        }else{
            self.currentSegueIdentifier = kSegueIdentifierHome
            
        }
        
        
        if((self.currentSegueIdentifier == kSegueIdentifierHome)&&(self.homeViewControl != nil)){
            self.swapFromViewController(self.inputViewControl, toViewController: self.homeViewControl)
            return
        }
        if((self.currentSegueIdentifier == kSegueIdentifierInput)&&(self.inputViewControl != nil)){
            if(userinfo!.object(forKey: kWaitingModelKey) != nil){
                let waitItem:PVDWaitingModel = userinfo!.object(forKey: kWaitingModelKey) as! PVDWaitingModel
                self.inputViewControl.reportid = waitItem.reportId!
                self.inputViewControl.processDetail = waitItem
                self.inputViewControl.processfile = (waitItem.reportId! + ".json") as NSString
//                dictionaryfile
                self.inputViewControl.dictionaryfile = (waitItem.reportId! + ".mrg") as NSString
                self.inputViewControl.workPlanId = userinfo!.object(forKey: kWorkPlanIdKey) as! String
                self.inputViewControl.inputType = userinfo!.object(forKey: kInputJsonFileTypeKey) as! String
                

                self.swapFromViewController(self.childViewControllers[0], toViewController: self.inputViewControl)
            }else{
                print("処理ファイルが指定されていません")
            }
            
            return
        }
        
        self.performSegue(withIdentifier: self.currentSegueIdentifier, sender: userinfo)

    }
    
    /**
     
     
     - parameter fromViewController: <#fromViewController description#>
     - parameter toViewController:   <#toViewController description#>
     */
    func swapFromViewController(_ fromViewController:UIViewController,toViewController:UIViewController){
        toViewController.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        fromViewController.willMove(toParentViewController: nil)
        self .addChildViewController(toViewController)
        self.transition(from: fromViewController, to: toViewController, duration: 1.0, options: UIViewAnimationOptions.transitionCrossDissolve, animations: nil) { [weak self](Bool) -> Void in
            if let selfWeak = self {
                fromViewController.removeFromParentViewController()
                toViewController.didMove(toParentViewController: selfWeak)
                selfWeak.transitionInProgress = false
            }
        }
        
        
     
    }
    

    //
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Instead of creating new VCs on each seque we want to hang on to existing
        // instances if we have it. Remove the second condition of the following
        // two if statements to get new VC instances instead.
        if((segue.identifier == kSegueIdentifierHome)){
            self.homeViewControl = segue.destination as! PVDHomeController
        }
        
        if((segue.identifier == kSegueIdentifierInput)){
            self.inputViewControl = segue.destination as! PVDInputController
        }
        // If we're going to the home view controller.
        if(segue.identifier == kSegueIdentifierHome){
            // If this is not the first time we're loading this.
            if(self.childViewControllers.count > 0){
               
                self.swapFromViewController( self.childViewControllers[0] , toViewController: self.homeViewControl)
            }else{
                // If this is the very first time we're loading this we need to do
                // an initial load and not a swap.
                self.addChildViewController(segue.destination)
                let destView:UIView = segue.destination.view
                destView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
                destView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
                self.view.addSubview(destView)
                segue.destination.didMove(toParentViewController: self)
            }
        
        }else if(segue.identifier == kSegueIdentifierInput){
            // By definition the second view controller will always be swapped with the
            // first one.
            if(sender is NSDictionary ){
                let userinfo = sender as! NSDictionary
                let waitItem:PVDWaitingModel = userinfo.object(forKey: kWaitingModelKey) as! PVDWaitingModel
                self.inputViewControl.processDetail = waitItem
                self.inputViewControl.reportid = waitItem.reportId
                self.inputViewControl.processfile = (waitItem.reportId! + ".json") as NSString
                self.inputViewControl.dictionaryfile = (waitItem.reportId! + ".mrg") as NSString
               
                self.inputViewControl.workPlanId = userinfo.object(forKey: kWorkPlanIdKey) as! String
                

                self.inputViewControl.inputType = userinfo.object(forKey: kInputJsonFileTypeKey) as! String
                self.swapFromViewController(self.childViewControllers[0], toViewController: self.inputViewControl)
            }else{
                print("処理ファイルが指定されていません")
            }
            
        }


    }


}
