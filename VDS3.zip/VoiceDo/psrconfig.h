//
//  psrconfig.h
//  VoiceDo
//
//  Created by user2 on 2015/09/11.
//  Copyright (c) 2015年 jp.co.nec.nis.voicedo. All rights reserved.
//

#ifndef VoiceDo_psrconfig_h
#define VoiceDo_psrconfig_h

//設備、システムINFO
#define kScreenWidth                        (UIScreen.mainScreen().bounds.size.width)
#define kScreenHeight                       ([UIScreen mainScreen].bounds.size.height)
#define iPhone6 ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone && MAX([UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width) == 667)
#define iPhone6Plus ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone && MAX([UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width) == 736)

#define IS_IOS8_OR_LATER ([[[[UIDevice currentDevice] systemVersion] substringToIndex:1] intValue]>=8)



typedef NS_ENUM(NSInteger, PSRChannelType) {
    PSRChannelTypeUnknown          = 0,
    PSROneChannelType              = 1,     //1ch
    PSRTwoChannelType              = 2,     //2ch
};




//Storyboardレイアウト
#define kiPhoneStoryboardName           @"Main"
#define kSegueIdentifierInput           @"embedInput"
#define kSegueIdentifierHome            @"embedHome"
#define kSegueIndentifierContainer      @"embedContainer"
#define kImageDisplayIdentifier         @"PVDImageDisplayController"
#define kImageDisplayCell               @"ImageDisplayCell"



//#define kHomeProcessFile                @"processfile"
//#define kDictionaryName                 @"DictionaryName"  //辞書
#define kWaitingModelKey                  @"reportFormIdKey"  //ホーム画面で選んだレポートの詳細s

#define kCameraRefreshEvent             @"showingCamera"
#define kPhotoAlbumNameKey              @"PhotoAlbumNameKey"
#define kShowPhotoAlbumNameKey          @"albumName"





//設定、音声合成 フラグKey
//#define kTtsInUseKey                    @"VoiceInUse"
#define kInspectWithSpeechKey           @"InspectWithSpeechKey"
#define kNrInUseKey                     @"NrInUse"
#define kNrLevelKey                     @"NoiseLevelKey"
#define kPushToSetting                  @"pushToSetting"
#define kPushToAdvancedSetting          @"pushToAdvancedSetting"
#define kGlobalPausekey                 @"GlobalPausekey"
#define kPushToScanKey                  @"PushToScanKey"
#define kAudioDumpModeKey               @"AudioDumpModeKey"

#define kMikeZeroInputCountKey          @"MikeZeroCount"

//録音ファイル保存key
#define kSaveRecordDumpKey              @"SaveRecordDumpKey"
#define kBackupRecordKey                @"BackupRecordKey"

//Observer key
#define kMeterKey                       @"MeterObserverKey"
#define kKeyChainKey                    @"jp.co.nec.nis.voicedo.VoiceDo-swifts"

//System password
#define kPassInputCtrlKey               @"PassInputCtrlKey"
#define kSystemSettingPasswordKey       @"SystemSettingPasswordKey"

#define MILLI_SEC 1000000

//初期化失敗グラグ
#define kInitFlagKey                       @"initflag"         //sr.iniは修正可能なので、sr.iniの問題による初期化失敗の時にバックアップのsr.iniを適応するフラグ

//通知
#define kRestartVoiceDoRuleNotification                 @"RestartVoiceDoInspectionNotification" //再度認識の通知
#define kStartBackupRuleNotification                    @"StartBackupRuleNotification"
#define kStopSoundRecordNotification                    @"StopSoundRecordNotification"
#define kStopInspectionNotification                     @"StopInspectionNotification"       //認識結果取得後、ルール停止
#define kReceivedInpectionResultNotification            @"ReceivedInpectionResultNotification"  //認識結果を受け取った
#define kMeterChangeNotification                        @"MeterChangeNotification"
#define kRootShowCameraNotification                     @"RootShowCameraNotification"
#define kRootFinishedCameraNotification                 @"RootFinishedCameraNotification"       //finished or cancelled
#define kChangeRootChildToInputNotification             @"ChangeRootChildToInputNotification"
#define kChangeRootChildToHomeNotification              @"ChangeRootChildToHomeNotification"
#define kSetLogTextNotification                         @"SetLogTextNotification"
#define kShowProcessItemImagesNotification              @"ShowProcessItemImagesNotification"    //画像表示通知
#define kVoiceTakePhotoNotification                     @"VoiceTakePhotoNotification"
#define kVoiceTakePhotoCancelNotification               @"VoiceTakePhotoCancelNotification"
#define kVoiceDoInSpectionRestartToRootNotification     @"VoiceDoInSpectionRestartToRootNotification" //認識再開通知
#define kVoiceDoInSpectionPauseToRootNotification       @"VoiceDoInSpectionPauseToRootNotification"   //認識停止通知
#define kVoiceDoInSpectionResumeToChildViewNotification @"VoiceDoInSpectionResumeToChildViewNotification" //子画面認識再開
#define kVoiceDoQRCodeScanNotification                  @"VoiceDoQRCodeScanNotification"     //QRCode Scan notification

#define kVoiceDoQRCodeScanCloseNotification             @"VoiceDoQRCodeScanCloseNotification "

#define kVoiceDoStartNextInputNotification              @"VoiceDoStartNextInputNotification"
#define kVoiceReloadHomeUnfinishedTblNotification       @"VoiceReloadHomeUnfinishedTblNotification"

#define kShowSystemSettingActionNotification            @"ShowSystemSettingActionNotification"

//#define kSiriStopFreeInputNotification                  @"siristopFreeinputNotification"        //siri自由入力完了
#define kSiriInspectionResultNotification               @"SiriInspectionResultNotification"
#define kAddedNewDumpFileNotification                   @"AddedNewDumpFileNotification"
#define kAudioDumpResultNotification                    @"AudioDumpResultNotification"
#define kUpdateDumpFileDurationNotification             @"updateDumpFileDurationNotification"
#define kStartInspectionCallbackNotification            @"StartInspectionCallbackNotification"
#define kStopInspectionCallbackNotification             @"StopInspectionCallbackNotification"
#define kStartWaitingRuleNotification                   @"StartWaitingRuleNotification"             //待ち状態のルールを開始るる
#define kReturnToNormalModeNotification                 @"ReturnToNormalModeNotification"           //Dump再生の時に入力モードを解除する
#define kUpdateunishedWorkSharingStateNotification      @"UpdateunishedWorkSharingState"            //設定で引き継ぎ済み表示数を変えた時すぐに反映



//制御語ファイルから読み込み
#define kControlBindKey                 @"control_bind"     //制御語
#define kStopRecogKey                   @"L005-002"         //認識一時停止
#define kStartRecogKey                  @"L005-003"         //認識再開



#define kResultKey                      @"recognicationResult"      //認識結果




#define    kDumpChoiceNoDump       "オフ"
#define    kDumpChoiceChoosedDump  "指定ファイルのみ保存"
#define    kDumpChoiceAllDump      "全ファイル保存"


//Home、ルール、合成チェック遅延
#define kDoAfterDelayTimeInterval       0.6
#define kHomeRule                       @"Home"
#define kControlRuleKey                 @"Control"
#define kEndControlRuleKey              @"EndControl"
#define kAnnounceKey                    @"announce"
#define kQRControlRuleKey               @"CodeScan"

//meter
#define kMeterValueKey                  @"meterValue"

//log
#define kLogViewKey                     @"logText"
#define kOptionKey                      @"option"
#define kScanCodeKey                    @"ScanCodeKey"


//SPEAKER
#define kForceToUseBuildInSpeeakKey     @"ForceToUseBuildInSpeeakKey"


//result back up key
#define kreportResultDataBackupKey                 @"reportResultDataBackupKey"
#define kreportResultDatabackupIndexKey            @"reportResultDatabackupIndexKey"

#define kWorkPlanIdKey                             @"kWorkPlanIdKey4"
#define kInputJsonFileTypeKey                      @"InputJsonFileTypeKey"

//#define LEVEL_MAX 120.0f       // AudioQueueのレベルメーターを使用する場合
//#define LEVEL_METER
#ifdef LEVEL_METER
#define LEVEL_MAX 120.0f        // AudioQueueのレベルメーターを使用する場合
#else
#define LEVEL_MAX 32767.0f      // マイク入力からレベルを取得する場合
#endif

//Tableview Cell
#define   kPVDWaitingDefaultCell            "PVDWaitngDefaultCell"
#define   kPVDWaitingFinishedCell           "WaitingFinishedCell"
#define   kPVDProcessFinishedCell           "PVDProcessFinishedCell"
#define   kCellIdentifier                   "PVDProcessingCell"
#define   kAudioCellIdentifier              "PVDAudioFileCell"
#define   kPVDProcessingCell                "ProcessingXibCell"
#define   kPVDAudioFileCell                 "PVDAudioFileXibCell"
#define   kPVDProcessingFreeInputCellID     "ProcessingFreeInputXibCell"
#define   kPVDNoiseAdjustCellID             "PVDNoiseAdjustCellID"
#define   kPVDSettingStatusCell             "PVDSettingStatusCell"




#define  kMAXWordInput              8192
#define  kMAXLinesInLogView         3

//Siri発話レート
#define  kVoicedoMaximumSpeechRate              0.7
#define  kVoiceMinimumSpeechRate                0.2


//フォントサイズ
#define kVoicedoMaximumGFontSize                40
#define kVoicedoMinimumGFontSize                10

#define kHeightOfSettingStatusCell              60
 

#define kMaxTimeInterval                        356400

#define kMaxbackupUploadRecord                  10

//ダウンロード関連
#define  kDownloadInitFileName       "Library/init.zip"

#define  kInspectionDumpNameKey      @"InspectionDumpNameKey"
#define  kInspectionDumpUserKey      @"InspectionDumpUserKey"
#define  kInspectionDumpDictKey      @"InspectionDumpDictKey"
#define  kInspectionDumpRuleKey      @"InspectionDumpRuleKey"







//環境設定ファイルのキー
#define kWhiteNoiseLevel            @"white_noise_level"

//Document path----------------------------------------------------------------------------------------------------------
#define  kInspectionDebugLogFile    "Documents/InspectionDebug.json"
#define  kInspectionLogFolder       [NSString stringWithFormat:@"Documents/InspectionLogs/"]
#define  kInspectionDumpPath         @"Documents/AudioDump/"
#define  kInspectionDumpTmpPath      @"Documents/AudioDumpTmp/"            //指定のDumpを残す時の臨時フォルダー
//-----------------------------------------------------------------------------------------------------------------------



//Library path------------------------------------------------------------------------
#define kDefaultMalePath            "/Library/homejson/speaker/999999_000000.usr"
#define kHomeSpeakerFolder          "/Library/homejson/speaker/"
#define kHomeDicFolder              "/Library/homejson/dic/"


#define kHomeDicFile                "/Library/homejson/dic/home_recog_dic.mrg"
#define ksrChangeTmpFile            "/Library/srchanging.ini"
#define kLibReportFolder            "/Library/homejson/reports/"


//------------------------------------------------------------------------------------



#define  kIniFilePassword        "Ams32aAVKTzgSTapEX9M10Wdk+/yJrJs"

//debug flag
#define kforceStopInspection        1
#define kLogInspection              1



//Hey VoiceDo　keys
#define kHVDWaitModeOnFlagKey           "HeyVoiceDowaitModeOn"      //true:入力待ちモード　false:通常モード
#define kHVDWaitingFlagKey              "HeyVOiceDoWaiting"         //true:入力待ち中　false:入力可能
#define kHVDWaitBindKey                 @"HeyVoiceDoWaitBindKey"   //hey voicedo wait flag
#define kHVDWaitLblTitle                "入力待ち"



//Home画面からの遷移種類 s
#define     kPVDInputTypeNew          "フォーマットから新規"            //新規の検査
#define     kPVDInputTypeUnfinished   "未完了作業から"                 //未完了から編集
#define     kPVDInputTypeFinished     "完了作業から"                   //完了から編集
#define     kPVDInputTypeUploaded     "アップロード済"

#define     kVoicedoDataBase          "voicedo.sqlite"

#define  kAppGroupId                                    "group.jp.co.nec.nis.handsfree"  //nec.nis
//#define  kAppGroupId                                    "group.jp.co.nis.handsfree"      //NIS


#define  kSrFileNameInShareContainer                    "handsfree.ini"
//SQL
#define  kengineSettingFileNameInShareContainer         "sr.ini"
//SQL create
#define  kengineSettingBKFileNameInShareContainer       "srbk.ini"
#define  kengineDataFolderNameInShareContainer          "/data/"
#define  kengineDicFolderNameInShareContainer           "/dic/"
//SQL insert
#define  kengineDefaultUserFolderNameInShareContainer   "/homejson/"
#define  kengineSynthFolderNameInShareContainer         "/Synth/"
#define  kengineTTSEngineFileNameInShareContainer       "TTSEngine.ini"

//SQL
#define kTmpDumpTableName           "tmpDumpTable"
#define kAudioDumpTableName         "audioDumpTable"
#define kuploadRecordTableName      "uploadRecordTable"

//SQL create
#define kCreateTmpDumpTableSQL      "create table IF NOT EXISTS tmpDumpTable(ID INTEGER PRIMARY KEY AUTOINCREMENT,filename text,currentRule text,userfilePath text,dicfilePath text,duration Int,audioStarttime double, audioEndtime double, flag BOOL)"
#define kCreateAudioDumpTableSQL    "create table IF NOT EXISTS  audioDumpTable(ID INTEGER PRIMARY KEY AUTOINCREMENT,filename text,currentRule text,userfilePath text,dicfilePath text,duration Int,audioStarttime double, audioEndtime double, flag BOOL)"
#define kCreateUploadedTableSQL     "create table IF NOT EXISTS uploadRecordTable(ID INTEGER PRIMARY KEY AUTOINCREMENT,filename text,name text,work_plan_id text,last_edit_time text,original_result_id text,report_form_id text,work_primary_id text)"





//SQL insert
#define kAddFirstTmpDumpTableRecordSQL "insert into tmpDumpTable (ID,filename,currentRule,userfilePath,dicfilePath, audioStarttime,flag) values (0,?,?,?,?,?,?)"
#define kAddFirstAudioDumpTableRecordSQL "insert into audioDumpTable (ID,filename,currentRule,userfilePath,dicfilePath, audioStarttime,flag) values (0,?,?,?,?,?,?)"

#define kAddNewTmpDumpTableRecordSQL "insert into tmpDumpTable (ID,filename,currentRule,userfilePath,dicfilePath, audioStarttime,flag) values (NULL,?,?,?,?,?,?)"
#define kAddNewAudioDumpTableRecordSQL "insert into audioDumpTable (ID,filename,currentRule,userfilePath,dicfilePath, audioStarttime,flag) values (NULL,?,?,?,?,?,?)"


#define kAddFirstAudioDumpTableRecordSQL_2 "insert into audioDumpTable (ID,filename,currentRule,userfilePath,dicfilePath, audioStarttime,audioEndtime,flag) values (0,?,?,?,?,?,?,0)"
#define kAddNewAudioDumpTableRecordSQL_2 "insert into audioDumpTable (ID,filename,currentRule,userfilePath,dicfilePath, audioStarttime,audioEndtime,flag)  values (NULL,?,?,?,?,?,?,0)"


#define kAddFisrtUploadedRecordSQL       "insert into uploadRecordTable (ID,filename,name,work_plan_id,last_edit_time,original_result_id,report_form_id,work_primary_id) values(0,?,?,?,?,?,?,?)"
#define kAddNewUploadeRecordSQL          "insert into uploadRecordTable (ID,filename,name,work_plan_id,last_edit_time,original_result_id,report_form_id,work_primary_id) values(NULL,?,?,?,?,?,?,?)"




//SQL select
#define kSelectAudioDumpTableNewRecordSQL "SELECT * FROM audioDumpTable ORDER BY audiostarttime DESC LIMIT 1"
#define kSelectTmpDumpTableNewRecordSQL "SELECT * FROM tmpDumpTable ORDER BY audiostarttime DESC LIMIT 1"

#define kSelectUpdateAudioDumpTableDurationSQL "SELECT * FROM audioDumpTable where duration IS NULL OR duration = ''"


#define kCountTmpDumpTableRecordSQL     "SELECT COUNT(*) FROM tmpDumpTable"
#define kCountAudioDumpTableRecordSQL   "SELECT COUNT(*) FROM audioDumpTable"
#define kCountuploadRecordTableSQL      "SELECT COUNT(*) FROM uploadRecordTable"

#define kSelectAudioDumpListSQL         "select * from audioDumpTable"

#define kSelectUpdateSaveFlagSQL        "select * from tmpDumpTable ORDER BY audiostarttime DESC LIMIT 2"


#define kSelectTmptableFlagOnSQL        "select * from tmpDumpTable where flag = 1 ORDER BY audiostarttime"
#define kSelectUploadedTableSQL         "select * from uploadRecordTable order by last_edit_time DESC"

#define kSelectUploadedTableByIdSQL         "select * from uploadRecordTable where original_result_id = ?"


//SQL delete
#define kDeleteAllFromaudioDumpTableSQL               "delete from audioDumpTable"
#define kDeleteAllFromtmpDumpTableSQL                 "delete from tmpDumpTable"
#define kDeleteAllFromUploadedTableSQL                "delete from uploadRecordTable"
#define kDeleteOldRecordSQL                           "delete from uploadRecordTable where ID in (select ID from uploadRecordTable uploadRecordTable order by ID limit 1) "



//SQL update
#define kUpdateUploadedTableSQL         "update uploadRecordTable set filename = ? , name = ? , work_plan_id = ? ,last_edit_time = ? ,work_primary_id = ?  where original_result_id = ?"







#endif
